#Program for accepting Two Numerical value and find Biggest among them and check for equality.
#TernaryOpEx2.py
a=float(input("Enter First Value:"))
b=float(input("Enter Second Value:"))
bv=a if a>b else b if b>a else "Both Values are Equal"
print("Big({},{})={}".format(a,b,bv))