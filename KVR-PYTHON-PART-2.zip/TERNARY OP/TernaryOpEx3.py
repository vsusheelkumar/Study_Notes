#Program for accepting Three Numerical value and find Biggest among them and check for equality.
#TernaryOpEx3.py
a=float(input("Enter First Value:"))
b=float(input("Enter Second Value:"))
c=float(input("Enter Third Value:"))
bv=a if(a>=b and a>c) else b if (b>a and b>=c) else c if (c>b and c>=a) else "All values equal"
print("Big({},{},{})={}".format(a,b,c,bv))
