#Program for accepting Numerical value and Decide whether it is +VE or -VE or Zero
#TernaryOpEx4.py
value=float(input("Enter Any Numerical Value:")) # Value--   10  OR -10  OR 0
res="+VE" if value>0 else "-VE" if value<0 else "ZERO "
print("{} is {}".format(value,res))
