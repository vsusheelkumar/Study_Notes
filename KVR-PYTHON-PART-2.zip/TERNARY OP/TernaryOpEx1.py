#Program for Deciding  Whetherthe given value Palindrome or Not
#TernaryOpEx1.py
val=input("Enter a Value:")
res="PALINDROME" if val==val[::-1] else "NOT PALINDROME"
print("{} is {}".format(val,res))