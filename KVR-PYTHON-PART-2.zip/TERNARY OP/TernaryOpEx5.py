#Program for accepting Numerical Integer value
# and Decide whether it is Even or Odd and It the Value of 0 or -ve the display Invalid Input
#TernaryOpEx5.py
value=int(input("Enter Any Inetger Value:")) # Value 120   121    -12   0
res="Invalid Input" if value<=0 else "EVEN" if value%2==0 else "ODD"
print("{} is {}".format(value,res))