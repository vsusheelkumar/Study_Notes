#LogEx6.py
import logging
logging.basicConfig(level="ERROR",format='%(asctime)s  : %(levelname)s: %(message)s',datefmt='%d-%m-%Y  %I:%M:%S %p ')
print("Logging Concept is going on")
logging.critical("\tCritical Messages")
logging.error("\tError Message")
logging.warning("\tWarning Message")
logging.info("\tInformation message")
logging.debug("\tDebuging Message")		
