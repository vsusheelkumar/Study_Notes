#DivEx9.py
import logging
try:
	logging.basicConfig(level="ERROR",format='%(asctime)s  : %(levelname)s: %(message)s',datefmt='%d-%m-%Y  %I:%M:%S %p ')
	print("Program exectuion started")
	a=float(input("Enter Value of a:"))
	b=float(input("Enter Value of b:"))
	res=a/b
except ValueError:
	logging.error("Don't enter alnums,strs and symbols for Integer data")
except ZeroDivisionError:
	logging.error("Don't Enter Zero for Den...")
else:
	print("Div({},{})={}".format(a,b,res))
finally:
	print("Program exectuion completed")
