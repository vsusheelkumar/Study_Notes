#LogEx4.py
import logging
logging.basicConfig()
print("Logging Concept is going on")
logging.critical("\tCritical Messages")
logging.error("\tError Message")
logging.warning("\tWarning Message")
logging.info("\tInformation message")
logging.debug("\tDebuging Message")		
