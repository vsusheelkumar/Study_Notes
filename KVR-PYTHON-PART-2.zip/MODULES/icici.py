#icici.py<-----File Name and Module Name
bname="ICICI"
addr="Ampt-HYD" # here bname and addr are called Global Variables
def simpleint():  # Function Def...
    print("------------------------------------")
    p=float(input("Enter Principle Amount:"))
    t=float(input("Enter Time:"))
    r = float(input("Enter Rate Interest:"))
    print("------------------------------------")
    si=(p*t*r)/100
    totamt=p+si
    print("------------------------------------")
    print("Principle Amount:{}".format(p))
    print("Time:{}".format(t))
    print("Rate of Interest:{}".format(r))
    print("Simple interest:{}".format(si))
    print("Total Amount to Pay:{}".format(totamt))
    print("------------------------------------")

