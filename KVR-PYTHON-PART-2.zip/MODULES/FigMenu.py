#FigMenu.py<----File Name and Module Name
def menu():
    print("-"*50)
    print("\tArea of Different Figures")
    print("-" * 50)
    print("\t\t1.Rectangle")
    print("\t\t2.Square")
    print("\t\t3.Circle")
    print("\t\t4.Triangle")
    print("\t\t5.Exit")
    print("-" * 50)
