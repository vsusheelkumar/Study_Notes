#ImportStmtSyntax4.py
import MathsInfo as m, Aop as a,icici as ic
print("---------------------------------------")
print("Value of PI=",m.PI)
print("Value of E=",m.E)
print("---------------------------------------")
a.addop(10,30) # Function call
a.subop(200,300) # Function call
a.mulop(4,5)# Function call
print("---------------------------------------")
print("Bank Name={}".format(ic.bname))
print("Bank Address={}".format(ic.addr))
ic.simpleint()
print("---------------------------------------")