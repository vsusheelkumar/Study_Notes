n=25
res=sqrt(n) # Function call
print("sqrt({})={}".format(n,res))