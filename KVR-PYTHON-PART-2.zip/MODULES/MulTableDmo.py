#MulTableDemo.py
from MulTable import table as t
t(int(input("Enter a Number:")))