#Triangle.py<---File Name and Module Name
def area1():
    B = float(input("Enter Base:"))
    H = float(input("Enter Height:"))
    at = (1/2)*B*H
    print("Area of Triangle={}".format(at))
def area2():
    A = float(input("Enter Side1:"))
    B = float(input("Enter Side2:"))
    C = float(input("Enter Side3:"))
    s=(A+B+C)/2
    at=(s*(s-A)*(s-B)*(s-C))**0.5
    print("Area of Triangle={}".format(at))


