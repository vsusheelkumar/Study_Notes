#Square.py<----File Name and Module Name
def area():
    side = float(input("Enter Value of Side:"))
    sa = side**2
    print("Area of Square={}".format(sa))

