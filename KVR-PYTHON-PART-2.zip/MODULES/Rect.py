#Rect.py<---File Name and Module Name
def area():
    L=float(input("Enter Length:"))
    B = float(input("Enter Breadth:"))
    ar=L*B
    print("Area of Rect={}".format(ar))



