#FigureDemo2.py<-----File Name and Program Name
from FigMenu import menu
from Rect import area as ra
from Square import area as sa
from Circle import area as ca
from Triangle import area1,area2
while(True):
    menu()
    ch=int(input("Enter Ur Choice:"))
    match(ch):
        case 1:
            ra()
        case 2:
            sa()
        case 3:
            ca()
        case 4:
            while(True):
                print("---------------------------")
                print("\tSub Menu of Triangle ")
                print("---------------------------")
                print("\t\t1.Area-with Base and hight")
                print("\t\t2.Area-with Three sides")
                print("\t\t3.Exit")
                print("---------------------------")
                c=int(input("Enter Ur Choice:"))
                match(c):
                    case 1:
                        area1()
                    case 2:
                        area2()
                    case 3:
                        break
                    case _:
                        print("Ur Selection of Sub Menu Op is Wrong-try again")
        case 5:
            print("Thx for this Program")
            break
        case _:
            print("Ur Selection of Operation is Wrong-try again")