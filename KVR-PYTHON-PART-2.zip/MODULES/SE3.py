#SE3.py<---File Name and Program
import icici
print("Bank Name={}".format(icici.bname))
print("Bank Address={}".format(icici.addr))
icici.simpleint()