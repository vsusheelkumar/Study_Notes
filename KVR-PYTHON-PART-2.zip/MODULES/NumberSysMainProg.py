#NumberSysMainProg.py
from NumberSysMenu import menu
from DecToBOH import DecToBOHconversion
from BinToDOH import BinToDOHconversion
from OctToDBH import OctToDBHconversion
from HexToDBO import HexToDBOconversion
while(True):
    menu()
    ch=int(input("Enter Ur Choice:"))
    match(ch):
        case 1:
            DecToBOHconversion()
        case 2:
            BinToDOHconversion()
        case 3:
            OctToDBHconversion()
        case 4:
            HexToDBOconversion()
        case 5:
            break
        case _:
            print("Ur Selection of Operation is wrong-try again")
