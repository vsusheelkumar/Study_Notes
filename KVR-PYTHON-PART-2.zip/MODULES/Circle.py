#Circle.py<---File Name and Module Name
def area():
    r= float(input("Enter Value of Radius:"))
    ac = 3.14*r**2
    print("Area of Circle={}".format(ac))

