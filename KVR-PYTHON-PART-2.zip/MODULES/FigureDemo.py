#FigureDemo.py<-----File Name and Program Name
from FigMenu import menu
from Rect import area as ra
from Square import area as sa
from Circle import area as ca
from Triangle import area1,area2
while(True):
    menu()
    ch=int(input("Enter Ur Choice:"))
    match(ch):
        case 1:
            ra()
        case 2:
            sa()
        case 3:
            ca()
        case 4:
            area1()
            area2()
        case 5:
            print("Thx for this Program")
            break
        case _:
            print("Ur Selection of Operation is Wrong-try again")