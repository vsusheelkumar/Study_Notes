#FromImportStmtEx3.py
from MathsInfo import *
from Aop import *
from icici import *
print("---------------------------------------")
print("Value of PI=",PI)
print("Value of E=",E)
print("---------------------------------------")
addop(10,30) # Function call
subop(200,300) # Function call
mulop(4,5)# Function call
print("---------------------------------------")
print("Bank Name={}".format(bname))
print("Bank Address={}".format(addr))
simpleint()
print("---------------------------------------")