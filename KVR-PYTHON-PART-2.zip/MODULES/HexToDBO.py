#HexToDBO.py
def HexToDBOconversion():
    hv=input("Enter Hexa Decimal Number System Value:")
    dv=int(hv,16)
    bv=bin(dv)
    ov=oct(dv)
    print("Given Hexa Decimal Number System Valuue:{}".format(hv))
    print("\t\tDec({})={}".format(hv,dv))
    print("\t\tBin({})={}".format(hv, bv))
    print("\t\tOct({})={}".format(hv, ov))

