#ImportStmtSyntax2.py
import MathsInfo, Aop,icici
print("---------------------------------------")
print("Value of PI=",MathsInfo.PI)
print("Value of E=",MathsInfo.E)
print("---------------------------------------")
Aop.addop(10,30) # Function call
Aop.subop(200,300) # Function call
Aop.mulop(4,5)# Function call
print("---------------------------------------")
print("Bank Name={}".format(icici.bname))
print("Bank Address={}".format(icici.addr))
icici.simpleint()
print("---------------------------------------")