#OctToDBH.py
def OctToDBHconversion():
    ov=input("Enter Octal Number System Value:")
    dv=int(ov,8)
    bv=bin(dv)
    hv=hex(dv)
    print("Given Octal Number System Valuue:{}".format(ov))
    print("\t\tDec({})={}".format(ov,dv))
    print("\t\tBin({})={}".format(ov, bv))
    print("\t\thex({})={}".format(ov, hv))
