#SE2.py<--File Name and Program
import Aop
Aop.addop(10,30) # Function call
Aop.subop(200,300) # Function call
Aop.mulop(4,5)# Function call