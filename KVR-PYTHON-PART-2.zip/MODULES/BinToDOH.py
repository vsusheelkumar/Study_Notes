#BinToDOH.py
def BinToDOHconversion():
    bv=input("Enter Binary Number System Value:")
    dv=int(bv,2)
    ov=oct(dv)
    hv=hex(dv)
    print("Given Binary Number System Valuue:{}".format(bv))
    print("\t\tDec({})={}".format(bv,dv))
    print("\t\toct({})={}".format(bv, ov))
    print("\t\thex({})={}".format(bv, hv))

