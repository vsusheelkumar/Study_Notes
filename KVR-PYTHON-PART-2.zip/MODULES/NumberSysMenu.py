#NumberSysMenu.py
def menu():
    s="""---------------------------------------------------------------------
			 Base Conversion Calculator
	---------------------------------------------------------------------
                1.    D to B
                      D to O
                      D to H
                2.    B to D
                      B to O
                      B to H
                3.    O to D
                      O to B
                      O to H
                4.    H to D
                      H to B
                      H to O
	-----------------------------------------------------------------------"""
    print(s)

