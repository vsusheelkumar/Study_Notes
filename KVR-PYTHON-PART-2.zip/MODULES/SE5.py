#SE5.py
import calendar
year=int(input("Enter Ur Year of Birth:"))
mon=int(input("Enter Ur Month of Birth:"))
print(calendar.month(year,mon))
