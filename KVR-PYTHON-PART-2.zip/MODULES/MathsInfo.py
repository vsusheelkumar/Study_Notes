#MathsInfo.py<---File Name and treated as Module Name
PI=3.14
E=2.71 # here PI and E Are called global Variables
