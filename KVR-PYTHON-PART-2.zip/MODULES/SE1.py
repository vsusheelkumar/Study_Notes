#SE1.py<---File Name and Program
import MathsInfo
print("Value of PI=",MathsInfo.PI)
print("Value of E=",MathsInfo.E)
