#FromImportStmtEx2.py
from MathsInfo import PI,E
from Aop import addop as ap,subop as sp,mulop as mp
from icici import bname as bn,addr as ad,simpleint as si
print("---------------------------------------")
print("Value of PI=",PI)
print("Value of E=",E)
print("---------------------------------------")
ap(10,30) # Function call
sp(200,300) # Function call
mp(4,5)# Function call
print("---------------------------------------")
print("Bank Name={}".format(bn))
print("Bank Address={}".format(ad))
si()
print("---------------------------------------")