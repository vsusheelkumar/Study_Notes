#Aop.py<----File Name and Module Name
def addop(x,y):
    print("sum({},{})={}".format(x,y,x+y))
def subop(x,y):
    print("sub({},{})={}".format(x,y,x-y))
def mulop(x,y):
    print("mul({},{})={}".format(x,y,x*y))



