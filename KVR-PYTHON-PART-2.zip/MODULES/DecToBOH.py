#DecToBOH.py
def DecToBOHconversion():
    dv=int(input("Enter Deciaml Number System Value:"))
    bv=bin(dv)
    ov=oct(dv)
    hv=hex(dv)
    print("Given Decimal Number System Valuue:{}".format(dv))
    print("\t\tbin({})={}".format(dv,bv))
    print("\t\toct({})={}".format(dv, ov))
    print("\t\thex({})={}".format(dv, hv))

