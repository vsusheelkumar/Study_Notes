#Program for Searching Zero K OR One 'K' or More K's
#RegExpr24.py
import re
matres=re.finditer("K*","KVKKVKKKVKV")
print("-"*50)
for mat in matres:
	print("\tStart Index:{}   End Index:{}  Value:{}".format(mat.start(),mat.end(),mat.group()))
print("-"*50)