#Program for Exracting the Words from Given Text
#NamesExtractEx1.py
import re
gd="Rossum got 66 marks, Travis got 55 marks , Ritche got 45 marks , Dennis got 88 marks and Hunter got 44 marks"
sp="[A-Za-z]+"
names=re.findall(sp,gd)
print("List of Words")
for word in names:
	print(word)
