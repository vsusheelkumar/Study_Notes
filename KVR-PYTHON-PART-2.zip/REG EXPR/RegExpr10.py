#Program for Searching all  Upper and   Lower Case Alphabets 
#RegExpr10.py
import re
gd="bRh5&Wa8#KhbGAt6c@PrB3"
sp="[A-Za-z]"
matres=re.finditer(sp,gd)
print("-"*50)
for mat in matres:
	print("\tStart Index:{}   End Index:{}  Value:{}".format(mat.start(),mat.end(),mat.group()))
print("-"*50)