#Program for searching a Word 'Python' and find Their Position OR Index
#RegExpr3.py
import re
gd="Python is an oop lang.Python is also fun prog lang"
word="an"
matresult=re.finditer(word,gd) # Here matresult type is callable_iterator
for mat in matresult: # here mat is an object of <class, re.Match >
	print("\tStart Index:{}   End Index:{}  Value:{}".format(mat.start(),mat.end(),mat.group()))