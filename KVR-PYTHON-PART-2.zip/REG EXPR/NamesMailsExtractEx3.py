#Program for Extracting the Names  and Mails from Given  File
#NamesMailsExtractEx3.py
import re
try:
	with open("E:\\KVR-PYTHON-7AM\\REG EXPR\\notes\\mails.data","r") as fp:
		filedata=fp.read()
		mailslist=re.findall(r"\S+@\S+",filedata)
		names=re.findall("[A-Z][a-z]+",filedata)
		print("-"*50)
		print("\tName\t\tMail-ID")
		print("-"*50)
		for sname,mail in zip(names,mailslist):
				print("\t{}\t\t{}".format(sname,mail))
		print("-"*50)
except FileNotFoundError:
	print("File Does not Exist")