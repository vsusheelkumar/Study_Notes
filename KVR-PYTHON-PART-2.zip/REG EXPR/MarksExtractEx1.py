#Program for Extracting the Marks from given Text
#MarksExtractEx1.py
import re
gd="Rossum got 66 marks, Travis got 55 marks , Ritche got 45 marks , Dennis got 88 marks and Hunter got 44 marks"
sp=r"\d{2}"
marks=re.findall(sp,gd)
print("List of Marks")
for m in marks:
	print("\t",m)