#Program for Extracting the Marks from given Text
#MarksExtractEx2.py
import re
print("List of Marks")
for m in re.findall(r"\d{2}","Rossum got 66 marks, Travis got 55 marks , Ritche got 45 marks , Dennis got 88 marks and Hunter got 44 marks"):
	print("\t",m)