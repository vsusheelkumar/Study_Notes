#Program for Searching Special Symbols  except   Apha-numerics
#RegExpr15.py
import re
gd="bRh5&Wa8#KhbGAt6c@PrB3"
sp="[^A-Za-z0-9]"
matres=re.finditer(sp,gd)
print("-"*50)
for mat in matres:
	print("\tStart Index:{}   End Index:{}  Value:{}".format(mat.start(),mat.end(),mat.group()))
print("-"*50)