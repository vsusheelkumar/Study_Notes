#Program for Extracting the Names and Marks from Given Text
#NamesMarksExtractEx1.py
import re
gd="Rossum got 66 marks, Travis got 55 marks , Ritche got 45 marks , Dennis got 88 marks and Hunter got 44 marks and Kvr got 11 marks"
names=re.findall("[A-Z][a-z]+",gd)
marks=re.findall(r"\d{2}",gd)
print("-"*50)
print("\tName\t\tMarks")
print("-"*50)
for sname,smarks in zip(names,marks):
	print("\t{}\t\t{}".format(sname,smarks))
print("-"*50)