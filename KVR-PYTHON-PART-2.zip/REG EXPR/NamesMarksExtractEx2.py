#Program for Extracting the Names and Marks from Given File where It Contains Student Data
#NamesMarksExtractEx2.py
import re
try:
	with open("E:\\KVR-PYTHON-7AM\\REG EXPR\\notes\\stud.info","r") as fp:
		filedata=fp.read()
		names=re.findall("[A-Z][a-z]+",filedata)
		marks=re.findall(r"\d{2}",filedata)
		print("-"*50)
		print("\tName\t\tMarks")
		print("-"*50)
		for sname,smarks in zip(names,marks):
			print("\t{}\t\t{}".format(sname,smarks))
		print("-"*50)
except FileNotFoundError:
	print("File does not Exist")