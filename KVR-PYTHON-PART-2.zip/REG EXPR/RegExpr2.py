#Program for searching a Word 'Python' and find Their Position OR Index
#RegExpr2.py
import re
gd="Python is an oop lang.Python is also fun prog lang"
word="Python"
matresult=re.search(word,gd) # Here matresult type can be either <re.Match> or NoneType
if(matresult!=None):
		print("\tSearch is Sucessful")
		print("\tStart Index=",matresult.start())
		print("\tEnd Index=",matresult.end())
		print("\tMatched Value=",matresult.group())
else:
	print("\tSearch is Un-Sucessful")
