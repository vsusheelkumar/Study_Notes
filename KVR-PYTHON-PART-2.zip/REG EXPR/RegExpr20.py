#Program for Searching Space Characters
#RegExpr20.py
import re
gd="b Rh5&Wa8# KhbGAt6c@PrB3"
sp=r"\s"
matres=re.finditer(sp,gd)
print("-"*50)
for mat in matres:
	print("\tStart Index:{}   End Index:{}  Value:{}".format(mat.start(),mat.end(),mat.group()))
print("-"*50)