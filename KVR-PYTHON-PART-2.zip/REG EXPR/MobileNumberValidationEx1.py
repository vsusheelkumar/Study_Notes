#Program for Validation of Mobile Number
#MobileNumberValidationEx1.py
import re
while(True):
	mno=input("Enter Ur Mobile Number:")
	if(len(mno)==10):
		res=re.search(r"\d{10}",mno)
		if(res!=None):
			print("\t{} Valid Mobile Number:".format(mno))
			break
		else:
			print("\t{} is Invalid Mobile Number bcoz It Contains non-int Values--try again".format(mno))
	else:
		print("\t{} is Invalid Mobile Number Length--try again".format(mno))
	
