#Program for Extracting the Names  and Mails from Given Text
#NamesMailsExtractEx2.py
import re
gd="Rossum mail id is rossum.1@psf.com, Travis mail id is  travis_num@numpy.org , Ritche mail id is ritche_c@belllabs.org.net , Dennis mail id dennis_cd@bell.co.in  and Hunter mail id is jhon_hunter@matplotlib.net.in and Kvr mail id is kvr1.python@gmail.com"
mailslist=re.findall(r"\S+@\S+",gd)
names=re.findall("[A-Z][a-z]+",gd)
print("-"*50)
print("\tName\t\tMail-ID")
print("-"*50)
for sname,mail in zip(names,mailslist):
		print("\t{}\t\t{}".format(sname,mail))
print("-"*50)