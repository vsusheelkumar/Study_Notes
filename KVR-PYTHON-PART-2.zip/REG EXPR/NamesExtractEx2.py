#Program for Exracting the Words from Given Text
#NamesExtractEx2.py
import re
gd="Rossum got 66 marks, Travis got 55 marks , Ritche got 45 marks , Dennis got 88 marks and Hunter got 44 marks"
sp="[A-Z][a-z]+"
names=re.findall(sp,gd)
print("List of Names")
for word in names:
	print("\t",word)
