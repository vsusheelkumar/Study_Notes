#Program for Searching for all except  'a' or 'b' or 'c'
#RegExpr5.py
import re
gd="bRh5&Wa8#KhbGAt6c@PrB3"
sp="[^abc]"
matres=re.finditer(sp,gd)
print("-"*50)
for mat in matres:
	print("\tStart Index:{}   End Index:{}  Value:{}".format(mat.start(),mat.end(),mat.group()))
print("-"*50)