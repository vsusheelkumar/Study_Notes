#Program for searching a Word 'Python' and their Number of Occurences
#RegExpr1.py
import re
gd="Python is an oop lang.Python is also fun prog lang"
word="an"
noc=re.findall(word,gd) # here noc is of type <class, list>
if(len(noc)!=0):
	print("Search is Sucessful")
	print("Number of Times '{}' Occurs in '{}' Times".format(word,len(noc)))
else:
	print("Search is Un-Sucessful")
	print("'{}'  does not Occurs".format(word))
