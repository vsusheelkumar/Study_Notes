#Program for Searching  all Values one by one
#RegExpr26.py
import re
matres=re.finditer(".","KVKKVKKKVKV")
print("-"*50)
for mat in matres:
	print("\tStart Index:{}   End Index:{}  Value:{}".format(mat.start(),mat.end(),mat.group()))
print("-"*50)