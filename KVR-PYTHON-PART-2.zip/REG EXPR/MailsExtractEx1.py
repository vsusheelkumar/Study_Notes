#Program for Extracting the Names and Marks from Given Text
#MailsExtractEx1.py
import re
gd="Rossum mail id is rossum.1@psf.com, Travis mail id is  travis_num@numpy.org , Ritche mail id is ritche_c@belllabs.org.net , Dennis mail id dennis_cd@bell.co.in  and Hunter mail id is jhon_hunter@matplotlib.net.in and Kvr mail id is kvr1.python@gmail.com"
sp=r"\S+@\S+"
mailslist=re.findall(sp,gd)
print("----------------------------------------------")
print("List of Mails")
print("----------------------------------------------")
for mail in mailslist:
	print("\t{}".format(mail))
print("----------------------------------------------")