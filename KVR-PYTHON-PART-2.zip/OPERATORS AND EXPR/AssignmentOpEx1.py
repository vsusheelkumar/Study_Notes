#Program for cal all arithmetic Operations by using multi line assignment op
#AssignmentOpEx1.py
a,b=float(input("Enter Value of a:")),float(input("Enter Value of b:"))
add,sub,mul,div,fdiv,mod,exp=a+b,a-b,a*b,a/b,a//b,a%b, a**b
print("-"*40)
print("Arithmetic Operations by using multi line assignment op ")
print("-"*40)
print("\tsum({},{})={}".format(a,b,add))
print(f"\tsub({a},{b})={sub}")
print(f"\tmul({a},{b})={mul}")
print(f"\tdiv({a},{b})={div}")
print(f"\tfloordiv({a},{b})={fdiv}")
print(f"\tmod({a},{b})={mod}")
print(f"\tpow({a},{b})={exp}")
print("-"*40)
