#Program for Swapping of Two Values
#AssignmentOpEx3.py--Only Integer Values
a,b=input("Enter Value of a:"),input("Enter Value of b:")
print("-"*40)
print("\t\tOriginal Value of a={}".format(a))
print("\t\tOriginal Value of b={}".format(b))
print("-"*40)
#Logic-2 for Swapping
x=a
a=b
b=x
print("\t\tSwapped Value of a={}".format(a))
print("\t\tSwapped Value of b={}".format(b))
print("-"*40)
