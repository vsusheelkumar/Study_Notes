#Program for Swapping of Two Values
#AssignmentOpEx6.py--Only Integer Values
a,b=int(input("Enter Value of a:")),int(input("Enter Value of b:"))
print("-"*40)
print("\t\tOriginal Value of a={}".format(a))
print("\t\tOriginal Value of b={}".format(b))
print("-"*40)
#Logic-4 for Swapping
a=a^b
b=a^b
a=a^b
print("\t\tSwapped Value of a={}".format(a))
print("\t\tSwapped Value of b={}".format(b))
print("-"*40)
