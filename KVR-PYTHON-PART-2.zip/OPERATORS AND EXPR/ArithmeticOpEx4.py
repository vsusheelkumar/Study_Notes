#Program for Calculating Square Root of a given Number without using sqrt() of math module
#ArithmeticOpEx4.py
n=float(input("Enter a Number for Cal its square root:"))
res=n**0.5  # OR n**(1/2)
print("sqrt({})={}".format(n,res))
