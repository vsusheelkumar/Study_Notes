#Program for Calculating Square Root of a given Number by using sqrt() of math module
#ArithmeticOpEx3.py
import math
n=float(input("Enter a Number for Cal its square root:"))
res=math.sqrt(n)
print("sqrt({})={}".format(n,res))
