#Program for Swapping of Two Values by using Multi Line assginment Operator
#AssignmentOpEx2.py--Any Value type
a,b=input("Enter Value of a:"),input("Enter Value of b:")
print("-"*40)
print("\t\tOriginal Value of a={}".format(a))
print("\t\tOriginal Value of b={}".format(b))
print("-"*40)
#Logic-1 for Swapping
a,b=b,a # Multi line assignment
print("\t\tSwapped Value of a={}".format(a))
print("\t\tSwapped Value of b={}".format(b))
print("-"*40)
