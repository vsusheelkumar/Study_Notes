#Program for Demonstrating the Garbage Colletor with Destructor.
#DestEx1.py
class Employee:
	def __init__(self,eno,ename):  # Parameterized Constructor
		print("I am from Parameterized Constructor")
		self.eno=eno
		self.ename=ename
		print("\tEmp Number={}".format(self.eno))
		print("\tEmp Name={}".format(self.ename))
	def __del__(self): # Destructor Def--called by GC
		print("GC Calls __del__() for De-allocating Memory space of Objects")

#main Program
print("-------------------------------------------------------------------")
print("Program Execution Started")
print("-------------------------------------------------------------------")
eo1=Employee(10,"RS") # Object Creation--Makes the PVM to Call Parameterized Constructor
eo2=Employee(20,"TR") # Object Creation--Makes the PVM to Call Parameterized Constructor
eo3=Employee(30,"DR") # Object Creation--Makes the PVM to Call Parameterized Constructor
print("-------------------------------------------------------------------")
print("Program Execution Ended")
print("-------------------------------------------------------------------")
#NOTE: At this point of GC automatically Removes the Memory Space of Objects eo1,eo2 and eo3 (Automatic GC)