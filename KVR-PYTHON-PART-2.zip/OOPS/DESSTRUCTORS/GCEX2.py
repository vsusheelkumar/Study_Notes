#Program for Demonstrating the Garbage Colletor with Destructor.
#GCEX2.py
import sys,time,gc
class Employee:
	def __init__(self,eno,ename):  # Parameterized Constructor
		print("I am from Parameterized Constructor--Current Object ID:{}".format(id(self)))
		self.eno=eno
		self.ename=ename
		print("\tEmp Number={}".format(self.eno))
		print("\tEmp Name={}".format(self.ename))
	def __del__(self): # Destructor Def--called by GC
		print("GC Calls __del__() for De-allocating Memory space of Current Object:{}".format(id(self)))
		global totmem
		totmem=totmem-sys.getsizeof(self)
		print("\tNow Available Memory Space:{}".format(totmem))

#main Program
print("Initially, Is GC running=",gc.isenabled())
print("-------------------------------------------------------------------")
print("Program Execution Started")
print("-------------------------------------------------------------------")
eo1=Employee(10,"RS") # Object Creation--Makes the PVM to Call Parameterized Constructor
eo2=Employee(20,"TR") # Object Creation--Makes the PVM to Call Parameterized Constructor
eo3=Employee(30,"DR") # Object Creation--Makes the PVM to Call Parameterized Constructor
totmem=sys.getsizeof(eo1) + sys.getsizeof(eo2)+ sys.getsizeof(eo3) # 144
print("Initial Memory Sapce of all Objects =",totmem)
gc.disable()
print("Is GC running after disable()=",gc.isenabled())
print("-------------------------------------------------------------------")
print("Program Execution Ended")
print("-------------------------------------------------------------------")
time.sleep(5)
#NOTE: At this point of GC automatically Removes the Memory Space of Objects eo1,eo2 and eo3 (Automatic GC)