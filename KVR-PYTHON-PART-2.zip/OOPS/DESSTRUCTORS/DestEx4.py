#Program for Demonstrating the Garbage Colletor with Destructor.
#DestEx4.py
import sys,time
class Employee:
	def __init__(self,eno,ename):  # Parameterized Constructor
		print("I am from Parameterized Constructor")
		self.eno=eno
		self.ename=ename
		print("\tEmp Number={}".format(self.eno))
		print("\tEmp Name={}".format(self.ename))
	def __del__(self): # Destructor Def--called by GC
		print("GC Calls __del__() for De-allocating Memory space of Current Object")

#main Program
print("-------------------------------------------------------------------")
print("Program Execution Started")
print("-------------------------------------------------------------------")
eo1=Employee(10,"RS") # Object Creation--Makes the PVM to Call Parameterized Constructor
print("No Longer Interested in Maintaining the Memory Space of Object eo1")
time.sleep(5)
eo1=None # Forcefully GC Calls Destructor
time.sleep(5)
eo2=Employee(20,"TR") # Object Creation--Makes the PVM to Call Parameterized Constructor
print("No Longer Interested in Maintaining the Memory Space of Object eo2")
time.sleep(5)
eo2=None # Forcefully GC Calls Destructor
time.sleep(5)
eo3=Employee(30,"DR") # Object Creation--Makes the PVM to Call Parameterized Constructor
time.sleep(5)
eo3=None # Forcefully GC Calls Destructor
time.sleep(5)
print("-------------------------------------------------------------------")
print("Program Execution Ended")
print("-------------------------------------------------------------------")
