#GCEX1.py
import gc
print("Initially, Is GC running=",gc.isenabled())
print("-------------------------------------------------------------------")
print("Program Execution Started")
print("-------------------------------------------------------------------")
a=10
b=20
c=a+b
gc.disable()
print("Is GC running after disable()=",gc.isenabled())
print("Val of a=",a)
print("Val of b=",b)
print("Sum=",c)
gc.enable()
print("Is GC running after enable()=",gc.isenabled())
print("-------------------------------------------------------------------")
print("Program Execution Ended")
print("-------------------------------------------------------------------")