#program for Demonstrating Deafult Constructor
#DeafultConstEx.py
class Test:
    def __init__(self):
        print("i am from Defalut Constructor")
        self.a=1
        self.b=2
        print("\tVal of a={}".format(self.a))
        print("\tVal of b={}".format(self.b))

#Main Program
t1=Test() # Object Creation---PVM--Calls Defalut Constructor
t2=Test() # Object Creation
t3=Test() # Object Creation