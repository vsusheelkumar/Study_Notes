#ConstEx1.py
class Emp:
    def __init__(self): # Defalut OR Parameter-Less Constructor
        print("i am from Defalut Constructor")
        self.eno=100
        self.ename="RS"
        print("\tEmp Number={}".format(self.eno))
        print("\tEmp Name={}".format(self.ename))

#main Program
eo1=Emp() # Object Creation--PVM automatically / Implicitly calls Default Constructor
eo2=Emp() # Object Creation--PVM automatically / Implicitly calls Constructor
eo3=Emp() # Object Creation--PVM automatically / Implicitly calls Constructor