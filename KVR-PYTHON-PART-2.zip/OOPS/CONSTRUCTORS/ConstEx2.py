#ConstEx2.py
class Emp:
    def __init__(self,eno,name): # Parameterized Constructor
        print("i am from Parameterized Constructor")
        self.eno=eno
        self.ename=name
        print("\tEmp Number={}".format(self.eno))
        print("\tEmp Name={}".format(self.ename))
        print("------------------------------------")
        

#main Program
eo1=Emp(10,"RS") # Object Creation--PVM automatically / Implicitly calls Parameterized Constructor
eo2=Emp(20,"TR") # Object Creation--PVM automatically / Implicitly calls Constructor
eo3=Emp(30,"DR") # Object Creation--PVM automatically / Implicitly calls Constructor

