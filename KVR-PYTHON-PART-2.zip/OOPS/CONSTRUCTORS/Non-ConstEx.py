#Non-ConstEx.py
class Emp:
    def setempvals(self):
        self.eno=100
        self.ename="RS"

#main Program
eo=Emp() # Object Creation
print(eo.__dict__) # { }
eo.setempvals() # Calling the method explicitly
print(eo.__dict__) # {...... }
