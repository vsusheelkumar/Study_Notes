#program for Demonstrating Deafult and parameterized  Constructor
#DeafultParameterizedConstEx.py
class Test:
    def __init__(self,a=1,b=2):
        print("I am from Deafult / Parameterized Constructor")
        self.a=a
        self.b=b
        print("\tVal of a={}".format(self.a))
        print("\tVal of b={}".format(self.b))
#main Program
t1=Test() # Object Creation--PVM Calls---Default Constructor
t2=Test(10,20) # Object Creation--PVM Calls---Parameterized Constructor
t3=Test(100,200) # Object Creation--PVM Calls---Parameterized Constructor
t4=Test(1000,2000) # Object Creation--PVM Calls---Parameterized Constructor
t5=Test(500) # Object Creation--PVM Calls---Parameterized Constructor
t6=Test(b=600) # Object Creation--PVM Calls---Parameterized Constructor
