#OopsStudentPickEx.py
import pickle
from Student import Student
class StudentPick:
    def savestuddata(self):
        with open("stud.pick","ab") as fp:
            while(True):
                #read student Data and put it in student Object
                print("----------------------------------------")
                sno=int(input("Enter Student Number:"))
                name = input("Enter Student Name:")
                marks = float(input("Enter Student Marks:"))
                print("----------------------------------------")
                so=Student()
                so.getstudvalues(sno,name,marks)
                #Save so object data into the file
                pickle.dump(so,fp)
                print("Student Object Data Saved in File")
                print("----------------------------------------")
                ch=input("Do u want to Insert another record(yes/no):")
                if(ch.lower()=="no"):
                    print("Thx for using This Program")
                    break

#Main Program
sp=StudentPick()
sp.savestuddata()

