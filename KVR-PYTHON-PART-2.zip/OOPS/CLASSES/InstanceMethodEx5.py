#Program for storing Student Details such as sno,name and marks and Course
# for all student by using Classes and objects
#InstanceMethodEx5.py
class Student:
    def getstudvals(self,objinfo):
        print("------------------------------------------")
        print("Enter {} Object information".format(objinfo))
        self.sno=int(input("\tEnter Student Number:"))
        self.sname=input("\tEnter Student Name:")
        self.marks=float(input("\tEnter Student Marks:"))
        print("------------------------------------------")

    def dispstudvals(self,objinfo):
        print("----------------------------------")
        print("{} Object information".format(objinfo))
        print("\tStudent Number={}".format(self.sno))
        print("\tStudent Name={}".format(self.sname))
        print("\tStudent Marks={}".format(self.marks))
        print("----------------------------------")
#main Program
s1=Student() # Object Creation s1
s2=Student() # Object Creation s2
#read the values of s1 and display values of s1
s1.getstudvals("First")
s1.dispstudvals("First")
#read the values of s1 and display values of s2
s2.getstudvals("Second")
s2.dispstudvals("Second")