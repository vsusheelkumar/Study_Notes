#Program for storing Student Details such as sno,name and marks by using Classes and objects
#InstanceDataMembersEx2.py
class Student:pass

#main Program
s1=Student() # Object Creation s1
s2=Student() # Object Creation s2
print("Initial Content of s1=",s1.__dict__) # {}
print("Initial Content of s2=",s2.__dict__) # {}
print("Number of Values in s1 Object=",len(s1.__dict__))
print("Number of Values in s2 Object=",len(s2.__dict__))
print("ID of s1=",id(s1))
print("ID of s2=",id(s2))
print("-----------------------------------------")
#Place OR Store Student no,name and Marks in s1--Instance Data members--through an object
s1.sno=100
s1.name="Rossum"
s1.marks=34.56
#Place OR Store Student no,name and Marks in s2--Instance Data members--through an object
s2.sno=101
s2.name="Travis"
s2.marks=66.66
#Display OR Access the Instance Data members of s1 object
print("-----------------------------------------")
print("Object s1 Information")
print("-----------------------------------------")
print(s1.__dict__)
print("Number of Values in s1 Object=",len(s1.__dict__))
print("-----------------------------------------")
#Display OR Access the Instance Data members of s2 object
print("Object s2 Information")
print("-----------------------------------------")
print(s2.__dict__)
print("Number of Values in s2 Object=",len(s2.__dict__))
print("-----------------------------------------")

