#Program for storing Student Details such as sno,name and marks by using Classes and objects
#InstanceDataMembersEx1.py
class Student:pass

#main Program
s1=Student() # Object Creation s1
s2=Student() # Object Creation s2
print("ID of s1=",id(s1))
print("ID of s2=",id(s2))
print("-----------------------------------------")
#Place OR Store Student no,name and Marks in s1--Instance Data members--through an object
s1.sno=100
s1.name="Rossum"
s1.marks=34.56
#Place OR Store Student no,name and Marks in s2--Instance Data members--through an object
s2.sno=101
s2.name="Travis"
s2.marks=66.66
#Display OR Access the Instance Data members of s1 object
print("-----------------------------------------")
print("Object s1 Information")
print("-----------------------------------------")
print("\tStudent Number:{}".format(s1.sno))
print("\tStudent Name:{}".format(s1.name))
print("\tStudent Marks:{}".format(s1.marks))
print("-----------------------------------------")
#Display OR Access the Instance Data members of s2 object
print("Object s2 Information")
print("-----------------------------------------")
print("\tStudent Number:{}".format(s2.sno))
print("\tStudent Name:{}".format(s2.name))
print("\tStudent Marks:{}".format(s2.marks))
print("-----------------------------------------")

