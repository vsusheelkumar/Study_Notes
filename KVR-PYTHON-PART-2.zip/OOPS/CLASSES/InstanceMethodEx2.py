#Program for Demonstrating the Instance Method and self
#InstanceMethodEx2.py
class Test:
    def getvalues(self): # Instance Method
        print("----------------------------------")
        self.a=float(input("Enter First Value:"))
        self.b=float(input("Enter Second Value:"))
        print("----------------------------------")
    def dispvals(self):
        print("----------------------------------")
        print("\tVal of a={}".format(self.a))
        print("\tVal of b={}".format(self.b))
        print("----------------------------------")

#Main Program
t1=Test() # Object Creation
#Read the Intsance  Values by using Instance Method for Object t1
t1.getvalues() # Instance Method Call
t2=Test()
#Read the Intsance  Values by using Instance Method for Object t2
t2.getvalues() # Instance Method Call
#display the Values of t1 object by using Instance Method
t1.dispvals()
#display the Values of t2 object by using Instance Method
t2.dispvals()
