#OopsStudentUnPickEx.py
import pickle
class StudentUnPick:
    def readstuddata(self):
        try:
            with open("stud.pick","rb") as fp:
                print("----------------------------------------")
                while(True):
                    try:
                        obj=pickle.load(fp)
                        obj.dispstudvalues()
                    except EOFError:
                        print("----------------------------------------")
                        break
        except FileNotFoundError:
            print("File Does not Exist")

#main Program
sup=StudentUnPick()
sup.readstuddata()

