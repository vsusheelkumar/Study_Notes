#program for Demonstrating the need of Class Level Method
#ClassLevelMethodEx3.py
class Employee:
    @classmethod
    def getcompname(cls): # Class Level Method
        cls.compname="PSF" # OR Employee.compname="PSF"
    @classmethod
    def getcity(cls):
        cls.city="HYD" # OR Employee.city="HYD"

#Main Program
Employee.getcompname()
Employee.getcity() # Calling Class Level Methods w.r.t Class Name
print("Comp Name=",Employee.compname)
print("Comp City=",Employee.city)