#program for Demonstarting How to represent Class Level Data Members
#ClassLevelDataMembersEx1.py
class Student:
    crs="PYTHON" # here crs is called Class Level Data Member

#main Program
print("Student Course Name:",Student.crs) # accessing the Class Level Data members wrt class anme
print("------------OR---------------------")
s=Student()
print("First Student Course Name:",s.crs) # accessing the Class Level Data members wrt obejct anme