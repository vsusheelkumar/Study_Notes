#Program for Demonstrating the Instance Method and self
#InstanceMethodEx1.py
class Test:
    def getvalues(self):
        print("-----------------------------------")
        print("I am from Instance Method")
        print("ID Of Current Object=",id(self))
        print("-----------------------------------")

#Main Program
t1=Test() # Object Creation
print("Content of t1=",t1.__dict__)
print("Id of t1 in main Program=",id(t1))
t1.getvalues() # Method Call
t2=Test()
print("Content of t2=",t2.__dict__)
print("Id of t2 in main Program=",id(t2))
t2.getvalues() # Method Call
