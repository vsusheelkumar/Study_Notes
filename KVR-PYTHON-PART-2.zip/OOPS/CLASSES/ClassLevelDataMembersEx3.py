#program for Demonstarting How to represent Class Level Data Members
#ClassLevelDataMembersEx3.py
class Student:
    country="INDIA" # here country is called Class Level Data Member

#main Program
Student.crs="PYTHON" # here crs is called Class Level Data Member--Defined in Main Program
print("Student Course Name:",Student.crs) # accessing the Class Level Data members wrt class anme
print("Student Country Name:",Student.country) # accessing the Class Level Data members wrt class anme
print("------------OR---------------------")
s=Student()
print("First Student Course Name:",s.crs) # accessing the Class Level Data members wrt obejct anme
print("First Student Country Name:",s.country) # accessing the Class Level Data members wrt obejct anme