#OopsWithDataBaseCommEx1.py<---File Name and Module Name
import oracledb as orc
class Employee:
    @classmethod
    def getcompname(cls): # Class Level Method
        cls.compname="PSF" # OR Employee.compname="PSF"
        cls.getcity() # Calling Class Level Methods w.r.t cls
        #OR
        #Employee.getcity() # Calling Class Level Methods w.r.t Class Name
    @classmethod
    def getcity(cls):
        cls.city="HYD" # OR Employee.city="HYD"
    def getempvals(self):
        print("------------------------------------------")
        self.eno=int(input("\tEnter Employee Number:"))
        self.ename=input("\tEnter Employee Name:")
        self.sal=float(input("\tEnter Employee Salary:"))
        print("------------------------------------------")
    def saveempvals(self):
        self.getcompname() # calling Class Level Method
        self.getempvals() # calling Instance Method
        #PDBC Code
        try:
            con=orc.connect("system/tiger@localhost/orcl")
            cur=con.cursor()
            #Define the Query
            iq=("insert into empinfo values(%d,'%s',%f,'%s','%s')"
                %(self.eno,self.ename,self.sal,self.compname,self.city))
            cur.execute(iq)
            con.commit()
            print("{} Record Inserted".format(cur.rowcount))
        except orc.DatabaseError as db:
            print("Problem in Oracle DB:",db)


