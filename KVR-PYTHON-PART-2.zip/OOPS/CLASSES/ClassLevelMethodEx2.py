#program for Demonstrating the need of Class Level Method
#ClassLevelMethodEx2.py
class Employee:
    @classmethod
    def getcompname(cls): # Class Level Method
        cls.compname="PSF" # Employee.compname="PSF"

#Main Program
e1=Employee()
e1.getcompname() # Calling Class Level Method w.r.t Object name
print("Emp Comp Name=",e1.compname)
e2=Employee()
print("Emp Comp Name=",Employee.compname)

