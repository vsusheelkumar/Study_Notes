#program for Demonstrating the need of Class Level Method
#ClassLevelMethodEx4.py
class Employee:
    @classmethod
    def getcompname(cls): # Class Level Method
        cls.compname="PSF" # OR Employee.compname="PSF"
        cls.getcity() # Calling Class Level Methods w.r.t cls
        #OR
        #Employee.getcity() # Calling Class Level Methods w.r.t Class Name
    @classmethod
    def getcity(cls):
        cls.city="HYD" # OR Employee.city="HYD"

#Main Program
Employee.getcompname() # Calling Class Level Methods w.r.t Class Name
print("Comp Name=",Employee.compname)
print("Comp City=",Employee.city)