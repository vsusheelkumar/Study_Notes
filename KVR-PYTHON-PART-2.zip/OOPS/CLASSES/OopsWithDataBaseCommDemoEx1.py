#OopsWithDataBaseCommDemoEx1.py
from OopsWithDataBaseCommEx1 import Employee
e=Employee()
e.saveempvals()

