#program for Demonstrating the need of Class Level Method
#ClassLevelMethodEx1.py
class Employee:
    @classmethod
    def getcompname(cls): # Class Level Method
        cls.compname="PSF" # Employee.compname="PSF"

#Main Program
Employee.getcompname() # Calling Class Level Method w.r.t Class Name Name
print("Emp Comp Name=",Employee.compname)
print("--------------OR------------------")
e=Employee()
print("Emp Comp Name=",e.compname)
print("Emp Comp Name=",Employee.compname)
