#program for Demonstrating the need of Class Level Method
#ClassLevelMethodEx5.py
class Employee:
    @classmethod
    def getcompname(cls): # Class Level Method
        cls.compname="PSF" # OR Employee.compname="PSF"
        cls.getcity() # Calling Class Level Methods w.r.t cls
        #OR
        #Employee.getcity() # Calling Class Level Methods w.r.t Class Name
    @classmethod
    def getcity(cls):
        cls.city="HYD" # OR Employee.city="HYD"
    def getempvals(self,objinfo):
        print("------------------------------------------")
        print("Enter {} Object information".format(objinfo))
        self.eno=int(input("\tEnter Employee Number:"))
        self.ename=input("\tEnter Employee Name:")
        self.sal=float(input("\tEnter Employee Salary:"))
        print("------------------------------------------")
    def dispempvals(self,objinfo):
        print("----------------------------------")
        Employee.getcompname() # Calling Class Level Method w.r.t Class Name from Instance Method
        print("{} Object information".format(objinfo))
        print("\tEmployee Number={}".format(self.eno))
        print("\tEmployee Name={}".format(self.ename))
        print("\tEmployee Marks={}".format(self.sal))
        print("\tEMPLOYEE COMP NAME={}".format(Employee.compname))
        print("\tEMPLOYEE COMP CITY={}".format(Employee.city))
        print("----------------------------------")
#Main Program
#Create Two Employee Object
e1=Employee()
e2=Employee()
#Read the Values for e1 Object--Instance Data Members
e1.getempvals("First")# calling Instance Method w.r.t Object Name
#Read the Values for e2 Object--Instance Data Members
e2.getempvals("Second")# calling Instance Method w.r.t Object Name
#Display the Data of e1 Object
e1.dispempvals("First")