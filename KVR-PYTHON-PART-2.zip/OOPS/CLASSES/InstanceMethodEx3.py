#Program for Demonstrating the Instance Method and self
#InstanceMethodEx3.py
class Test:
    def getvalues(self,objinfo): # Instance Method
        print("----------------------------------")
        print("Enter {} Object Information".format(objinfo))
        self.a=float(input("\tEnter First Value:"))
        self.b=float(input("\tEnter Second Value:"))
        print("----------------------------------")
    def dispvals(self,objinfo):
        print("----------------------------------")
        print("{} Object information".format(objinfo))
        print("\tVal of a={}".format(self.a))
        print("\tVal of b={}".format(self.b))
        print("----------------------------------")
#Main Program
t1=Test() # Object Creation
#Read the Intsance  Values by using Instance Method for Object t1
t1.getvalues("First") # Instance Method Call
t2=Test()
#Read the Intsance  Values by using Instance Method for Object t2
t2.getvalues("Second") # Instance Method Call
#display the Values of t1 object by using Instance Method
t1.dispvals("First")
#display the Values of t2 object by using Instance Method
t2.dispvals("Second")
