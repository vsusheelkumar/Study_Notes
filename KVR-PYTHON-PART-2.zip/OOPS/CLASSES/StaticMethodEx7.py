#Program for Performing App Arithmetic Operations by using Static Methods
class Arithmetic:
    def getvalswithsymbol(self):
        self.a=float(input("Enter First value:"))
        self.b = float(input("Enter Second value:"))
        self.op = input("Enter Any Arithmetic Operator:")
class Calculator:
    @staticmethod
    def arithmeticop(ao):
        match(ao.__dict__.get('op')):
            case "+":
                a,b=ao.__dict__['a'],ao.__dict__['b']
                print("Sum({},{})={}".format(a,b,a+b))
            case "-":
                a, b = ao.__dict__.get('a'), ao.__dict__.get('b')
                print("Sub({},{})={}".format(a, b, a - b))
            case "*":
                print("Sub({},{})={}".format(ao.__dict__.get('a'), ao.__dict__.get('b'),
                                             ao.__dict__.get('a')* ao.__dict__.get('b')))
            case "/":
                print("Div({},{})={}".format(ao.__dict__.get('a'), ao.__dict__.get('b'),
                                             ao.__dict__.get('a') / ao.__dict__.get('b')))
            case "//":
                print("FloorDiv({},{})={}".format(ao.__dict__.get('a'), ao.__dict__.get('b'),
                                             ao.__dict__.get('a') // ao.__dict__.get('b')))
            case "%":
                print("Mod({},{})={}".format(ao.__dict__.get('a'), ao.__dict__.get('b'),
                                             ao.__dict__.get('a') % ao.__dict__.get('b')))
            case "**":
                print("Pow({},{})={}".format(ao.__dict__.get('a'), ao.__dict__.get('b'),
                                             ao.__dict__.get('a') ** ao.__dict__.get('b')))
            case _:
                print("Inavlid Arithmetic Operator-try again")
#Main Program
ao=Arithmetic()
ao.getvalswithsymbol()
Calculator.arithmeticop(ao)
