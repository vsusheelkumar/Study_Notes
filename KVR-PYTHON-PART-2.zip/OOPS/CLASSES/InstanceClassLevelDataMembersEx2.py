#Program for storing Student Details such as sno,name and marks and Course
# for all student by using Classes and objects
#InstanceClassLevelDataMembersEx2.py
class Student:
    crs="PYTHON" # Here crs is called Class Level Data member

#main Program
s1=Student() # Object Creation s1
s2=Student() # Object Creation s2
#Place OR Store Student no,name and Marks in s1--Instance Data members--through an object
s1.sno=100
s1.name="Rossum"
s1.marks=34.56
#Place OR Store Student no,name and Marks in s2--Instance Data members--through an object
s2.sno=101
s2.name="Travis"
s2.marks=66.66
#Display OR Access the Instance Data members of s1 object
print("-----------------------------------------")
print("Object s1 Information")
print("-----------------------------------------")
print("\tStudent Number:{}".format(s1.sno))
print("\tStudent Name:{}".format(s1.name))
print("\tStudent Marks:{}".format(s1.marks))# Accessing the Instance DM by using Object name
print("\tStudent Course:{}".format(s1.crs)) # Accessing the Class Level DM by using Object name
print("-----------------------------------------")
#Display OR Access the Instance Data members of s2 object
print("Object s2 Information")
print("-----------------------------------------")
print("\tStudent Number:{}".format(s2.sno))
print("\tStudent Name:{}".format(s2.name))
print("\tStudent Marks:{}".format(s2.marks))
print("\tStudent Course:{}".format(s2.crs))
print("-----------------------------------------")

