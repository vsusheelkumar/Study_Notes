#Student.py<---File Name and Module Name
class Student:
    def getstudvalues(self,sno,sname,marks):
        self.sno=sno
        self.name=sname
        self.marks=marks
    def dispstudvalues(self):
        print("\t{}\t{}\t{}".format(self.sno,self.name,self.marks))