#program for Demonstrating the need of Static Methods
#StaticMethodEx5.py
class Student:
    def getStudVals(self):
        print("-------------------------------------")
        self.sno=int(input("Enter Student Number:"))
        self.sname = input("Enter Student Name:")
        self.marks = float(input("Enter Student Marks:"))
class Employee:
    def getEmpVals(self):
        print("-------------------------------------")
        self.eno=int(input("Enter Employee Number:"))
        self.ename = input("Enter Employee Name:")
class Teacher:
    def getTeacherVals(self):
        print("-------------------------------------")
        self.tno=int(input("Enter Teacher Number:"))
        self.tname = input("Enter Teacher Name:")
        self.sub = input("Enter Student Subject:")
        self.exp = int(input("Enter Teacher Exp:"))
class HYD:
    @classmethod
    def getObjectData(cls,objdata,objinfo):
        cls.dispObjectData(objdata,objinfo) #One Class Level Method Calling another Static Method
    @staticmethod
    def dispObjectData(objdata,objinfo):
        print("----------------------------------")
        print("{} Object Information".format(objinfo))
        print("----------------------------------")
        for dmn,dmv in objdata.__dict__.items():
            print("\t{}-->{}".format(dmn,dmv))
        print("----------------------------------")

#Main Program
s=Student() # Object Creation of Student Class
e=Employee() # Object Creation of Employee Class
t=Teacher() # Object Creation of Teacher Class
s.getStudVals()
e.getEmpVals()
t.getTeacherVals()
#Display all the above Objects Data by using Static Method
HYD.getObjectData(s,"Student") # Calling Class Lavel Method w.r.t Class Name
HYD.getObjectData(e,"Employee")
HYD.getObjectData(t,"Teacher")