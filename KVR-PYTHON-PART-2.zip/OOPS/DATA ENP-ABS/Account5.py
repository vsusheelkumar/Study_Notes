#Program for Demonstrating the need of Data Encapsulation
#Account5.py<----File Name and Module Name
class __Account: # Here Class Name made as Encapsulated
    def __init__(self):
        self.acno=100
        self.cname="Rossum"
        self.bal=4.5
        self.pin=3456
        self.bname="SBI"

