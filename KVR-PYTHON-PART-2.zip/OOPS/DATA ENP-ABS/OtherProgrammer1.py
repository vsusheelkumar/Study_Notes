#Program Demonstrates Data Abstraction.
#OtherProgrammer1.py<---Program
from Account1 import Account
ac=Account() # Object Creation
print("-"*50)
#print("Account Number=",ac.acno)
print("Customer Name=",ac.cname)
#print("Customer Bal=",ac.bal)
#print("Customer PIN=",ac.pin)
print("Customer Branch=",ac.bname)
print("-"*50)