#Program for Demonstrating the need of Data Encapsulation
#Account2.py<----File Name and Module Name
class Account:
    def getaccdetails(self):
        self.__acno=100
        self.cname="Rossum"
        self.__bal=4.5
        self.__pin=3456
        self.bname="SBI"

