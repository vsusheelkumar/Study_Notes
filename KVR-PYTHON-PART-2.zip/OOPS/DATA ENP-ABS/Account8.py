#Account8.py<--File Name and Module Name
__acno=100
cname="Rossum"
__bal=3.4