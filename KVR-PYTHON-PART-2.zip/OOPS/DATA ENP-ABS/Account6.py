#Program for Demonstrating the need of Data Encapsulation
#Account6.py
class Account:
    def __init__(self):
        self.__acno=100
        self.cname="Rossum"
        self.__bal=4.5
        self.__pin=3456
        self.bname="SBI"
    def accessaccdet(self):
        print("I am inside of Account Class--accessaccdet")
        print("Account Number=",self.__acno)
        print("Customer Name=", self.cname)
        print("Customer Bal=",self.__bal)
        print("Customer PIN=",self.__pin)
        print("Customer Branch=", ac.bname)


#Main Program
print("I am from Main Program")
ac=Account()
print("-"*50)
print("Account Number=",ac.acno)
print("Customer Name=",ac.cname)
#print("Customer Bal=",ac.bal)
#print("Customer PIN=",ac.pin)
print("Customer Branch=",ac.bname)
print("-"*50)
ac.accessaccdet()