#Program Demonstrates Data Abstraction.
#OtherProgrammer5.py<---Program
from Account5 import Account
#This Program will not execute bcoz Account class made as Encapsulated
#ImportError: cannot import name 'Account' from 'Account5'
ac=Account() # Object Creation
