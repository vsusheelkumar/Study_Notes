#Program Demonstrates Data Abstraction.
#OtherProgrammer3.py<---Program
from Account3 import Account
ac=Account() # Object Creation
#ac.getaccdetails()
print("-"*50)
"""print("Account Number=",ac.acno)
print("Customer Name=",ac.cname)
print("Customer Bal=",ac.bal)
print("Customer PIN=",ac.pin)
print("Customer Branch=",ac.bname)"""
print("-"*50)