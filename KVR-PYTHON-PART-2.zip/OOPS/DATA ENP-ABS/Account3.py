#Program for Demonstrating the need of Data Encapsulation
#Account3.py<----File Name and Module Name
class Account:
    def __getaccdetails(self):
        self.acno=100
        self.cname="Rossum"
        self.bal=4.5
        self.pin=3456
        self.bname="SBI"

