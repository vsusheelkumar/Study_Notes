#Program for Demonstrating the need of Data Encapsulation
#Account1.py<----File Name and Module Name
class Account:
    def __init__(self):
        self.__acno=100
        self.cname="Rossum"
        self.__bal=4.5
        self.__pin=3456
        self.bname="SBI"

