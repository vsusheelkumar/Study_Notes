#Program for Demonstrating the need of Data Encapsulation
#Account4.py<----File Name and Module Name
class Account:
    def ______init__(self): # It is Not Possible to encapsulate constructors
        self.acno=100
        self.cname="Rossum"
        self.bal=4.5
        self.pin=3456
        self.bname="SBI"

