#Program for Demonstrating the need of Data Encapsulation
#Account7.py
class Account:
    def __setaccdet(self):
        self.__acno=100
        self.cname="Rossum"
        self.__bal=4.5
        self.__pin=3456
        self.bname="SBI"
        print("Account Number=", self.__acno)
        print("Customer Name=", self.cname)
        print("Customer Bal=", self.__bal)
        print("Customer PIN=", self.__pin)
        print("Customer Branch=", ac.bname)
    def accessaccdet(self):
        self.__setaccdet() # Calling Encapsulated Instance Method

#Main Program
ac=Account()
#ac.__setaccdet()----gives AttributeError
ac.accessaccdet()