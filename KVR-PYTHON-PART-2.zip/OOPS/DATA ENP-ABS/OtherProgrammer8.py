from Account8 import *
#print("Account Number=",acno)
print("Account Holder Name=",cname)
#print("Account Bal=",bal)