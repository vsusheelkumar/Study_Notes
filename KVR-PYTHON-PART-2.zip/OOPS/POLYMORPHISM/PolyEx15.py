#PolyEx15.py
class Circle:
    def __init__(self,r): # Parameterized Constructor
        self.ac=3.14*r**2
        print("Area of Circle={}".format(self.ac))
        print("---------------------------------------")
class Square(Circle):
    def __init__(self,s): # Overridden Constructor
        self.sa=s**2
        print("Area of Square={}".format(self.sa))
        print("---------------------------------------")

class Rect(Square):
    def __init__(self,L,B):# Overridden Constructor
        self.ra=L*B
        print("Area of Rect={}".format(self.ra))
        print("---------------------------------------")
        Circle.__init__(self,float(input("Enter Radius:")))
        Square.__init__(self,float(input("Enter Side Value:")))
#main Program
L=float(input("Enter Length:"))
B=float(input("Enter Breadth:"))
ro=Rect(L,B) # Object Creation--Makes the PVM to call Parameterized Const.

