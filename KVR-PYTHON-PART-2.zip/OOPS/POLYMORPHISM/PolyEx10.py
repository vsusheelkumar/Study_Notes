#PolyEx10.py
class C1:
    def __init__(self): # Original Constructor
        print("C1-- __init__()--Deafult Constructor")
class C2:
    def __init__(self): # Original Constructor
        print("C2-- __init__()--Deafult Constructor")
class C3(C1,C2):
    def __init__(self): # Overridden Constructor
        print("C3-- __init__()--Deafult Constructor")
        C1.__init__(self)
        C2.__init__(self)

#Main Program
print("w.r.t C3 Class")
o3=C3() # Object Creation--Makes the PVM to Call Deafult Constructor