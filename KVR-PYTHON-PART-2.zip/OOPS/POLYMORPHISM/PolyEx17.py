#PolyEx16.py
class Circle:
    def __init__(self,r): # Original Parameterized Constructor
        self.ac=3.14*r**2
        print("Area of Circle={}".format(self.ac))
        print("---------------------------------------")
class Square: # Original Parameterized Constructor
    def __init__(self,s): # Overridden Constructor
        self.sa=s**2
        print("Area of Square={}".format(self.sa))
        print("---------------------------------------")
class Rect(Square,Circle):
    def __init__(self,s=0):pass

    def area(self,L,B):# Method
        self.ra=L*B
        print("Area of Rect={}".format(self.ra))
        print("---------------------------------------")
        Circle.__init__(self, float(input("Enter Radius:")))
        Square.__init__(self, float(input("Enter Side Value:")))
#main Program
L=float(input("Enter Length:"))
B=float(input("Enter Breadth:"))
ro=Rect() # Object Creation--Makes the PVM to call Parameterized Const.


