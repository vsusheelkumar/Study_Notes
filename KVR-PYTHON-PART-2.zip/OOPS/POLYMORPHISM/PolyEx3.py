# program for Demionstrating the Need of Polymorphism
# PolyEx3.py
class Circle(object):
    def draw(self):  # Original Method
        print("Drawing--Circle")
class Rect(Circle):
    def draw(self):  # Overridden Method
        print("Drawing--Rect")
class Square(Rect):
    def draw(self):# Overridden Method
        print("Drawing Square")
        Circle.draw(self) # Calling Top Most Super Class Method
        # from Bottom Most Derived Class w.r.t Class Name Approach
        Rect.draw(self) # Calling  Super Class Method
        # from Bottom Most Derived Class w.r.t Class Name Approach

# main Program
print("w.r.t Square Class")
s=Square()
s.draw()