#program for Demionstrating the Need of Polymorphism
#PolyEx1.py
class Circle:
    def draw(self):#Original Method
        print("Drawing--Circle")
        
class Rect(Circle):
    def draw(self): # Method Overriding
        print("Drawing--Rect")
        super().draw() #Call Super Class draw() from Derived Class draw()

#main Program
print("w.r.t Rect Class")
r=Rect()
r.draw()