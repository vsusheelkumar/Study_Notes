#PolyEx13.py
class Circle:
    def area(self,r): # Original Method
        self.ac=3.14*r**2
        print("Area of Circle={}".format(self.ac))
        print("---------------------------------------")
class Square:
    def area(self,s): # Original Method
        self.sa=s**2
        print("Area of Square={}".format(self.sa))
        print("---------------------------------------")
class Rect(Circle,Square):
    def area(self,L,B):# Overridden Method
        self.ra=L*B
        print("Area of Rect={}".format(self.ra))
        print("---------------------------------------")
        super().area(float(input("Enter Radius:")))
        Square.area(self,float(input("Enter Side:")))

#main Program
ro=Rect()
L=float(input("Enter Length:"))
B=float(input("Enter Breadth:"))
ro.area(L,B) # Method Call