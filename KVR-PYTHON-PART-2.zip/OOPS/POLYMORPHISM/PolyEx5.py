# program for Demionstrating the Need of Polymorphism
# PolyEx4.py
class Circle(object):
    def draw(self):  # Original Method
        print("Drawing--Circle")
class Rect(Circle):
    def draw(self):  # Orginal Method
        print("Drawing--Rect")
        super().draw()
class Square(Circle):
    def draw(self):  # Overridden Method
        print("Drawing--Square")
        super().draw()

# main Program
print("w.r.t Square Class--One Derived Class")
s=Square()
s.draw()
print("-----------------------------------------")
print("w.r.t Rect Class--One Derived Class")
r=Rect()
r.draw()
