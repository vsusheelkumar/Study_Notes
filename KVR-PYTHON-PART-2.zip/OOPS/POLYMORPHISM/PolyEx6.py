#PolyEx6.py
class C1:
    def __init__(self): # Original Constructor
        print("C1-- __init__()--Deafult Constructor")

class C2(C1):
    def __init__(self): # Overridden Constructor
        print("C2-- __init__()--Deafult Constructor")
        super().__init__() # Calling Base Class Constructor from Derived Class

#Main Program
print("w.r.t C2 Class")
o2=C2() # Object Creation--Makes the PVM to Call Deafult Constructor