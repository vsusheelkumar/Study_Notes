# program for Demionstrating the Need of Polymorphism
# PolyEx2.py
class Circle(object):
    def draw(self):  # Original Method
        print("Drawing--Circle")
class Rect(Circle):
    def draw(self):  # Overridden Method
        print("Drawing--Rect")
        super().draw() # Calling Super class method from Derived Class
class Square(Rect):
    def draw(self):# Overridden Method
        print("Drawing Square")
        super().draw() # Calling Super class method from Derived Class

# main Program
print("w.r.t Square Class")
s=Square()
s.draw()