#InhProg9.py
class GrandParent:
    def getGrandParentProp(self):
        gpp=float(input("Enter Grand Parent Property:"))
        return gpp
class Parent(GrandParent):
    def getParentProp(self):
        pp=float(input("Enter Parent Property:"))
        return pp
class Child(Parent):
    def getChildProperty(self):
        cp = float(input("Enter Child Property:"))
        return cp
    def calTotalProp(self):
        gp=self.getGrandParentProp()
        pp=self.getParentProp()
        cp=self.getChildProperty()
        tp=gp+pp+cp
        print("Grand Parent Property={}".format(gp))
        print("Parent Property={}".format(pp))
        print("Child Property={}".format(cp))
        print("Total Property={}".format(tp))

#Main Program
co=Child()
print(co.__dict__)
co.calTotalProp()
print(co.__dict__)
