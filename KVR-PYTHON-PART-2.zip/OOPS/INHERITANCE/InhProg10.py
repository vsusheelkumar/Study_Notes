#InhProg10.py
class GrandParent:
    def getGrandParentProp(self):
        self.gpp=float(input("Enter Grand Parent Property:"))
        return self.gpp
class Parent:
    def getParentProp(self):
        self.pp=float(input("Enter Parent Property:"))
        return self.pp
class Child(GrandParent,Parent):
    def getChildProperty(self):
        self.cp = float(input("Enter Child Property:"))
        return self.cp

    def calTotalProp(self):
        gp = self.getGrandParentProp()
        pp = self.getParentProp()
        cp = self.getChildProperty()
        tp = gp + pp + cp
        print("Grand Parent Property={}".format(gp))
        print("Parent Property={}".format(pp))
        print("Child Property={}".format(cp))
        print("Total Property={}".format(tp))


#Main Program
co=Child()
co.calTotalProp()
