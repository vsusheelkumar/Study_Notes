#InhProg11.py
import oracledb as orc
class Univ:
    def getUnivDet(self):
        self.uname=input("Enter Univeristy Name:")
        self.uloc = input("Enter Univeristy Location:")
    def dispUnivDet(self):
        print("----------------------------------------")
        print("University Name:{}".format(self.uname))
        print("University Location:{}".format(self.uloc))
        print("----------------------------------------")

class College(Univ):
    def getCollDet(self):
        self.cname = input("Enter College Name:")
        self.cloc = input("Enter College Location:")
    def dispCollDet(self):
        print("----------------------------------------")
        print("Colege Name:{}".format(self.cname))
        print("Colege Location:{}".format(self.cloc))
        print("----------------------------------------")
class Student(College):
    def getStudDet(self):
        self.sno = int(input("Enter Student Number:"))
        self.sname = input("Enter Student Name:")
        self.crs = input("Enter Student Course:")
    def dispStudDet(self):
        print("----------------------------------------")
        print("Student Number:{}".format(self.sno))
        print("Student Name:{}".format(self.sname))
        print("Student Course:{}".format(self.crs))
        print("----------------------------------------")
    def savestuddata(self):
        try:
            con=orc.connect("system/tiger@localhost/orcl")
            cur=con.cursor()
            iq="insert into studentres values(%d,'%s','%s','%s','%s','%s','%s')"
            cur.execute(iq %(self.sno,self.sname,self.crs,self.cname,self.cloc,self.uname,self.uloc))
            con.commit()
            print("{} Record Inserted".format(cur.rowcount))
        except orc.DatabaseError as db:
            print("Probem in Oracle DB:",db)

#Main Program
so=Student()
so.getStudDet()
so.getCollDet()
so.getUnivDet()
so.dispUnivDet()
so.dispCollDet()
so.dispStudDet()
so.savestuddata()