#Program for Generating Odd Numbers and Even Numbers Separately by using Multiple Threads
#EvenOddOopEx2.py
import threading,time
class Odd:
	def odd(self,n):
		if(n<=0):
			print("{}-->{} is Invalid Value".format(threading.current_thread().name,n))
		else:
			for i in range(1,n+1,2):
				print("{}--->Odd Number:{}".format(threading.current_thread().name,i))
				time.sleep(0.5)
class Even:
	def even(self,n):
			if(n<=0):
				print("{}-->{} is Invalid Value".format(threading.current_thread().name,n))
			else:
				for i in range(2,n+1,2):
					print("{}--->Even Number:{}".format(threading.current_thread().name,i))
					time.sleep(0.5)

#Main Program
noodd=int(input("Enter How Many Odd Numbers u want:"))
noeven=int(input("Enter How Many Even Numbers u want:"))
#Create Two Sub Threads
ot=threading.Thread(target=Odd().odd,args=(noodd,))
et=threading.Thread(target=Even().even,args=(noeven,))
#Dispath the sub threads
ot.start()
et.start()
