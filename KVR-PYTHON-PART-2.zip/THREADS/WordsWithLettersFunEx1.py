#Program for accepting a Line of Text and Display the words after each every second and also display Letters of Words after each and every Second with threads
#WordsWithLettersFunEx1.py
import threading , time
def wordswithletters(line):
	if(line.isspace() or len(line)==0):
		print("\tU Must Enter Line of Text:")
	else:
		words=line.split()
		for word in words:
			print("\t{}".format(word))
			time.sleep(1)
			for ch in word:
				print("\t\t{}".format(ch))
				time.sleep(0.25)
	
#Main Program
line=input("Enter a Line of Text:")
t1=threading.Thread(target=wordswithletters,args=(line,))
t1.start()

