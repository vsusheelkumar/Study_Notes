#DefaultThreadFlow.py
import threading
def hello():
	print("Line-2:hello() executed by:",threading.current_thread().name)
def hi():
	print("Line-5:hi() executed by:",threading.current_thread().name)
def welcome():
	print("Line:7:welome() executed by:",threading.current_thread().name)
#Main Program
print("-"*50)
print("Program Execution Started:",threading.current_thread().name)
print("-"*50)
print("Line-12")
hello()
print("Line-14")
hi()
print("Line-16")
welcome()
print("-"*50)
print("Program Execution Ended:",threading.current_thread().name)
print("-"*50)

