#SubThreadsWithMainThreadFlow.py
import threading,time
def hello():
	print("Line-2:hello() executed by:",threading.current_thread().name) # Thread-1
	time.sleep(3)
def hi():
	print("Line-5:hi() executed by:",threading.current_thread().name) # Thread-2
	time.sleep(3)
def welcome():
	print("Line:7:welome() executed by:",threading.current_thread().name) # Thread-3
	time.sleep(3)

#Main Program
print("-"*50)
print("Program Execution Started:",threading.current_thread().name) # MainThread
print("Initially, Number of theads in Python Program=",threading.active_count())
print("-"*50)
#create sub thread 1 for executing hello()
t1=threading.Thread(target=hello) # here t1 is sub thread object whose name is Thread-1
t1.name="RS"
#create sub thread 2 for executing hi()
t2=threading.Thread(target=hi) # here t2 is sub thread object whose name is Thread-2
t2.name="TR"
#create sub thread 3 for executing welcome()
t3=threading.Thread(target=welcome) # here t3 is sub thread object whose name is Thread-3
t3.name="KV"
#Dispatch the sub threads by using start() of Thread class
t1.start()
t2.start()
t3.start()
print("Now Number of theads in Python Program=",threading.active_count())
t1.join()
t2.join()
t3.join()
print("Program Execution Ended:",threading.current_thread().name)  #MainThread
print("At End, Number of theads in Python Program=",threading.active_count())
print("-"*50)

