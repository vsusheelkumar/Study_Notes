#Program for Generating 1 to N Number after each and every second where N is +Ve by using threads
#NumGenOopEx2.py
import threading,time
class Numbers:
	def __init__(self,n):
		self.n=n
	def generate(self):
		if(self.n<=0):
			print("{}--->{} Invalid input".format(threading.current_thread().name,self.n))
		else:
			print("-"*50)
			print("Numbers within {}".format(self.n))
			print("-"*50)
			for i in range(1,self.n+1):
				print("{}--->Value of i={}".format(threading.current_thread().name,i))
				time.sleep(0.25)
			print("-"*50)
#Main Program
n=int(input("Enter How Many Numbers u want to Generate:"))
#create a sub thread
no=Numbers(n)#Object Creation--Makes the PVM to Call Parameterized Constructor
t1=threading.Thread(target=no.generate)
#set User-Friendly Name to the thread
t1.name="RS"
#dispatch the sub thread
t1.start()
