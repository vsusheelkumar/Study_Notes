#Program for Demonstrating the start() and is_alive()
#SatrtIsAliveEx.py
import threading
def  welcome(sname):
	print("Sub Thread Name={}".format(threading.current_thread().name))
	print("Hi:{}, Good Morning".format(sname))

#Main Program
t=threading.Thread(target=welcome,args=("RS",))
print("Execution Status of t before start=",t.is_alive())
t.start()
print("Execution Status of t after start=",t.is_alive())