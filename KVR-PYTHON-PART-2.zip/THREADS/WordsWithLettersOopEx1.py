#Program for accepting a Line of Text and Display the words after each every second and also display Letters of Words after each and every Second with threads
#WordsWithLettersOopEx1.py
import threading , time
class Words:
	def __init__(self,line):
		self.line=line
	def wordswithletters(self):
		if(self.line.isspace() or len(self.line)==0):
			print("\tU Must Enter Line of Text:")
		else:
			words=self.line.split()
			for word in words:
				print("\t{}".format(word))
				time.sleep(1)
				for ch in word:
					print("\t\t{}".format(ch))
					time.sleep(0.25)
				print("\t\tNumber Letters=",len(word))
				print("-"*50)
	
#Main Program
line=input("Enter a Line of Text:")
t1=threading.Thread(target=Words(line).wordswithletters)
t1.start()

