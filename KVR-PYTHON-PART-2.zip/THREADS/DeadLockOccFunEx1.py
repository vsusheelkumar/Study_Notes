#Program for Demonstrating the Dead Lock Occurence
#DeadLockOccFunEx1.py
import threading,time
def table(n):
	if(n<=0):
		print("\t{}--->{} is invalid Input".format(threading.current_thread().name,n))
	else:
		for i in range(1,11):
			print("\t{}-->{} x {} = {}".format(threading.current_thread().name,n,i,n*i))
			time.sleep(0.5)
		print("-------------------------------------------------------")
		
#Main Program
t1=threading.Thread(target=table,args=(9,))
t2=threading.Thread(target=table,args=(19,))
t3=threading.Thread(target=table,args=(8,))
t4=threading.Thread(target=table,args=(18,))
#dispatch the sub threads
t1.start()
t2.start()
t3.start()
t4.start()