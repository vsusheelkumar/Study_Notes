#DefaultThreadNameEx1.py
import threading
print("Default Name of Thread=",threading.current_thread().name)
print("Number of threads in Python Program=",threading.active_count())