#Program for Generating Squares,Cubes and Squareroots for List of Values  Separately by using Multiple Threads
#SqrtSqrCubeOopsEx2.py
import threading,time
class  Squareroots:
	def squareroots(self,lst):
		for val in lst:
			print("\t{}-->sqrt({})={}".format(threading.current_thread().name,val,val**0.5))
			time.sleep(0.5)
class Squares:
	def squares(self,lst):
			for val in lst:
				print("\t{}-->sqr({})={}".format(threading.current_thread().name,val,val**2))
				time.sleep(0.5)
class Cubes:
	def cubes(self,lst):
			for val in lst:
				print("\t{}-->cube({})={}".format(threading.current_thread().name,val,val**3))
				time.sleep(0.5)

#Main Threads
#Accept the List of Values
print("Enter List of Values Separated  By Space:")
lst=list(filter(lambda val: val>=0, list(map(float, input().split()))))
#create 3 Sub Threads
sqrtt=threading.Thread(target=Squareroots().squareroots,args=(lst,))
sqrt1=threading.Thread(target=Squares().squares,args=(lst,))
cbt=threading.Thread(target=Cubes().cubes,args=(lst,))
#disppatch the sub threads
sqrtt.start()
sqrt1.start()
cbt.start()
