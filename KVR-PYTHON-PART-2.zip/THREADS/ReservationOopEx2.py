#ReservationOopEx2.py
import threading,time
class Train:
	def  __init__(self,nos):
		self.nos=nos
	def   reservation(self):
		K.acquire()
		global totseats
		if(self.nos>totseats):
			print("\tHi {}, {} Seats are not available-Try next ".format(threading.current_thread().name,self.nos))
			time.sleep(2)
		else:
			totseats=totseats-self.nos
			print("\tHi {}, {} Seats are Reserved-Hpy Jrny ".format(threading.current_thread().name,self.nos))
			time.sleep(2)
			print("\tNow Available Seats=",totseats)
		K.release()
#main program
totseats=12 # here totseats  global Variable
K=threading.Lock()

p1=threading.Thread(target=Train(5).reservation)
p1.name="Rossum"
p2=threading.Thread(target=Train(8).reservation)
p2.name="Travis"
p3=threading.Thread(target=Train(4).reservation)
p3.name="Ritche"
p4=threading.Thread(target=Train(3).reservation)
p4.name="Hunter"
p5=threading.Thread(target=Train(2).reservation)
p5.name="KVR"
#dispatch the threads
p1.start()
p2.start()
p3.start()
p4.start()
p5.start()