#SubThreadsFlowWithTime.py
import time,threading
def square(lst):
	for val in lst:
		print("{}-->Square({})={}".format(threading.current_thread().name,val,val**2))
		time.sleep(1)
def cubes(lst):
	for val in lst:
		print("{}-->cube({})={}".format(threading.current_thread().name,val,val**3))
		time.sleep(1)

#Main Program
bt=time.time()
print("-"*50)
print("Program Execution Started:",threading.current_thread().name)
print("-"*50)
lst=[12,4,16,7,19,-14,23,17,22]
#Create  a sub thread for executing square Function
t1=threading.Thread(target=square,args=(lst,) )
#Create  a sub thread for executing cubes Function
t2=threading.Thread(target=cubes,args=(lst,) )
#dispatch the sub threads
t1.start()
t2.start()
t1.join()
t2.join()
print("-"*50)
print("Program Execution Ended:",threading.current_thread().name)
print("-"*50)
et=time.time()
print("Total Execution of Default Thread Flow Program=",(et-bt))
