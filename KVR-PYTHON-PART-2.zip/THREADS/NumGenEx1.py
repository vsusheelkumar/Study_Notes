#Program for Generating 1 to N Number after each and every second where N is +Ve by using threads
#NumGenFunEx1.py
import threading,time
def generate(n):
	if(n<=0):
		print("{}--->{} Invalid input".format(threading.current_thread().name,n))
	else:
		print("-"*50)
		print("Numbers within {}".format(n))
		print("-"*50)
		for i in range(1,n+1):
			print("{}--->Value of i={}".format(threading.current_thread().name,i))
			time.sleep(1)
		print("-"*50)
#Main Program
n=int(input("Enter How Many Numbers u want to Generate:"))
#create a sub thread
t1=threading.Thread(target=generate,args=(n,))
#set User-Friendly Name to the thread
t1.name="RS"
#dispatch the sub thread
t1.start()
