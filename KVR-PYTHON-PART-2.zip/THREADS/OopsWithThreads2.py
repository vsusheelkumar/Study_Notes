#OopsWithThreads2.py
import threading,time
class Sample:
	def hello(self):
		print("Line-2:hello() executed by:",threading.current_thread().name) # Thread-1
		time.sleep(3)
		print("{} came out-off sleep".format(threading.current_thread().name))
	def hi(self):
		print("Line-5:hi() executed by:",threading.current_thread().name) # Thread-2
		time.sleep(3)
		print("{} came out-off sleep".format(threading.current_thread().name))
	def welcome(self):
		print("Line:7:welome() executed by:",threading.current_thread().name) # Thread-3
		time.sleep(3)
		print("{} came out-off sleep".format(threading.current_thread().name))

#Main Program
print("Program execution Started by :{}".format(threading.current_thread().name))
print("---------------------------------------------------------------------------------")
#Create  3 Sub Threads for executing 3 Functions
t1=threading.Thread(target=Sample().hello)
t2=threading.Thread(target=Sample().hi)
t3=threading.Thread(target=Sample().welcome)
#Set the Names to the Sub Threads
t1.name="RS"
t2.name="TR"
t3.name="DR"
print("Initially,Number of Threads in the Program=",threading.active_count())
#dispatch the sub threads
t1.start()
t2.start()
t3.start()
print("Now ,Number of Threads in the Program after start=",threading.active_count())
#Make the sub threads to join with MainThread
t1.join()
t2.join()
t3.join()
print("Now ,Number of Threads in the Program after join=",threading.active_count())
print("---------------------------------------------------------------------------------")
print("Program execution Completed by :{}".format(threading.current_thread().name))
print("---------------------------------------------------------------------------------")