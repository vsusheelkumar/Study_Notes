#Program for Demonstrating the Dead Lock  Elimination
#DeadLockEliminationOopEx1.py
import threading,time
class MulTable:
	def table(self,n):
		#Get the Lock
		L.acquire() # Step-2
		if(n<=0):
			print("\t{}--->{} is invalid Input".format(threading.current_thread().name,n))
		else:
			for i in range(1,11):
				print("\t{}-->{} x {} = {}".format(threading.current_thread().name,n,i,n*i))
				time.sleep(0.125)
			print("-------------------------------------------------------")
		#Release te lock
		L.release() #Step-3
#Main Program
#Create an object of Lock Class
L=threading.Lock() # Step-1
#Create Multi Threads and targetting same Function
t1=threading.Thread(target=MulTable().table,args=(9,))
t2=threading.Thread(target=MulTable().table,args=(19,))
t3=threading.Thread(target=MulTable().table,args=(-8,))
t4=threading.Thread(target=MulTable().table,args=(18,))
#dispatch the sub threads
t1.start()
t2.start()
t3.start()
t4.start()