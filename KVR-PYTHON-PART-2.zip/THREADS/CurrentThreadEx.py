#Program for Demonstrating How to get Default Thread and its active count
#CurrentThreadEx.py
import threading
t=threading.current_thread()
print("Default Thread Name:", t.name)
print("-------------------------OR-----------------------")
print("Default Thread Name:", threading.current_thread().name)
print("Number of Threads by Default=",threading.active_count())