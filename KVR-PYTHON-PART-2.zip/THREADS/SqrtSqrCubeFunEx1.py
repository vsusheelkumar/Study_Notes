#Program for Generating Squares,Cubes and Squareroots for List of Values  Separately by using Multiple Threads
#SqrtSqrCubeFunEx1.py
import threading,time
def squareroots(lst):
	for val in lst:
		print("\t{}-->sqrt({})={}".format(threading.current_thread().name,val,val**0.5))
		time.sleep(0.5)
def squares(lst):
		for val in lst:
			print("\t{}-->sqr({})={}".format(threading.current_thread().name,val,val**2))
			time.sleep(0.5)

def cubes(lst):
		for val in lst:
			print("\t{}-->cube({})={}".format(threading.current_thread().name,val,val**3))
			time.sleep(0.5)

#Main Threads
#Accept the List of Values
lst=[float(val) for val in input("Enter List of Values separated space:").split() if float(val)>=0]
#create 3 Sub Threads
sqrtt=threading.Thread(target=squareroots,args=(lst,))
sqrt1=threading.Thread(target=squares,args=(lst,))
cbt=threading.Thread(target=cubes,args=(lst,))
#disppatch the sub threads
sqrtt.start()
sqrt1.start()
cbt.start()
