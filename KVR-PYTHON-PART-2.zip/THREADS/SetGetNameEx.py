#Program for Demonstrating the setName() and getName()
#SetGetNameEx.py
import threading
def  welcome(sname):
	print("Sub Thread Name={}".format(threading.current_thread().name))
	print("Hi:{}, Good Morning".format(sname))

#Main Program
t=threading.Thread(target=welcome,args=("RS",))
#Get the Name of sub Thread
stname=t.name              #stname=t.getName()---Not Recommended to Use--Use only 'name'
print("Default Name of Sub Thread=",stname)
#Set the Programmer-Defined Name to the sub thread
t.name="KVR"       #t.setName("KVR")-------Not Recommended to Use--Use only 'name'
stname=t.name 
print("Programmer-Defined Name of Sub Thread=",stname)
print("Execution Status of t before start=",t.is_alive())
t.start()
print("Execution Status of t after start=",t.is_alive())