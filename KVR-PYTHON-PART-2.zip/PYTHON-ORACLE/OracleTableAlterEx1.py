#Program for altering the column Sizes of Employee Table
#OracleTableAlterEx1.py
import oracledb as orc
def tablealterwithmodify():
    try:
        con=orc.connect("system/manager@localhost/orcl") # Step-2
        cur=con.cursor() #Step-3
        #step-4
        ta="alter table employee modify (eno number(3), name varchar2(15))"
        cur.execute(ta)
        print("Table altered -verify")#Step-5
    except orc.DatabaseError as db:
        print("Problem in Oracle DB:",db)#Step-5

#Main Program
tablealterwithmodify()# Function Call