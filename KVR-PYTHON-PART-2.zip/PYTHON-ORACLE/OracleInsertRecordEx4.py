#program for Inserting the Record in a Employee Table
#OracleInsertRecordEx4.py
import oracledb as orc
import sys
sys.path.append("E:\\KVR-PYTHON-7AM\\EXCEPTION HANDLING\\CASE STUDY-3")
from NameValidExceptions import ZeroLengthError,SpaceError,InvalidNameError
from NameValidation import validation
def recordinsert():
    while(True):
        try:
            con=orc.connect("system/manager@localhost/orcl")
            cur=con.cursor()
            #Read Employee Values from KBD
            print("-----------------------------------------")
            empno=int(input("Enter Employee Number:"))
            empname=validation(input("Enter Employee Name:"))
            empsal=float(input("Enter Employee Salary:"))
            compname=validation(input("Enter Employee Comp Name:"))
            print("-----------------------------------------")
            ir="insert into employee values(%d,'%s',%f,'%s')" %(empno,empname,empsal,compname)
            cur.execute(ir)
            con.commit()
            print("{} Record Inserted".format(cur.rowcount))
            print("-----------------------------------------")
            ch=input("Do u want to Insert Another Employee Record(yes/no):")
            if(ch.lower()=="no"):
                print("Thx for using this Program")
                break
        except orc.DatabaseError as db:
            print("Problem in Oracle DB:",db)
        except ValueError:
            print("\tDon't enter alnums,strs and symbols for empno and Salary")
        except ZeroLengthError:
            print("\t U Must enter Ur Name/comp Name-try again")
        except SpaceError:
            print("\tDon't Enter Space to UR  Name/comp Name-try again")
        except InvalidNameError:
            print("\tUr Name is Invalid-try again ")

#Main Program
recordinsert() # Function call