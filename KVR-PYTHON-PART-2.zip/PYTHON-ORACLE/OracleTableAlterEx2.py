#Program for altering the  Employee Table by adding new col name
#OracleTableAlterEx2.py
import oracledb as orc
def tablealterwithadd():
    try:
        con=orc.connect("system/manager@localhost/orcl") # Step-2
        cur=con.cursor() #Step-3    
        #step-4
        ta="alter table employee add (compname varchar2(10) not null)"
        cur.execute(ta)
        print("Table altered -verify")#Step-5
    except orc.DatabaseError as db:
        print("Problem in Oracle DB:",db)#Step-5

#Main Program
tablealterwithadd()# Function Call