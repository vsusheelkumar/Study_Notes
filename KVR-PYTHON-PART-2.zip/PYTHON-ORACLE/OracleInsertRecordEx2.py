#program for Inserting the Record in a Employee Table
#OracleInsertRecordEx2.py
import oracledb as orc
def recordinsert():
    try:
        con=orc.connect("system/manager@localhost/orcl")
        cur=con.cursor()
        #Read Employee Values from KBD
        print("-----------------------------------------")
        empno=int(input("Enter Employee Number:"))
        empname=input("Enter Employee Name:")
        empsal=float(input("Enter Employee Salary:"))
        compname=input("Enter Employee Comp Name:")
        print("-----------------------------------------")
        ir="insert into employee values(%d,'%s',%f,'%s')" %(empno,empname,empsal,compname)
        cur.execute(ir)
        con.commit()
        print("{} Record Inserted".format(cur.rowcount))
        print("-----------------------------------------")
    except orc.DatabaseError as db:
        print("Problem in Oracle DB:",db)
#Main Program
recordinsert() # Function call