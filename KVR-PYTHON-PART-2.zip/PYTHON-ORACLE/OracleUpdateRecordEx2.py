#Program for updating the Employee Values Based on Emp Number
#OracleUpdateRecordEx2.py
import oracledb as orc
def updaterecord():
    while(True):
        try:
            con=orc.connect("system/manager@localhost/orcl")
            cur=con.cursor()
            #get the employee number from KBD
            empno=int(input("Enter Employee Number to update other Values:"))
            empsal=float(input("Enter Employee New Salary for Update:"))
            empcomp =input("Enter Employee New Comp Name for Update:")
            uq="update employee set sal=%f,compname='%s' where eno=%d"
            cur.execute(uq %(empsal,empcomp,empno))
            con.commit()
            if(cur.rowcount>0):
                print("{} Record Updated".format(cur.rowcount))
            else:
                print("Record Does not Exist")
            ch=input("Do u want to Update another Record(yes/no):")
            if(ch.lower()=="no"):
                break
        except orc.DatabaseError as db:
            print("Problem with Oracle:",db)
        except ValueError:
            print("Don't enter alnums,strs and symbols for empno and Salary")

#Main Program
updaterecord()
