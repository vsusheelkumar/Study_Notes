#Program for Dropping OR Removing the Table from Oracle Database
#OracleDropTableEx.py
import oracledb as orc
def droptable():
    try:
        con=orc.connect("system/manager@127.0.0.1/orcl")
        cur=con.cursor()
        #dt="drop table student"
        cur.execute("drop table temp")
        print("Table dropped")
    except orc.DatabaseError as db:
        print("Problem in Oracle:",db)

#main Program
droptable() # Function Call