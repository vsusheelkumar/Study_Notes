#Program for updating the Employee Values Based on Emp Number
#OracleUpdateRecordEx1.py
import oracledb as orc
def updaterecord():
    try:
        con=orc.connect("system/manager@localhost/orcl")
        cur=con.cursor()
        uq="update employee set sal=6.2,compname='WIPRO' where eno=325"
        cur.execute(uq)
        con.commit()
        print("{} Record Updated".format(cur.rowcount))
    except orc.DatabaseError as db:
        print("Problem with Oracle:",db)

#Main Program
updaterecord()