#Program for Creating Employee Table in Oracle Databaes
#OracleTableCreateEx1.py
import oracledb as k # Step-1
def tablecreate():
    try:
        con=k.connect("system/manager@localhost/orcl") # Step-2
        cur=con.cursor() #Step-3
        #step-4
        tc="create table teacher(tno number(2) primary key, tname varchar2(10) not null, sub varchar2(10) not null)"
        cur.execute(tc)
        print("Table Created-verify")#Step-5
    except k.DatabaseError as db:
        print("Problem in Oracle DB:",db)#Step-5

#Main Program
tablecreate() # Function Call