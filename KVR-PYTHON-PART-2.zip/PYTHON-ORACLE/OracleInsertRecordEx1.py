#program for Inserting the Record in a Employee Table
#OracleInsertRecordEx1.py
import oracledb as orc
def recordinsert():
    try:
        con=orc.connect("system/manager@localhost/orcl")
        cur=con.cursor()
        ir="insert into employee values(225,'Hunter',2.6,'VE')"
        cur.execute(ir)
        con.commit()
        print("{} Record Inserted".format(cur.rowcount))
    except orc.DatabaseError as db:
        print("Problem in Oracle DB:",db)
#Main Program
recordinsert() # Function call