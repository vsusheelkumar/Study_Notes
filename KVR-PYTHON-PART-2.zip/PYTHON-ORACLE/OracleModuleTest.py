#OracleModuleTest.py
import oracledb as orc
print("Module Version=",orc.__version__)
