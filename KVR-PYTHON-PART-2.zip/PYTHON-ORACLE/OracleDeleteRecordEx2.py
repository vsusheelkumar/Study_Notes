#Program for Delete Record from employee Table based empno
#OracleDeleteRecordEx2.py
import oracledb as orc
def deleterecord():
    while(True):
        try:
            con=orc.connect("system/manager@localhost/orcl")
            cur=con.cursor()
            #get the employee number from KBD
            empno=int(input("Enter Employee Number to Delete:"))
            dq="delete from employee where eno=%d"
            cur.execute(dq %empno)
            con.commit()
            if(cur.rowcount>0):
                print("{} Record Deleted".format(cur.rowcount))
            else:
                print("Record Does not Exist")
            ch=input("Do u want to Delete another Record(yes/no):")
            if(ch.lower()=="no"):
                break
        except orc.DatabaseError as db:
            print("Problem with Oracle:",db)
        except ValueError:
            print("Don't enter alnums,strs and symbols for empno")

#Main Program
deleterecord()