#Program for Reading the Records from Table--by using fetchall()
#OracleSelectRecordsEx2.py
import oracledb as orc
def selectrecord():
    try:
        con=orc.connect("system/manager@localhost/orcl")
        cur=con.cursor()
        sq="select * from employee"
        cur.execute(sq)
        #Get the Records from cursor object
        print("-"*50)
        records=cur.fetchall()
        if(len(records)==0):
            print("Table Does not Contain Records")
        else:
            ln=0
            for record in records:
                for val in record:
                    print("\t{}".format(val),end="\t")
                ln = ln + 1
                print()
            print("Number of Records=",ln)
        print("-" * 50)

    except orc.DatabaseError as db:
        print("Problem with Oracle:",db)

#Main Program
selectrecord()