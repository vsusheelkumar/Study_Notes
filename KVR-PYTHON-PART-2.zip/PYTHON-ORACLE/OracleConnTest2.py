#OracleConnTest2.py
import oracledb as orc
try:
    con=orc.connect("system/manager@127.0.0.1/orcl")
    print("Python Program Got Connection from Oracle db")
    print("Type of con object=",type(con))
except orc.DatabaseError as db:
    print("Problem in Oracle DB:",db)