#Program for Delete Record from employee Table based empno
#OracleDeleteRecordEx1.py
import oracledb as orc
def deleterecord():
    try:
        con=orc.connect("system/manager@localhost/orcl")
        cur=con.cursor()
        dq="delete from employee where eno=475"
        cur.execute(dq)
        con.commit()
        print("{} Record Deleted".format(cur.rowcount))
    except orc.DatabaseError as db:
        print("Problem with Oracle:",db)

#Main Program
deleterecord()