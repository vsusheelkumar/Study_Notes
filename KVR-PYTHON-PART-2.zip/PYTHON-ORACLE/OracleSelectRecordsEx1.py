#Program for Reading the Records from Table--by using fetchone()
#OracleSelectRecordsEx1.py
import oracledb as orc
def selectrecord():
    try:
        con=orc.connect("system/manager@localhost/orcl")
        cur=con.cursor()
        sq="select * from employee"
        cur.execute(sq)
        #Get the Records from cursor object
        print("-"*50)
        while(True):
            record = cur.fetchone()
            if(record!=None):
                for val in record:
                    print("\t{}".format(val),end="\t")
                print()
            else:
                print("-" * 50)
                break
    except orc.DatabaseError as db:
        print("Problem with Oracle:",db)

#Main Program
selectrecord()