#Program for Obtaining Records with Col Names and its Internal details
#Meta Data=Data(Records) About Data(Column Names and Its Data Type)
#OracleRecordsWithColNamesEx1.py
import oracledb as orc
def selectrecordscols():
    try:
        con=orc.connect("system/manager@localhost/orcl")
        cur=con.cursor()
        sq="select * from teacher"
        cur.execute(sq)
        #Get the Col Names  from cursor object
        print("-"*50)
        for colinfo in cur.description:
            print("\t{}".format(colinfo[0]),end="\t")
        print()
        print("-" * 50)
        #Get the Records
        records=cur.fetchall()
        for record in records:
            for val in record:
                print("\t{}".format(val),end="\t")
            print()
        print("-" * 50)
    except orc.DatabaseError as db:
        print("Problem with Oracle:",db)

#Main Program
selectrecordscols()