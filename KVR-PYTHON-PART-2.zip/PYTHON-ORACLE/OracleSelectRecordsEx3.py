#Program for Reading the Records from Table--by using fetchmany()
#OracleSelectRecordsEx3.py
import oracledb as orc
def selectrecord():
    try:
        con=orc.connect("system/manager@localhost/orcl")
        cur=con.cursor()
        sq="select * from employee"
        cur.execute(sq)
        #Get the Records from cursor object
        print("-"*50)
        records=cur.fetchmany(6)
        for record in records:
           for val in record:
               print("\t{}".format(val),end="\t")
           print()
        print("-" * 50)
    except orc.DatabaseError as db:
        print("Problem with Oracle:",db)

#Main Program
selectrecord()