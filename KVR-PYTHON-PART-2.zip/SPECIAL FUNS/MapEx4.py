#Program for Obtaining New Salary List from Old Salary List
#MapEx4.py
import functools
print("Enter List of Old Salary Values:")
oldsal=[float(val) for val in input().split()]  # [100,200,150,300,400,500]
newsal=list(map(lambda sal:sal+sal*50/100,oldsal))
#Find Total Amout Paid by Comp with Old Salary
totoldsal=functools.reduce(lambda sal1,sal2:sal1+sal2,oldsal)
#Find Total Amout Paid by Comp with New Salary
totnewsal=functools.reduce(lambda sal1,sal2:sal1+sal2,newsal)
print("-"*50)
print("\tOld Salary\tNew Salary")
print("-"*50)
for ol,nl in zip(oldsal,newsal):
	print("\t{}\t\t{}".format(ol,nl))
print("-"*50)
print("Total:{}\t\t{}".format(totoldsal,totnewsal))
print("-"*50)
