#Program for Getting Sum of List of +Ve and -Ve Values
#FilterEx6.py
import functools
print("Enter List of Values Separated by Space:")
lst=[float(val) for val in input().split()]
#lst=[10 -20 30 -40 50 -60 12 -6 0]
#Filter +Ve Vals
psvals=list(filter(lambda x: x>0,lst))
#Filter -Ve Vals
ngvals=tuple(filter(lambda x: x<0,lst))
#Find the sum of +ve Vals
if(len(psvals)>0):
	pssum=functools.reduce(lambda x,y: x+y,psvals)
	print("List of +Ve Values:{}-->Sum={}".format(psvals,pssum))
if(len(ngvals)>0):
	ngsum=functools.reduce(lambda x,y: x+y,ngvals)
	print("List of -Ve Values:{}-->Sum={}".format(ngvals,ngsum))
