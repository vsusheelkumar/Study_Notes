#Program for accepting List of Values and find tmax value using reduce()
#ReduceEx5.py
import functools

#main program
print("Enter List of Words Separated by Comma:")
lst=[  val  for val in input().split(",")]
print("Given Words=",lst)
line=functools.reduce(lambda k,v: k+" "+v, lst)
print("Line=",line)