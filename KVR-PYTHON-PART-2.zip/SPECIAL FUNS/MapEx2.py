#Program for Obtaining New Salary List from Old Salary List
#MapEx2.py
print("Enter List of Old Salary Values:")
oldsal=[float(val) for val in input().split()]  # [100,200,150,300,400,500]
newsal=list(map(lambda sal:sal+sal*50/100,oldsal))
print("Old Sal Values=",oldsal)
print("New Sal Values=",newsal)