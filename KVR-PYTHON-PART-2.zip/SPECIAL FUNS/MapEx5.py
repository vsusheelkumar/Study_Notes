#Program for Obtaining Total salary from  Salary with Comm.
#MapEx5.py
import functools
sals=[1000,2000,3000,4000]
comm=[500,200,100,50]

totsal=list(map(lambda sal,com:sal+com, sals,comm))
print("Given Sals=",sals)
print("Comm=",comm)
print("Total salary with Comm=",totsal)