#Program for Obtaining New Salary List from Old Salary List
#MapEx3.py
print("Enter List of Old Salary Values:")
oldsal=[float(val) for val in input().split()]  # [100,200,150,300,400,500]
newsal=list(map(lambda sal:sal+sal*50/100,oldsal))
print("-"*50)
print("\tOld Salary\tNew Salary")
print("-"*50)
for ol,nl in zip(oldsal,newsal):
	print("\t{}\t\t{}".format(ol,nl))
print("-"*50)