#Program for accepting List of Values and find tmax value using reduce()
#ReduceEx7.py
import functools
def kvrjoin(k,v):
	return(k+" "+v)

#main program
print("Enter List of Words Separated by Comma:")
lst=[  val  for val in input().split(",")]
print("Given Words=",lst)
line=functools.reduce(kvrjoin, lst)
print("Line=",line)