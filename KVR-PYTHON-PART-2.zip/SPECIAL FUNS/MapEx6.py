#Program for Adding ot Two List Contents into Single list
#MapEx6.py
def addlists(x,y):
	return(x+y)



#Main Program
lst1=[10,20,30,40]
lst2=[1,2,3,4]  # lst3=[11,22,33,44]
lst3=list(map(addlists,lst1,lst2))
print("Given List1=",lst1)
print("Given List2=",lst2)
print("Addition List3=",lst3)