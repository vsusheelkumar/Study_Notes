#Program for Obtaining New Salary List from Old Salary List
#MapEx1.py
def hike(sal):
	return(sal+sal*50/100)


#Main Program
print("Enter List of Old Salary Values:")
oldsal=[float(val) for val in input().split()]  # [100,200,150,300,400,500]
mapobj=map(hike,oldsal)
print("type of mapobj=",type(mapobj)) # here mapobj is of type <class,map>
#Type Cast map object into list
newsal=list(mapobj)
print("Old Sal Values=",oldsal)
print("New Sal Values=",newsal)