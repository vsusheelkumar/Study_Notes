#Program for Adding ot Two List Contents into Single list
#MapEx8.py
print("Enter List of Salaries  Separated by Space For First List")
SalList=[float(val) for val in input().split()]
print("Enter List of Comm. Values Separated by Space For Second List")
CommList=[float(val) for val in input().split()]
if(len(SalList)>len(CommList)):
	for i in range(len(SalList)-len(CommList) ):
		CommList.append(0)
elif(len(CommList)>len(SalList)):
	for i in range(len(CommList)-len(SalList)):
		SalList.append(0)

totsal=list(map(lambda x,y:x+y,SalList,CommList))
print("="*50)
print("Old Salary\t\tNew Salary\tTotal Salary")
print("="*50)
for osl,nsl,tsl in zip(SalList,CommList,totsal):
	print("\t{}\t\t{}\t\t{}".format(osl,nsl,tsl))
print("="*50)
