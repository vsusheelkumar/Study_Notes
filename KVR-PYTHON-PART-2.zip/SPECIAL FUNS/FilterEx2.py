#Program for Getting +Ve Value from List of Vaues by using Filter
#FilterEx2.py
print("Enter List of Values Separated by Space:")
lst=[float(val) for val in input().split()]
pslist=list(filter(lambda x: x>0 , lst))
nglist=tuple(filter(lambda x: x<0,lst))
print("----------------------------------------")
print("Given Values:",lst)
print("+Ve Values:",pslist)
print("-Ve Values:",nglist)
print("----------------------------------------")
