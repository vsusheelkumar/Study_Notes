#Program for accepting List of Values and find tmax value using reduce()
#ReduceEx4.py
import functools

findmaxval=lambda x,y: x if x>y else y # Anonymous func

#Main Program
print("Enter List of Elements Separated by Space:")
lst=[ float(val) for val in input().split()]
maxv=functools.reduce(findmaxval,lst)
print("Max({})={}".format(lst,maxv))

