#Program for Getting Those words whose length ranges between 3 to 4.
#FilterEx3.py
print("Enter List of words Separated by Comma:")
lst=[val for val in input().split(",")]
words34=list(filter(lambda word:len(word) in [3,4], lst))
print("-----------------------------------------------------------")
print("Given Words=",lst)
print("Words with 3 or 4=",words34)
print("-----------------------------------------------------------")