#Program for Getting Those Vowel words whose length ranges between 3 to 4.
#FilterEx5.py
print("Enter List of words Separated by Comma:")
lst=[val for val in input().split(",")]
words34=list(filter(lambda word:len(word) in range(3,5) and ("a" in word or "e" in word or "i" in word or "o" in word or"u" in word) , lst))
print("-----------------------------------------------------------")
print("Given Words=",lst)
print("Words with 3 or 4=",words34)
print("-----------------------------------------------------------")