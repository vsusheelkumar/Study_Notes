#Program for Getting +Ve Value from List of Vaues by using Filter
#FilterEx1.py
lst=[10,-20,-30,40,50,-60,70,-80]
pslist=[]
for val in lst:
	if(val>0):
		pslist.append(val)
print("+Ve Values=",pslist)
print("---------------OR---------------------")
psl=[val for val in lst if val>0]
print("+Ve Values=",psl)
print("---------------OR---------------------")
def posval(x):
	if x>0:
		return True
	else:
		return False

filtobj=filter(posval,lst)
print("filtobj=",type(filtobj))  # <class,filter>
#Type Cast Filter Object to List
poslist=list(filtobj)
print("+Ve Values=",poslist)