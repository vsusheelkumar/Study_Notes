#Program for accepting List of Values and find their sum by using reduce()
#ReduceEx1.py
import functools
def sumop(x,y): # Normal Function
	return(x+y)

#Main Program
print("Enter List of Elements Separated by Space:")
lst=[ float(val) for val in input().split()]
res=functools.reduce(sumop,lst)
print("Sum({})={}".format(lst,res))