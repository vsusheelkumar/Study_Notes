#Program for accepting List of Values and find their sum by using reduce()
#ReduceEx2.py
import functools

sumop=lambda x,y:x+y # Anonymous Function

#Main Program
print("Enter List of Elements Separated by Space:")
lst=[ float(val) for val in input().split()]
res=functools.reduce(sumop,lst)
print("Sum({})={}".format(lst,res))