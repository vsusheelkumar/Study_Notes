#Program for accepting List of Values and find tmax value using reduce()
#ReduceEx5.py
import functools

def findmaxval(k,v):
	return (k if k>v else v)

#main program
print("Enter List of Elements Separated by Space:")
lst=[ float(val) for val in input().split()]
maxv=functools.reduce( findmaxval, lst)
print("Max({})={}".format(lst,maxv))
