#Program for Adding ot Two List Contents into Single list
#MapEx7.py
print("Enter List of Values Separated by Space For First List")
lst1=[float(val) for val in input().split()]
print("Enter List of Values Separated by Space For Second List")
lst2=[float(val) for val in input().split()]
lst3=list(map(lambda x,y:x+y,lst1,lst2))
print("Given List1=",lst1)
print("Given List2=",lst2)
print("Addition List3=",lst3)