#Program for Loading OR Reading JSON File Data into Dict Object
#JsonFileToDictObj.py
import json
with open("E:\\KVR-PYTHON-7AM\\JSON\\notes\\stud.json","r") as fp:
	dictobj=json.load(fp)
	print("type of dictobj=",type(dictobj))
	print("------------------------------------------------------------")
	for key,val in dictobj.items():
		print("\t{}---->{}".format(key,val))
	print("------------------------------------------------------------")

