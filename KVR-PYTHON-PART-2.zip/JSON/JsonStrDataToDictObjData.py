#Program for Cnverting JSON String Data into Dict Object Data by using loads() os json module
#JsonStrDataToDictObjData.py
import json
print("--------------------------------------------------------------------")
jsonstrdata='{"SNO":"10","NAME":"Rossum","MARKS":"45.67"}'
print("Json String Data=",jsonstrdata)
print("Type of jsonstrdata=",type(jsonstrdata)) # <class 'str'>
print("--------------------------------------------------------------------")
dictobj=json.loads(jsonstrdata)
print("Type of dictobj=",type(dictobj))
for key,val in dictobj.items():
	print("\t{}-->{}".format(key,val))
print("--------------------------------------------------------------------")
