#Program for Converting Dict Data into JSON Str Data
#DictObjToJsonStrData.py
print("-----------------------------------------------------------------")
dictobj={"SNO":100,"NAME":"Rossum","MARKS":78.78}
print("Dict Data=",dictobj)
print("Type of Dict Obj=",type(dictobj))
print("-----------------------------------------------------------------")
#Convert Dict Object into JSON Str Data by usig str()
JsonStrData=str(dictobj)
print("Json String Data=",JsonStrData)
print("Type of Json Str Data=",type(JsonStrData))
print("-----------------------------------------------------------------")