#Program for Savinf Dict Object Data into JSON File
#DictObjToJsonFile.py
import json
print("-----------------------------------------------------------------")
dictobj={"SNO":100,"NAME":"Rossum","MARKS":78.78}
print("Dict Data=",dictobj)
print("Type of Dict Obj=",type(dictobj))
print("-----------------------------------------------------------------")
#save Dict Object Data into JSON File
with open("E:\\KVR-PYTHON-7AM\\JSON\\notes\\Stud.json","w") as fp:
	json.dump(dictobj,fp)
	print("Dict Object Data Saved in JSON File")
print("-----------------------------------------------------------------")