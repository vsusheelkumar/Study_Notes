#Program for Demonstrating the Functionality of continue stmts
#ContinueStmtEx2.py--while loop
s="PYTHON"
print("By using while Loop")
i=0
while(i<len(s)):
    print("\t{}".format(s[i]))
    i=i+1
else:
    print("I am else part of whileloop")
print("---------------------------------------------")
#My Req is to display "PYHON"
print("By using while Loop")
i=0
while(i<len(s)):
    if(s[i]=="T"):
        i = i + 1
        continue
    print("{}".format(s[i]),end="")
    i=i+1
else:
    print()
    print("I am else part of whileloop")
print("---------------------------------------------")