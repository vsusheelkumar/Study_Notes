#Program for accepting Line of Text and dispay vowels and Its count
#CountVowels.py
line=input("Enter a Line of Text:")
print("Given Line:{}".format(line)) # line=Apple is in red
vc=0
for ch in line:
    if ch.upper() in ["A","E","I","O","U"]:
        print(ch,end=",")
        vc=vc+1
else:
    print()
    print("Number of Vowels={}".format(vc))
