#Program for Finding Sum of Digits of Given Number
#NumDigitsSumEx1.py
n=int(input("Enter a Number for Finding Sum of Digits:"))
s=0
while(n>0):
    r=n%10
    s=s+r
    n=n//10
else:
    print("Sum of Digits of Given Number={}".format(s))
