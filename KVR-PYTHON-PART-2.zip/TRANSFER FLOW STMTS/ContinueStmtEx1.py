#Program for Demonstrating the Functionality of continue stmts
#ContinueStmtEx1.py--for loop
s="PYTHON"
print("By using for Loop")
for ch in s:
    print("\t{}".format(ch))
else:
    print("I am else part of for loop")
print("---------------------------------------------")
#My Req is to display "PYTON
for ch in s:
    if(ch=="H"):
        continue
    print("{}".format(ch),end="")
else:
    print()
    print("I am else part of for loop")
print("---------------------------------------------")

