#Program for Finding Sum of Digits of Given Number
#NumDigitsSumEx2.py
n=input("Enter a Number for Finding Sum of Digits:") # 4567
s=0
for d in n:
    s=s+int(d)
else:
    print("Sum of Digits of Given Number={}".format(s))
