#Program for Demonstrating the Functionality of continue stmts
#ContinueStmtEx3.py--for loop
s="PYTHON"
print("By using for Loop")
for ch in s:
    print("\t{}".format(ch))
else:
    print("I am else part of for loop")
print("---------------------------------------------")
#My Req is to display  PTHN
for ch in s:
    if(ch=="Y") or (ch=="O"):
        continue
    print("{}".format(ch),end="")
else:
    print()
    print("I am else part of for loop")
print("---------------------------------------------")

