#Program for Demionstrating the need of break stmt
#BreakStmtEx1.py
s="PYTHON"
print("By using for loop")
for ch in s:
    print(ch)
else:
    print("---------------------------------------")
#My Req today is to display only  PYTH without using Indexing and Slicing
for ch in s:
    if(ch=="O"):
        break
    print(ch,end="")
else:
    print("---------------------------------------")

