#Program for Demionstrating the need of break stmt
#BreakStmtEx4.py
s="MISSISSIPPI"
#My Req today is to display only  MISS without using Indexing and Slicing
i=0
c=0
while(i<len(s)):
    if(s[i]=="I"):
        c=c+1
        if(c==2):
            break
    print(s[i],end="")
    i=i+1