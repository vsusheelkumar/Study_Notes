#Program for Demionstrating the need of break stmt
#BreakStmtEx3.py
s="MISSISSIPPI"
#My Req today is to display only  MISS without using Indexing and Slicing
c=0
for ch in s:
    if(ch=="I"):
        c=c+1
        if(c==2):
            break
    print(ch,end="")