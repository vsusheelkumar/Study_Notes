#Program for accepting a Line of Text and Display Only digits and count them
#ContinueStmtEx4.py
s=input("Enter a Line of Text with the combination of alphabets and digits:")
nod=0
for ch in s:
    if(not ch.isdigit()):
        continue
    print("{}".format(ch),end=" ")
    nod=nod+1
else:
    print()
    print("Number of Digits in Given Text={}".format(nod))