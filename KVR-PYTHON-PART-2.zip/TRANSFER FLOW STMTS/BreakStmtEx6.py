#Program for accepting a Numerical Integer Value
# and Decide whether It is Prime or Not
#BreakStmtEx6.py
n=int(input("Enter a Number:"))
if(n<=1):
    print("{} is Invalid input".format(n))
else:
    res=True
    for i in range(2,n):
        if(n%i==0):
            res=False
            break
    res1="PRIME" if res else "NOT PRIME"
    print("{} is {}".format(n,res1))