#Program for Demionstrating the need of break stmt
#BreakStmtEx2.py
s="PYTHON"
print("By using while loop")
i=0
while(i<len(s)):
    print(s[i])
    i=i+1
else:
    print("I am from else part of while")
#My Req today is to display only  PYTH without using Indexing and Slicing
i=0
while(i<len(s)):
    if(s[i]=="O"):
        break
    else:
        print(s[i],end="")
        i=i+1
else:
    print("I am from else part of while")
print()
print("Other Statements in Program")