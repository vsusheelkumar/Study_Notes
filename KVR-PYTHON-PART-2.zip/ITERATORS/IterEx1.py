#Program for Demonstrating the need of Iterator
#IterEx1.py
x=[10,"RS",34.56,"PYTHON"]
print("Type of x=",type(x))
#convert Iterable Object into Iterator Object by using iter()
xitr=iter(x)
print("Type of xitr=",type(xitr))
#get the Data from Iterator Object
print(next(xitr))
print(next(xitr))
print(next(xitr))
print(next(xitr))

