#Program for Demonstrating the need of Iterator
#IterEx6.py
x=range(10,20,2)
print("Type of x=",type(x))
#convert Iterable Object into Iterator Object by using iter()
xitr=iter(x)
print("Type of xitr=",type(xitr))
#get the Data from Iterator Object
for val in xitr:
	print(val)

