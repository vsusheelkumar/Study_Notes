#Program for Demonstrating the need of Iterator
#IterEx4.py
x={10:"C",20:"PYTHON",30:"DSA",40:"HTML"}
print("Type of x=",type(x))
#convert Iterable Object into Iterator Object by using iter()
xitr=iter(x)
print("Type of xitr=",type(xitr))
#get the Data from Iterator Object
for val in xitr:
	print(x.get(val),"-->",val) # OR print(x[val],"-->",val)


