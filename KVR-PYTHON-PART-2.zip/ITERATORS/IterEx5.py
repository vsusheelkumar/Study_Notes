#Program for Demonstrating the need of Iterator
#IterEx5.py
x="PYTHON"  
print("Type of x=",type(x))
#convert Iterable Object into Iterator Object by using iter()
xitr=iter(x)
print("Type of xitr=",type(xitr))
#get the Data from Iterator Object
for val in xitr:
	print(val)

