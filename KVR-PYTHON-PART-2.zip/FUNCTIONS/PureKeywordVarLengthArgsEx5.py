#PureKeywordVarLengthArgsEx5.py
def findtotal(sno,sname,cls,*kvr,city="HYD",**submarks):
	print("****************************************************")
	print("Variable Length Arguments={} and sum={}".format(kvr,sum(kvr)))
	print("--------------------------------------------------")
	print("\tStudent Number:{}".format(sno))
	print("\tStudent Name:{}".format(sname))
	print("\tStudent Class:{}".format(cls))
	print("\tStudent City={}".format(city))
	print("--------------------------------------------------")
	totmarks=0
	if(len(submarks)==0):pass
	else:
		print("\tSubjects\tMarks")
		print("--------------------------------------------------")
		for subject,marks in submarks.items():
			print("\t{}\t\t{}".format(subject,marks))
			totmarks=totmarks+marks
		print("--------------------------------------------------")
		print("Internat Total:{} Ext .Total Marks:{}".format(sum(kvr),totmarks))
	print("\tTOTAL MARKS={}".format(sum(kvr)+totmarks))
	print("--------------------------------------------------")

#Main Program
findtotal(10,"Rakesh","X",12,20,16,18,14,11,Tel=80,Hindi=90,English=95,Maths=75,Sci=80,Soc=90)
findtotal(20,"Rajesh","XII",20.3,11.3,13.3,15.6,18.8,English=95,Sanskrit=99,Math=75,Phy=60,Che=58)
findtotal(30,"Ramesh","B.Tech",8.2,3.4,5.6,cm=50,cppm=70,OS=90)
findtotal(40,"Rossum","Research",5.6,7.8)
findtotal(50,"DT","Politics",Pol=90,city="USA",Eco=50)
#findtotal(cls="Politics",sname="VP",sno=60,10,20,30,Com=34,city="RSA")