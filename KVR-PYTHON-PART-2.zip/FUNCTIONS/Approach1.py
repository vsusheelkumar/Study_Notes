#Program To Define Function for addition of Two Numbers
# INPUT    : Taking from Function Call
# PROCESS  : Done Inside of Function Body
# RESULT   : Giving Back to Function Call
#Approach1.py
def addop(a,b): # Here 'a' and 'b' are called Formal Parameters
    c=a+b  # Here c is called Local Variable
    return c

#Main Program
x=float(input("Enter First Value:"))
y=float(input("Enter Second Value:"))
res=addop(10,20) # Function Call
print("Sum({},{})={}".format(x,y,res))
print("----------------OR----------------------")
a=float(input("Enter First Value:"))
b=float(input("Enter Second Value:"))
c=addop(a,b) # Function Call
print("Sum({},{})={}".format(a,b,c))