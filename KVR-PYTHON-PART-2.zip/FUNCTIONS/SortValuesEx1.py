#SortValuesEx1.py
def getvalues():
    n=int(input("Enter How Many Values u want to enter:"))
    if(n<=0):
        return []
    else:
        lst=[]
        for i in range(1,n+1):
            value=float(input("Enter {} Value:".format(i)))
            lst.append(value)
        else:
            return lst

def sortvalues():
    lst=getvalues()
    if(len(lst)==0):
        print("List is Empty--can't sort ")
    else:
        print("-----------------------------")
        print("Original Data")
        for val in lst:
            print("\t{}".format(val))
        else:
            print("-----------------------------")
            lst.sort()
            print("Ascending Order of Data")
            for val in lst:
                print("\t{}".format(val))
            else:
                print("-----------------------------")
                lst.sort(reverse=True) # OR lst=lst[::-1] OR lst.reverse()
                print("Decending Order of Data")
                for val in lst:
                    print("\t{}".format(val))
                else:
                    print("-----------------------------")

#Main Program
sortvalues()
