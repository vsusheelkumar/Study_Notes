#Program for Demionstrating  Keyword Variable Length Arguments
#This Program will  Execute as it is
#PureKeywordVarLengthArgsEx2.py
def  disp( **a): #Here **a is called Keyword Variable length args and whose type <class, dict>
	print("---------------------------------------")
	for k in a.keys():
		print("\t{}-->{}".format(k,a[k]))
	print("Number of Values=",len(a))
	print("---------------------------------------")

#Main Program
disp(sno=10,sname="RS",cm=40,cppm=50,pym=60) # Function Call-1 with 5-Keyword Var Length args
disp(eno=100,ename="TR",sal=4.5,dsg="SE")# Function Call-2 with 4-Keyword  Var Length args
disp(tid=1,tname="JG",Sub="PYTHON")# Function Call-3 with 3-Keyword Var Length args
disp(cid=200,cname="KV")# Function Call-4 with 2-Keyword Var Length args
disp(a=100)# Function Call-5with 1-Keyword Var Length args
disp()# Function Call-6with 0-Keyword Var Length args

