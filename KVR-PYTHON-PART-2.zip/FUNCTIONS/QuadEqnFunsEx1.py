#QuadEqnFunsEx1.py
def getabcvalues():
    a,b,c=float(input("Enter Value of a:")),float(input("Enter Value of b:")),float(input("Enter Value of c:"))
    return a,b,c
def calroots():
    a,b,c=getabcvalues() # Function Call with Multi Line assigment
    d=(b**2-4*a*c)**0.5
    if(type(d)==float):
        if(d==0):
            print("\tRoots are Real and Equal")
            r1 = (-b)/ (2 * a)
            r2 = (-b) / (2 * a)
            print("\tRoot1={}".format(r1))
            print("\tRoot2={}".format(r2))
        elif(d>0):
            print("\tRoots are Real and Distinct")
            r1=(-b+d)/(2*a)
            r2=(-b-d)/(2*a)
            print("\tRoot1={}".format(r1))
            print("\tRoot2={}".format(r2))
    else:
        print("\tRoots are Imaginary")
        r1 = (-b + d) / (2 * a)
        r2 = (-b - d) / (2 * a)
        print("\tRoot1={}".format(r1))
        print("\tRoot2={}".format(r2))

#Main Program
calroots()