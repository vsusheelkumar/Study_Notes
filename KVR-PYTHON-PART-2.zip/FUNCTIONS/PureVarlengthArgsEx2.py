#Program for Demonstrating the  Variable Length Arguments
#This Program will  execute as it is.
#PureVarlengthArgsEx2.py
def disp(*a ): # Here *a is called Variable Length Parameter and whose type is <class,tuple>
	for val in a:
		print("{}".format(val),end="  ")
	print()
	print("------------------------------------------")
	


#Main Program
disp(10,20,30,40,50) # Function Call-1 with 5 args
disp(10,20,30,40) # Function Call-2 with 4 args
disp(10,20,30) # Function Call-3 with 3 args
disp(10,20) # Function Call-4 with 2 args
disp(10) # Function Call-5 with 1 args
disp() # Function Call-6 with 0 args"""
