#Program for Demonstrating the need of globals()
#GlobalsFunEx2.py
# Note : Here global and local Variables are Same
#How Can we Refer Both global and local Variable in same Function Body?
# ANS Use globals()
def  operations():
	a=100
	b=200
	c=300
	d=400 # here 'a' , 'b' , 'c' and 'd' are called Local variable 
	res=a+b+c+d+globals()['a']+globals().get('b')+globals().get('c')+globals()['d']
	print("sum=",res)

#Main Program
a=10
b=20
c=30
d=40 # Here 'a', 'b' 'c' and 'd' are called global Variables
operations() # Function Call




