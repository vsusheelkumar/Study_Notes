#Program for Demonstrating the Default Arguments
#DefaultArgsEx2.py
def dispstudvalues(sno,sname,marks,crs="PYTHON",cnt="INDIA"):  # Here crs and cnt are called Default Parameters
	print("\t{}\t{}\t{}\t{}\t{}".format(sno,sname,marks,crs,cnt))


#Main Program
print("-"*50)
print("\tSNO\tNAME\tMARKS\tCOURSE\tCOUNTRY")
print("-"*50)
dispstudvalues(100,"RS",34.56) # Function Call with Pos Args 
dispstudvalues(200,"TR",55.16) # Function Call with Pos Args 
dispstudvalues(300,"DR",35.86) # Function Call with Pos Args 
dispstudvalues(400,"SS",11.11) # Function Call with Pos args
dispstudvalues(500,"PT",66.66) # Function Call with Pos Args 
print("-"*50)