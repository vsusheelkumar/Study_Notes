#Program for Demonstrating the need of global keyword
#GlobalKwdEx2.py
def  modify1():
	global a,b
	a=a+1
	b=b+1

def modify2():
	global a,b
	a=a*2
	b=b*2

def modify3():
	#Here we need not write global Kwd bcoz here we are Just Acessing global Variables 'a' and 'b' But not modifying
	c=a+10
	d=b+20
	print("In modify3(), Val of c(Local)=",c) # 32
	print("In modify3(), Val of d(Local)=",d)# 62

#Main Program
a,b=10,20 # Here 'a'  and 'b' is called Global Variable
print("Main Program-Before Function Call--> a={}  b={}".format(a,b)) # 10, 20
modify1() # Function Call-1
print("Main Program-after Function Call--> a={}  b={}".format(a,b)) # 11 21
modify2()  # Function Call-2
print("Main Program-after Function Call--> a={}  b={}".format(a,b)) # 22  42
modify3()  # Function Call-3
print("Main Program-after Function Call--> a={}  b={}".format(a,b)) # 22  42
