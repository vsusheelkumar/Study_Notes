#Program for Demonstrating Local and Global Variables
#LocalGlobalVarEx4.py
def  learnAI():
	sub1="AI"  # Here sub1 is called Local Var
	print("To Implement '{}' Based Apps, we use '{}' Lang".format(sub1,lang))

def  learnML():
	sub2="ML"   # Here sub2 is called Local Var
	print("To Implement '{}' Based Apps, we use '{}' Lang".format(sub2,lang))

def  learnDS():
	sub3="DS" # Here sub3 is called Local Var
	print("To Implement '{}' Based Apps, we use '{}' Lang".format(sub3,lang))

#Main Program
#learnAI() # we get Error---bcoz 'lang' Defined after Function Call
lang="PYTHON" # here lang is Called Global Var
learnML() # Function Calls
learnDS() # # Function Calls
