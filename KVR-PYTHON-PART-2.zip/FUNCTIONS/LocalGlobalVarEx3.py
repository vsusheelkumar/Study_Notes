#Program for Demonstrating Local and Global Variables
#LocalGlobalVarEx3.py
def  learnAI():
	sub1="AI"  # Here sub1 is called Local Var
	print("To Implement '{}' Based Apps, we use '{}' Lang".format(sub1,lang))

def  learnML():
	sub2="ML"   # Here sub2 is called Local Var
	print("To Implement '{}' Based Apps, we use '{}' Lang".format(sub2,lang))

lang="PYTHON" # here lang is Called Global Var

def  learnDS():
	sub3="DS" # Here sub3 is called Local Var
	print("To Implement '{}' Based Apps, we use '{}' Lang".format(sub3,lang))

#Main Program
learnAI() # Function Calls
learnML() # Function Calls
learnDS() # # Function Calls
