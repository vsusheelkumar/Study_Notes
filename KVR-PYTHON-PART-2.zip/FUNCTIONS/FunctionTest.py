#Define a Function
#welcome("Rossum")---Invalid Function Calling
def welcome(name):
    print("Hi {}, Good Morning".format(name))

#Main Program
print("I am after welcome() Def")
print("Lin:7-type of welcome=",type(welcome))
welcome("Rossum") # valid Function Calling
welcome("Travis") # valid Function Calling
print("I am after welcome() execution")