#Program To Define Function for addition of Two Numbers
# INPUT    : Taking inside of Function Body
# PROCESS  : Done Inside of Function Body
# RESULT   : Giving Back to Function Call
#Approach4.py
def addop():
    # Taking Input
    a = float(input("Enter First Value:"))
    b = float(input("Enter Second Value:"))
    # Process
    c = a + b
    #Give the Result back to Function Call
    return a,b,c

#Main Program
k,v,r=addop() # Function Call with Multi Line assignment
print("Sum({},{})={}".format(k,v,r))
print("----------------OR--------------------")
res=addop() # Function Call with Single Line assignment
#here res is an object of type<class, tuple>
print("sum({},{})={}".format(res[0],res[1],res[2]))
print("----------------OR--------------------")
print("sum({},{})={}".format(res[-3],res[-2],res[-1]))
