#Program for Demonstrating the need of globals()
#GlobalsFunEx3.py
def  operations():
	x=globals()
	print("-"*50)
	print("Bith Visible and Invisible Global Variables")
	for gvn,gvv in x.items():
		print("{}-->{}".format(gvn,gvv))
	print("-"*50)
	print("Programmer-Defined Gloval Variables-Way-1")
	print("Val of a=",x.get('a'))
	print("Val of b=",x.get('b'))
	print("-"*50)
	print("Programmer-Defined Gloval Variables-Way-2")
	print("Val of a=",x['a'])
	print("Val of b=",x['b'])
	print("-"*50)
	print("Programmer-Defined Gloval Variables-Way-3")
	print("Val of a=",globals()['a'])
	print("Val of b=",globals()['b'])
	print("-"*50)
	print("Programmer-Defined Gloval Variables-Way-4")
	print("Val of a=",globals().get('a'))
	print("Val of b=",globals().get('b'))
	print("-"*50)
#Main Program
a=10
b=20  # Here 'a', 'b'  are called global Variables
operations() # Function Call




