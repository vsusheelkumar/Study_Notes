#PureKeywordVarLengthArgsEx3.py
def findtotal(sno,sname,cls,**submarks):
	print("--------------------------------------------------")
	print("\tStudent Number:{}".format(sno))
	print("\tStudent Name:{}".format(sname))
	print("\tStudent Class:{}".format(cls))
	print("--------------------------------------------------")
	if(len(submarks)==0):pass
	else:
		print("\tSubjects\tMarks")
		print("--------------------------------------------------")
		totmarks=0
		for subject,marks in submarks.items():
			print("\t{}\t\t{}".format(subject,marks))
			totmarks=totmarks+marks
		print("--------------------------------------------------")
		print("\tTOTAL MARKS:{}".format(totmarks))
	print("--------------------------------------------------")

#Main Program
findtotal(10,"Rakesh","X",Tel=80,Hindi=90,English=95,Maths=75,Sci=80,Soc=90)
findtotal(20,"Rajesh","XII",English=95,Sanskrit=99,Math=75,Phy=60,Che=58)
findtotal(30,"Ramesh","B.Tech",cm=50,cppm=70,OS=90)
findtotal(40,"Rossum","Research")