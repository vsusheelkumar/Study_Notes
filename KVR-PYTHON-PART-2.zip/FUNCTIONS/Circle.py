#Program to define Function to cal area and perimter of Circle
#Circle.py
def circlearea():
    r=float(input("Enter Radius for Cal area of Circle:"))
    ca=3.14*r**2
    print("Circle Area={}".format(ca))

def circleperi():
    r = float(input("Enter Radius for Cal Perimeter of Circle:"))
    cp = 2*3.14 * r
    print("Circle Perimeter={}".format(cp))

#Main Program
while(True):
    print('-'*50)
    print("Circle Measurments")
    print('-'*50)
    print("1. Area")
    print("2. Perimeter")
    print("3. Exit")
    print('-'*50)
    ch=int(input("Enter Ur Choice:"))
    match(ch):
        case 1: circlearea()
        case 2: circleperi()
        case 3:
            print("Thc for Using this program")
            break
        case _:
            print("UR Selection of Operation is wrong--try again")
