#Program To Define Function for addition of Two Numbers
# INPUT    : Taking inside of Function Body
# PROCESS  : Done in Function Body
# RESULT   : Displayed Inside of Function Body
#Approach2.py
def  addop():
    #Taking Input
    a=float(input("Enter First Value:"))
    b = float(input("Enter Second Value:"))
    #Process
    c=a+b
    #Display the Result
    print("Sum({},{})={}".format(a,b,c))

#Main Program
addop() # Function Call

