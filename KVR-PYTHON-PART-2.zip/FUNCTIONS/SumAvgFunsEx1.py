#SumAvfFunsEx1.py
def getvalues():
    n=int(input("Enter How Many Values u want to enter:"))
    if(n<=0):
        return []
    else:
        lst=[]
        for i in range(1,n+1):
            value=float(input("Enter {} Value:".format(i)))
            lst.append(value)
        else:
            return lst

def computesumavg(lst):
    if(len(lst)==0):
        print("List is Empty--can't Find sum and avg ")
    else:
        s=0
        for val in lst:
            s=s+val
        else:
            print("Sum={}".format(s))
            print("Average={}".format(s/len(lst)))
#Main Program
lst=getvalues() # Function Call
computesumavg(lst)
