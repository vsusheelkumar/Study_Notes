#Program for Demonstrating the need of global keyword
#GlobalKwdEx1.py
def  modify1():
	global a
	a=a+1

def modify2():
	global a
	a=a*2

#Main Program
a=10 # Here 'a' is called Global Variable
print("Main Program: Value of a before Function Call:{}".format(a)) # 10
modify1() # Function Call-1
print("Main Program: Value of a after Function Call:{}".format(a)) #  11
modify2()  # Function Call-2
print("Main Program: Value of a after Function Call:{}".format(a)) #  22
