#Program for Demonstrating the  Variable Length Arguments
#This Program will  execute as it is.
#PureVarlengthArgsEx4.py
def disp(sno,sname,*a,city="HYD"): # Here *a is called Variable Length Parameter and whose type is <class,tuple>
	print("-"*50)
	print("Student Number:{}".format(sno))
	print("Student Name:{}".format(sname))
	print("Student City:{}".format(city))
	s=0
	for val in a:
		print("\t{}".format(val))
		s+=val
	print("\tSum={}".format(s))
	print("------------------------------------------")
	
#Main Program
disp(100,"Rossum",10,20,30,40,50) # Function Call-1 with 5 args
disp(200,"Travis",10,20,30,40) # Function Call-2 with 4 args
disp(300,"Ritche",10,20,30) # Function Call-3 with 3 args
disp(400,"Dennis",10,20) # Function Call-4 with 2 args
disp(500,"Hunter",10) # Function Call-5 with 1 args
disp(600,"Gosling") # Function Call-6 with 0 args
disp(700,"DT",1.2,4.5,6.7,city="USA") # Function Call-6 with 0 args
#disp(800,"PT",city="RSA",10,2.3,5.6) --SyntaxError: positional argument follows keyword argument
disp(800,"PT",10,2.3,5.6,city="RSA")
