#Program To Define Function for addition of Two Numbers
# INPUT    : Taking from Function Call
# PROCESS  : Done Inside of Function Body
# RESULT   : Displayed Inside of Function Body
#Approach3.py
def addop(x,y):
    z=x+y
    print("Sum({},{})={}".format(x,y,z))

#main Program
x=float(input("Enter First Value:"))
y=float(input("Enter Second Value:"))
addop(x,y) # Function Call
