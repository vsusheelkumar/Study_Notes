#FunctionwithDataType.py
def disp1(a:complex):
    print(a.imag)
    print(a.real)

def disp2(x:list):
    print(x)
    x.extend([12,13,14])
    print(x)

def disp3(s:str):
    print(s)
    s=s.upper()
    print(s)

#Main Program
print("-------------------------------")
disp1(2+3j)
print("-------------------------------")
disp3("Python")
print("-------------------------------")
disp2([10,20,30,40,50])
print("-------------------------------")

