#Program To Define Function for addition of Two Numbers
#ApproachEx1.py
def addop(a,b): # Here 'a' and 'b' are called Formal Parameters
    print("\tI am from addop()")
    c=a+b # Here c is called Local Variable
    return c

#Main Program
res=addop(10,20) # Function Call
print("Sum=",res)
res1=addop(100,200) # Function Call
print("Sum=",res1)
res1=addop(-100,-200) # Function Call
print("Sum=",res1)