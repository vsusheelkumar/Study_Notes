#Program for Accepting List of Words and Find Max Length Word
#MaxLenWordEx1.py
def getwords():
	nowords=int(input("Enter Howw Many words u have:"))
	if(nowords<=0):
		return [] # Empty List
	else:
		words=[]
		for i in range(1,nowords+1):
			word=input("Enter {} Word:".format(i))
			words.append(word)
		else:
			return(words)


def findwordslength(words):
	if(len(words)==0):  
		print("List is empty--can't find max length word")
	else: # words=['Python', 'Java', 'Elephant', 'C', 'HTML']
		wd={}
		for word in words:
			wd[word]=len(word)
		else:
			return wd


def findmaxword(wd): # wd={'Python': 6, 'Java': 4, 'Elephant': 8, 'C': 1, 'HTML': 4}
	print("-----------------------------------------------------")
	mlw=max(wd.values())
	print("Max Length Word(s)")
	for k,v in wd.items():
		if(v==mlw):
			print("\tWord:{}\tlength={}".format(k,v))
	print("-----------------------------------------------------")		

#Main Program
words=getwords()
wd=findwordslength(words)
findmaxword(wd)
