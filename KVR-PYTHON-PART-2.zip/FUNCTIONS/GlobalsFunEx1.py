#Program for Demonstrating the need of globals()
#GlobalsFunEx1.py
# Note : Here global and local Variables are Different.
a=10
b=20
c=30
d=40 # Here 'a', 'b' 'c' and 'd' are called global Variables
def  operations():
	x=100
	y=200
	z=300
	k=400 # here 'x' , 'y' , 'z' and 'k' are called Local variable 
	res=a+b+c+d+x+y+z+k
	print("sum=",res)
#Main Program
operations() # Function Call




