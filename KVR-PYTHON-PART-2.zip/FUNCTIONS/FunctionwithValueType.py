#FunctionwithValueType.py
def decidetype(a):
    if(type(a)==int):
        print("Value:{} Type:{}".format(a,type(a)))
    elif(type(a)==float):
        print("Value:{} Type:{}".format(a, type(a)))
    elif(type(a)==bool):
        print("Value:{} Type:{}".format(a, type(a)))
    elif(type(a)==complex):
        print("Value:{} Type:{}".format(a, type(a)))
        print("\tReal Part:{} Imaginary Part:{}".format(a.real,a.imag))
    elif(type(a)==str):
        print("Value:{} Type:{}".format(a, type(a)))
        print("\tIts Upper Case:{}".format(a.upper()))
    elif(type(a)==bytes):
        print("Value:{} Type:{}".format(a, type(a)))
        for val in a:
            print("\t{}".format(val))
    elif (type(a) == bytearray):
        print("Value:{} Type:{}".format(a, type(a)))
        for val in a:
            print("\t{}".format(val))
    elif (type(a) == range):
        print("Value:{} Type:{}".format(a, type(a)))
        for val in a:
            print("\t{}".format(val))
    elif (type(a) == list):
        print("Value:{} Type:{}".format(a, type(a)))
        for val in a:
            print("\t{}".format(val))
    elif (type(a) == tuple):
        print("Value:{} Type:{}".format(a, type(a)))
        for val in a:
            print("\t{}".format(val))
    elif (type(a) == set):
        print("Value:{} Type:{}".format(a, type(a)))
        for val in a:
            print("\t{}".format(val))
    elif (type(a) == frozenset):
        print("Value:{} Type:{}".format(a, type(a)))
        for val in a:
            print("\t{}".format(val))
    elif(type(a)==dict):
        print("Value:{} Type:{}".format(a, type(a)))
        for key,value in a.items():
            print("\t{}-->{}".format(key,value))
    else:
        print("Value:{} Type:{}".format(a, type(a)))

#Main Program
decidetype(10) # Function Call
decidetype(10.75) # Function Call
decidetype(True) # Function Call
decidetype(2+3j) # Function Call
decidetype("python") # Function Call
decidetype(bytes([100,200,189,210])) # Function Call
decidetype(bytearray([100,200,189,210])) # Function Call
decidetype(range(10,21,2))# Function Call
decidetype([10,"RS",45.67,True])# Function Call
decidetype((100,"TR",65.67,False,2+3j))# Function Call
decidetype({1.2,2.3,4.5,10,20})# Function Call
decidetype(frozenset({1.2,2.3,4.5,10,20}))# Function Call
decidetype({10:1.2,20:2.3,30:3.4,40:4.5}) # Function Call
decidetype(None)


