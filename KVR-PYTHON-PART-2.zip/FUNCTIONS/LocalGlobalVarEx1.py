#Program for Demonstrating Local and Global Variables
#LocalGlobalVarEx1.py
def  learnAI():
	sub1="AI"  # Here sub1 is called Local Var
	print("To Implement '{}' Based Apps, we use '{}' Lang".format(sub1,lang))
	#print(sub2,sub3) here we can't access sub2 and sub3 bcoz they are local in other Functions

def  learnML():
	sub2="ML"   # Here sub2 is called Local Var
	print("To Implement '{}' Based Apps, we use '{}' Lang".format(sub2,lang))
	#print(sub1,sub3) here we can't access sub1 and sub3 bcoz they are local in other Functions

def  learnDS():
	sub3="DS" # Here sub3 is called Local Var
	print("To Implement '{}' Based Apps, we use '{}' Lang".format(sub3,lang))
	#print(sub1,sub2) here we can't access sub1 and sub2 bcoz they are local in other Functions

#Main Program
lang="PYTHON" # here lang is Called Global Var
learnAI() # Function Calls
learnML() # Function Calls
learnDS() # # Function Calls
