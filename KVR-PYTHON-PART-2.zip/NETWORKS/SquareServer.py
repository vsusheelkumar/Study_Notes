#A. Write a Python Server Side Program in such way that It should accept a Number from Client Side Program, 
#   square It gives the Result to the Client Side Program. (SquareServer.py)
#SquareServer.py
import socket # Step-1
s=socket.socket() # Step-2
s.bind(("localhost",9999))
s.listen(2) # Step-3
print("SSP is ready to accept any CSP Request")
while(True):
	try:
		cs,ca=s.accept() # Step-4
		#Step-5
		cv=cs.recv(1024).decode() 
		print("Val of Client at Server=",cv)
		val=float(cv)
		res=val**2
		#Step-6
		cs.send( str(res).encode() )
	except ValueError:
		cs.send("Don't Enter alnums,strs and symbols".encode())