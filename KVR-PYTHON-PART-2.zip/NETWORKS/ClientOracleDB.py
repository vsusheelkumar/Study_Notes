#B. Write a Python Client Side Program in such way that It Should accept  Emp Number from Key Board and  Gives Other deatils as Reply to the Server Side Program.
#ClientOracleDB.py
import socket
s=socket.socket()
s.connect(("localhost",3600))
print("CSP Got Connection from SSP")
#accept emp number from key board
empno=input("Enter Employee Number to Get Other Details:")
s.send(empno.encode())
res=s.recv(1024).decode()
print("Result from Server")
print(res)

