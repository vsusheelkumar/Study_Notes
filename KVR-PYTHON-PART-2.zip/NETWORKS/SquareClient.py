#B. Write a Python Client Side Program in such way that It should accept a Number from Key Board, Send to Server Side Program and Obtain Square of that Number.
#SquareClient.py
import socket
s=socket.socket()
s.connect(("localhost",9999))
print("CSP Got Connection from SSP")
#read the value from KBD
val=input("Enter a Value for Getting Its Square:")
s.send(val.encode())
res=s.recv(1024).decode()
print("Square({})={}".format(val,res))