#A. Write a Python Server Side Program in such way that It Should accept the message from Client Side Program and Gives Reply to the Client Side Program.
#ServerChat.py
import socket
s=socket.socket()
s.bind(("127.0.0.1",8558))
s.listen(2)
while(True):
	cs,ca=s.accept()
	cval=cs.recv(1024).decode()
	print("Student-->{}".format(cval))
	sval=input("KVR-->")
	cs.send(sval.encode())

