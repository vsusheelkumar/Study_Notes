#B. Write a Python Client Side Program in such way that It Should accept the message from Key Board and Gives Reply to the Server Side Program.
#ClientChat.py
import socket
while(True):
	s=socket.socket()
	s.connect(("127.0.0.1",8558))
	cval=input("Student-->")
	if(cval.lower()=="bye"):
		s.send(cval.encode())
		break
	else:
		s.send(cval.encode())
		sval=s.recv(1024).decode()
		print("KVR-->{}".format(sval))