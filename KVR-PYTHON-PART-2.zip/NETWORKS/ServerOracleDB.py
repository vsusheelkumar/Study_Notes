#A. Write a Python Server Side Program in such way that It Should accept the Emp Number from Client Side Program  and  Gives other details of employee to the Client Side Program.
#ServerOracleDB.py
import socket
import oracledb as orc
s=socket.socket()
s.bind(("localhost",3600))
s.listen(2)
print("SSP is ready to accept any CSP Request")
while(True):
	try:
		csock,caddr=s.accept()
		empno=int(csock.recv(1024).decode())
		print("Employee Number from Client=",empno)
		#Oracle Data base Connection Code
		con=orc.connect("system/tiger@localhost/orcl")
		cur=con.cursor()
		cur.execute("select * from employee where eno=%d" %empno)
		record=cur.fetchone()
		if(record!=None):
			s1="-----------------------------------------------------------"
			s2="Employee Number="+str(record[0])
			s3="Employee Name="+str(record[1])
			s4="Employee Salary="+str(record[2])
			s5="Employee Comp Name="+str(record[3])
			s6="-----------------------------------------------------------"
			fres=s1+"\n"+s2+"\n"+s3+"\n"+s4+"\n"+s5+"\n"+s6
			csock.send(fres.encode())
		else:
			csock.send("Employee Number Does not Exist".encode())
	except ValueError:
		csock.send("Don't Enter alnums,strs and symbols for empno".encode())
	except orc.DatabaseError as db:
		csock.send(("Problem in Oracle DB:"+db).encode())