#Program for Displaying Each and Every Char of Given Word
#ForLoopEx1.py
s="PYTHON"
print("By using while loop")
i=0
while(i<len(s)):
    print("\t{}".format(s[i]))
    i=i+1
print("---------------------------------")
print("By using for loop")
for k in s:
    print("\t{}".format(k))
else:
    print("---------------------------------")