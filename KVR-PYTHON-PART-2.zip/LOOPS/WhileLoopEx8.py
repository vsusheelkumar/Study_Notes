#Program for Cal Factorial of a Number
#n!= 1 x 2 x 3 x 4x......n  OR   nx (n-1) x (n-2)x......0!
# We know that 0!=1
#WhileLoopEx8.py
n=int(input("Enter a Number for Cal Factorial:"))
if(n<0):
    print("{} is Invalid Input".format(n))
else:
    fact=1
    i=1
    while(i<=n):
        fact=fact*i
        i=i+1
    else:
        print("Factorial({})={}".format(n,fact))