#Program for Generating N to 1 Numbers where N is +VE
#WhileLoopEx3.py
n=input("Enter How Many Numbers u want to Generate Decending Order:")
if(n.isalpha()):
    print("{} is Invalid Input".format(n))
elif(not n.isdigit()):
    print("{} is Invalid Input".format(n))
elif(int(n)<=0):
    print("{} is Invalid Input".format(n))
else:
    print("*" * 40)
    print("Numbers within {} to 1".format(n))
    print("*" * 40)
    i=int(n) # Initlization
    while(i>=1):
        print("\t{}".format(i))
        i=i-1
    else:
        print("*" * 40)
