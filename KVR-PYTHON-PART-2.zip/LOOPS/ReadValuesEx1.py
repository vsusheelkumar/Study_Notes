#Program for Reading the Values from KBD and display those values
#ReadValuesEx1.py
n=int(input("Enter How Many Values u want:"))
if(n<=0):
    print("{} is Invalid Input".format(n))
else:
    lst=[] # OR lst=list()--creating an empty list
    for i in range(1,n+1):
        val=float(input("Enter {} Value:".format(i)))
        lst.append(val)
    else:
        print("Given List of Elements={}".format(lst))