#Program for Generating primes within range n
#InnerLoopEx6.py
n=int(input("Enter the Range in which u want Prime Numbers:"))
if(n<=1):
    print("{} is Invalid input".format(n))
else:
    nop=0
    print("-"*50)
    print("List of Primes within the range:{}".format(n))
    print("-" * 50)
    for num in range(2,n+1):# Supplying the Numbers
        res=True
        for i in range(2,num):
            if(num%i==0):
                res=False
                break
        if(res):
            print("\t{}".format(num))
            nop=nop+1
    else:
        print("-" * 50)
        print("Number of Primes within {}={}".format(n,nop))
        print("-" * 50)




