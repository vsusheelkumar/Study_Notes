#Program for Cal sum of N Natural Numbers where N is +Ve
#WhileLoopEx4.py
n=int(input("Enter How Many Natural Numbers Sum u want Find:"))
if(n<=0):
    print("{} is Invalid Input".format(n))
else:
    print("-"*50)
    print("Natural Numbers within:{}".format(n))
    print("-" * 50)
    i=1
    s=0 # Initlization Part--Additive Identity
    while(i<=n):
        print("\t{}".format(i))
        s = s + i  # we are accumulating the i Values
        i+=1 # Short Hand + Operator
    else:
        print("-" * 50)
        print("Sum={}".format(s))
        print("-" * 50)



