#Program for Demonstrating Inner Loops--while loop in for loop
#InnerLoopEx4.py
for i in range(5,0,-1): # Outer Loop
    print("="*50)
    print("Outer loop--Val of i={}".format(i))
    print("=" * 50)
    j=1
    while(j<=3): # Inner loop
        print("\tInner loop-Value of j={}".format(j))
        j=j+1
    else:
        print("\tOut-off inner loop")
        print("-"*50)
else:
    print("Out-off outer loop")
    print("=" * 50)
