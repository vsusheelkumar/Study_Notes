#Program for Finding the Factors
#WhileLoopEx10.py
n=int(input("Enter a Number for Finding Its Factors:"))
if(n<=0):
    print("{} is Invalid Input".format(n))
else:
    print("*"*50)
    print("Factors of :{}".format(n))
    print("*" * 50)
    i=1
    while(i<=(n//2)):
        if(n%i==0):
            print("\t\t{}".format(i))
        i=i+1
    else:
        print("\t\t{}".format(n))
        print("*" * 50)

