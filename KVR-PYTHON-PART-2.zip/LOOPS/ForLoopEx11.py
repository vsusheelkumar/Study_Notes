#Program for accepting Line of Text and Display the words of line in Opp Order
#ForLoopEx11.py
line=input("Enter a Line of Text:") #  Python is an oop lang
words=line.split() # words=['Python', 'is', 'an', 'oop', 'lang']
for word in words[::-1]:
    print(word,"--->",word[::-1])
print("--------------------------------------------")
for index in range(len(words)-1,-1,-1):
    print(words[index])
print("--------------------------------------------")
for index in range(len(words)-1,-1,-1):
    print(words[index],"--->",words[index][::-1])
print("--------------------------------------------")