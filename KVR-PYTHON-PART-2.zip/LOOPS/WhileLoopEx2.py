#Program for Generating 1 to N Numbers where N is +VE
#WhileLoopEx2.py
n=input("Enter How Many Numbers u want to Generate:")
if(n.isalpha()):
    print("{} is Invalid Input".format(n))
elif(not n.isdigit()):
    print("{} is Invalid Input".format(n))
elif(int(n)<=0):
    print("{} is Invalid Input".format(n))
else:
    print("*" * 40)
    print("Numbers within {}".format(n))
    print("*" * 40)
    i = 1  # Initlization Part
    while (i <= int(n)):  # Cond Part
        print("\t{}".format(i))
        i = i + 1  # Updation Part
    else:
        print("*" * 40)



