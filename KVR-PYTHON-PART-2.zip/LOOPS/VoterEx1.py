#Prohgram for accepting age of a Person and Decides Elgible to Vote or Not
#VoterEx1.py
while(True):
    age=int(input("Enter Ur Age:"))
    if(age>=18):
        print("\t{} Years Citizen is Eligible to Vote:".format(age))
        break
    else:
        print("\t{} Years Citizen is Not Eligible to Vote:".format(age))
