#Program for Generating  random Multiplication Tables
#InnerLoopEx7.py
n=int(input("Enter How Many Mul Tables u want:"))
if(n<=0):
    print("{} is Invalid input".format(n))
else:
    lst=[]
    for i in range(1,n+1):
        val=int(input("Enter {} Value:".format(i)))
        lst.append(val)
    else:
        print("-"*50)
        print("Given List of Values")
        print("\t\t{}".format(lst)) # [19, -5, -23, 16, 0, 45]
        print("-" * 50)
        #Code Mul Table for Random Numbers
        for num in lst: # Outer loop--Supply the Value from list
            if(num<=0):
                continue
            print("="*50)
            print("Mul Table for:{}".format(num))
            print("=" * 50)
            for i in range(1,11): # Inner loop--Generates mul Table
                print("\t{} x {} = {}".format(num,i,num*i))
            else:
                print("=" * 50)



