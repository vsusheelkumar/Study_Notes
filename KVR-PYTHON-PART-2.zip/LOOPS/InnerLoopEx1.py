#Program for Demonstrating Inner Loops--for loop in for loop
#InnerLoopEx1.py
for i in range(1,5): # Outer Loop
    print("="*50)
    print("Outer loop--Val of i={}".format(i))
    print("=" * 50)
    for j in range(1,4): # Inner loop
        print("\tInner loop-Value of j={}".format(j))
    else:
        print("\tOut-off inner loop")
        print("-"*50)
else:
    print("Out-off outer loop")
    print("=" * 50)
