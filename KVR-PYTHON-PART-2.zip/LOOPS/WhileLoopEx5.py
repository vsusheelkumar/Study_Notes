#Program for Cal sum of Squares of N Natural Numbers where N is +Ve
#WhileLoopEx5.py
n=int(input("Enter How Many Natural Numbers Squares Sum u want Find:"))
if(n<=0):
    print("{} is Invalid Input".format(n))
else:
    print("-"*50)
    print("Natural Numbers:\t\tSquares")
    print("-" * 50)
    i=1
    s=0 # Initlization Part--Additive Identity
    ss=0 # Initlization Part--Additive Identity
    while(i<=n):
        print("\t{}\t\t\t\t\t{}".format(i,i*i))
        s = s + i  # we are accumulating the i Values
        ss=ss+i**2
        i+=1 # Short Hand + Operator
    else:
        print("-" * 50)
        print("Sum={}\t\t\t\t\t{}".format(s,ss))
        print("-" * 50)



