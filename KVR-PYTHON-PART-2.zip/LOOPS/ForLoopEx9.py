#Program for Generating Mul Table for a Given Number
#ForLoopEx9.py
n=int(input("Enter a Number for Generating Mul Table:"))
if(n<=0):
    print("{} is invalid Input".format(n))
else:
    print("-"*40)
    print("while loop---MuTable for {}".format(n))
    i=1
    while(i<=10):
        print("\t{} x {} = {}".format(n,i,n*i))
        i=i+1
    else:
        print("-" * 40)
    print("------------------------------------------------")
    print("for loop---MuTable for {}".format(n))
    for i in range(1,11):
        print("\t{} x {}={}".format(n,i,n*i))
    else:
        print("-" * 40)