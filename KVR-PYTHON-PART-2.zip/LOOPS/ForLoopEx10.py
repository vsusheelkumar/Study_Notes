#Program for accepting Line of Text and Display the words of line
#ForLoopEx10.py
line=input("Enter a Line of Text:") #  Python is an oop lang
words=line.split() # words=['Python', 'is', 'an', 'oop', 'lang']
if(len(words)!=0):
    for word in words:
        print("\t{}".format(word))
else:
    print("Ur Line is empty--can't find number of words")



