#Program for Displaying 1 to N where N is +Ve
#ForLoopEx2.py
n=int(input("Enter How Many Numbers u want to Generate:"))
if(n<=0):
    print("{} is Invalid Input".format(n))
else:
    print("Numbers within:{}".format(n))
    for i in range(1,n+1):
        print("\t{}".format(i))
    else:
        print("="*50)
