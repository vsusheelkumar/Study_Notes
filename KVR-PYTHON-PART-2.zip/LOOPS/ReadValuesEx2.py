#Program for Reading the Words from KBD and display those values
#ReadValuesEx1.py
n=int(input("Enter How Many Words u want:"))
if(n<=0):
    print("{} is Invalid Input".format(n))
else:
    lst=list()#--creating an empty list
    for i in range(1,n+1):
        val=input("Enter {} Value:".format(i))
        lst.append(val)
    else:
        print("Given List of Words={}".format(lst))