#Program for Demonstrating Inner Loops--while loop in while loop
#InnerLoopEx2.py
i=1
while(i<=5): # Outer Loop
    print("="*50)
    print("Outer loop--Val of i={}".format(i))
    print("=" * 50)
    j=1
    while(j<=3): # Inner loop
        print("\tInner loop-Value of j={}".format(j))
        j=j+1
    else:
        i=i+1
        print("\tOut-off inner loop")
        print("-"*50)
else:
    print("Out-off outer loop")
    print("=" * 50)
