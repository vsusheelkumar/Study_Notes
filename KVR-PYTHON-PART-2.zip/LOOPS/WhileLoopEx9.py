#Program for Cal Factorial of a Number
#n!= 4x3x2x1........0!  OR   nx (n-1) x (n-2)x......0!
# We know that 0!=1
#WhileLoopEx9.py
n=int(input("Enter a Number for Cal Factorial:"))
if(n<0):
    print("{} is Invalid Input".format(n))
else:
    fact=1
    i=n
    while(i>0):
        fact*=i
        i-=1
    else:
        print("\t\t{}!={}".format(n,fact))