#Program for accepting List of Values and Find Their Sum and Average
#ListValuesWithSumAvgEx1.py
n=int(input("Enter How Numbers u have:"))
if(n<=0):
    print("{} is Invalid input".format(n))
else:
    print("-" * 50)
    lst=[]
    print("Enter {} Values:".format(n))
    for i in range(1,n+1):
        val=float(input())
        lst.append(val)
    else:
        print("-"*50)
        print("Given List of Values")
        print(lst) # [45.0, 12.0, 456.0, 23.0, 89.0]
        #code for Finding sum and average
        s=0
        for val in lst:
            s+=val
        else:
            print("Sum={}".format(s))
            print("Average={}".format(s/len(lst)))
            print("-----------OR------------------")
            print("Average={}".format(s / n))
        print("-" * 50)

