#Program Implementsing Student Marks Report
#StudentMarksReportEx1.py
#Accept the student number and Validate with the range of 100 to 200
while(True):
    sno=int(input("Enter Student Number:"))
    if(sno>=100) and (sno<=200):
        break
    else:
        print("\t{} is Invalid student Number-try again".format(sno))
#Accept the student name and Validate
while(True):
    name=input("Enter Ur Name:") # Guido Van Rossum
    words=name.split()
    res=True
    for word in words:
        if(not word.isalpha()):
            res=False
            break
    if(res):
        break
    else:
        print("\t'{}' is In Valid Name".format(name))
#Accept the student Marks in C and Validate
while(True):
    cm=int(input("Enter Marks in C:"))
    if(cm in range(0,101)):
        break
    else:
        print("\t'{}' is In Valid Marks".format(cm))

#Accept the student Marks in CPP and Validate
while(True):
    cppm=int(input("Enter Marks in C++:"))
    if(0<=cppm<=100):
        break
    else:
        print("\t'{}' is In Valid Marks".format(cppm))

#Accept the student Marks in PYTHON and Validate
while(True):
    pym=int(input("Enter Marks in PYTHON:"))
    if(0<=pym<=100):
        break
    else:
        print("\t'{}' is In Valid Marks".format(pym))
#Calculate total marks and percentage of marks
totmarks=cm+cppm+pym
percent=(totmarks/300)*100
if(cm<40) or (cppm<40) or (pym<40):
    grade="FAIL"
else:
    if(totmarks in range(250,301)):
        grade="DISTINCTION"
    elif(totmarks in range(200,250)):
        grade="FIRST"
    elif (totmarks in range(150, 200)):
        grade = "SECOND"
    elif (totmarks in range(120,150)):
        grade = "THIRD"
#Display the Student Marks Report
print("*"*50)
print("\t\tSTUDENT MARKS REPORT")
print("*"*50)
print("\t\tStudent Number:{}".format(sno))
print("\t\tStudent Name:{}".format(name))
print("\t\tStudent Marks in C:{}".format(cm))
print("\t\tStudent Marks in C++:{}".format(cppm))
print("\t\tStudent Marks in PYTHON:{}".format(pym))
print("\t\tStudent Total Marks:{}".format(totmarks))
print("\t\tStudent Percentage of Marks:{}".format(percent))
print("\t\tStudent Grade:{}".format(grade))
print("*"*50)
