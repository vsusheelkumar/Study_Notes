#Program for Demonstrating Inner Loops--for loop in while loop
#InnerLoopEx3.py
i=1
while(i<=5): # Outer Loop
    print("="*50)
    print("Outer loop--Val of i={}".format(i))
    print("=" * 50)
    for j in range(3,0,-1): # Inner loop
        print("\tInner loop-Value of j={}".format(j))
    else:
        i=i+1
        print("\tOut-off inner loop")
        print("-"*50)
else:
    print("Out-off outer loop")
    print("=" * 50)
