#Program for Reading List of Numerical Values and Obtain Positive and Negative Values
#GetPosNegValuesEx2.py
n=int(input("Enter How Many Values u want:"))
if(n<=0):
    print("{} is Invalid Input".format(n))
else:
    lst=[] # OR lst=list()--creating an empty list
    for i in range(1,n+1):
        val=float(input("Enter {} Value:".format(i)))
        lst.append(val)
    else:
        print("Given List of Elements={}".format(lst))
        #lst=[10.0, -23.0, 45.0, -67.0, 78.0]
        #Code for Getting +Ve and -Ve Values
        pslist=list()
        nglist=list()
        for val in lst:
            if(val>0):
                pslist.append(val)
            elif(val<0):
                nglist.append(val)
        else:
            print("List of +Ve Values={} and we Found {} +Ve Elements".format(pslist, len(pslist)))
            print("List of -Ve Values={} and we Found {} -Ve Elements".format(nglist, len(nglist)))

