#Program for Cal sum of Squares and cubes of N Natural Numbers where N is +Ve
#WhileLoopEx6.py
n=int(input("Enter How Many Natural Numbers Squares and cubes Sum u want Find:"))
if(n<=0):
    print("{} is Invalid Input".format(n))
else:
    print("-"*50)
    print("Natural Numbers:\t\tSquares:\t\tCubes")
    print("-" * 50)
    i=1
    s,ss,cs=0,0,0 # Initlization Part--Additive Identity
    while(i<=n):
        print("\t{}\t\t\t\t\t{}\t\t\t\t\t{}".format(i,i*i,i**3))
        s = s + i  # we are accumulating the i Values
        ss=ss+i**2
        cs=cs+i**3
        i+=1 # Short Hand + Operator
    else:
        print("-" * 50)
        print("Sum={}\t\t\t\t\t{}\t\t\t\t\t{}".format(s,ss,cs))
        print("-" * 50)



