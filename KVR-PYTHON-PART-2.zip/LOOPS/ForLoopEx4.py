#Program for Displaying all even numbers within N where N is +Ve
#ForLoopEx4.py
n=int(input("Enter How Many Even Numbers u want to Generate:"))
if(n<=0):
    print("{} is Invalid Input".format(n))
else:
    print("for loop--Even Numbers within:{}".format(n))
    if(n%2!=0):
        n=n-1
    for v in range(n,1,-2):
        print("\t{}".format(v))
