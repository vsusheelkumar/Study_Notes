#Program for Accepting List of Words and Find Their Length
#WordswithLength.py
n=int(input("Enter How Many Words u want:"))
if(n<=0):
    print("{} is Invalid Input".format(n))
else:
    print("-"*50)
    lst=list()#--creating an empty list
    for i in range(1,n+1):
        val=input("Enter {} Value:".format(i))
        lst.append(val)
    else:
        print("-" * 50)
        print("Given List of Words={}".format(lst))
        print("-" * 50)
        #Code for Getting words and Length
        for word in lst:
            print("\t{}---->{}".format(word,len(word)))
        print("-" * 50)