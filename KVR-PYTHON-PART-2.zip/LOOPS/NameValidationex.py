#Program for Validating the Name of the Person/ Product / Place
#NameValidationex.py
while(True):
    name=input("Enter Ur Name:") # Guido Van Rossum
    words=name.split()
    res=True
    for word in words:
        if(not word.isalpha()):
            res=False
            break
    if(res):
        print("\t'{}' is Valid Name".format(name))
        break
    else:
        print("\t'{}' is In Valid Name".format(name))

