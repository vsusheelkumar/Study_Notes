#Program for Displaying all even numbers within N where N is +Ve
#ForLoopEx3.py
n=int(input("Enter How Many Even Numbers u want to Generate:"))
if(n<=0):
    print("{} is Invalid Input".format(n))
else:
    print("for loop--Even Numbers within:{}".format(n))
    for i in range(2,n+1,2):
        print("\t{}".format(i))
    else:
        print("="*50)
        print("for loop--Odd Numbers within:{}".format(n))
        for i in range(1,n+1,2):
            print("\t{}".format(i))
        else:
            print("=" * 50)

