#Program for Cal Product of N Natural Numbers where N is +Ve
#WhileLoopEx7.py
n=int(input("Enter How Many Natural Numbers Product u want Find:"))
if(n<=0):
    print("{} is Invalid Input".format(n))
else:
    print("-"*50)
    print("Natural Numbers within:{}".format(n))
    print("-" * 50)
    i=1
    p=1 # Multiplicative Identity
    while(i<=n):
        print("\t\t{}".format(i))
        p=p*i #OR  p*=i
        i=i+1 # OR i+=1
    else:
        print("-" * 50)
        print("Product={}".format(p))
        print("-" * 50)