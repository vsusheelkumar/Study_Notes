#Prohgram for accepting age of a Person and Decides Elgible to Vote or Not
#VoterEx2.py
age=int(input("Enter Ur Age:"))
if(age>=18):
    print("\t{} Years Citizen is Eligible to Vote:".format(age))
else:
   print("\t{} Years Citizen is Not Eligible to Vote:".format(age))

