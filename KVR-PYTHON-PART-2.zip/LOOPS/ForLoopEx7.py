#Program for Displaying Each and Every Char of Given Word
#ForLoopEx7.py
s="PYTHON"
print("---------------------------------")
print("By using for loop")
for k in range(2,len(s)):
    print("\t{}".format(s[k]))
else:
    print("---------------------------------")