#Program for Demonstrating generators importance
#GenEx6.py
def getcourses():
	yield "PYTHON"
	yield "C"
	yield "DSA"

#Main Program
crs=getcourses()
print("type of crs=",type(crs))
print(next(crs))
print(next(crs))
print(next(crs))
