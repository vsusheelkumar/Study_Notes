#Program for Demonstrating generators importance
#GenEx3.py
def kvrrange(val):
	i=1
	while(i<=val):
		yield i
		i=i+1

#Main Program
r=kvrrange(10)
print("type of r=",type(r)) # type of r= <class 'generator'>
#extract the data from generator object by using next()
for val in r:
	print(val)