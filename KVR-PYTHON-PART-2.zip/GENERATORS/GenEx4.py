#Program for Demonstrating generators importance
#GenEx4.py
def kvrrange(start,stop):
	while(start<=stop):
		yield start
		start=start+1

#Main Program
r=kvrrange(10,20) # here r is an object of generator
print("type of r=",type(r))
print(next(r))
print(next(r))
while(True):
	try:
		print("\t{}".format(next(r)))
	except StopIteration:
		break
print("----------------------------------------")
r1=kvrrange(100,110) # here r1 is an object of generator
for val in r1:
	print("\t{}".format(val))
