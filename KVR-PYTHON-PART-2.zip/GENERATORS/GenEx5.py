#Program for Demonstrating generators importance
#GenEx5.py
def kvrrange(start,stop=1,step=1):
	if(start>stop):
		stop=start
		start=1
	while(start<=stop):
		yield start
		start=start+step

#Main Program
r=kvrrange(10,20,2) # here r is an object of generator
while(True):
	try:
		print("\t{}".format(next(r)))
	except StopIteration:
		break
print("----------------------------------------")
r1=kvrrange(100,110) # here r1 is an object of generator
while(True):
	try:
		print("\t{}".format(next(r1)))
	except StopIteration:
		break
print("----------------------------------------")
r2=kvrrange(5) # here r1 is an object of generator
while(True):
	try:
		print("\t{}".format(next(r2)))
	except StopIteration:
		break
print("----------------------------------------")
