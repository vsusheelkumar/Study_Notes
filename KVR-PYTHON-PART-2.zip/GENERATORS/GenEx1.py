#Program for Demonstrating generators importance
#GenEx1.py
import sys
def kvrrange(val):
	i=1
	while(i<=val):
		yield i
		i=i+1

#Main Program
r=kvrrange(5)
print("type of r=",type(r)) # type of r= <class 'generator'>
#extract the data from generator object by using next()
try:
	print(next(r))
	print(next(r))
	print(next(r))
	print(next(r))
	print(next(r))
	print(next(r))
except StopIteration:
	sys.exit()