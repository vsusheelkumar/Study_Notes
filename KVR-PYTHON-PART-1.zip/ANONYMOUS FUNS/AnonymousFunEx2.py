#Program for Finding Biggest and Smallest of Two Numbers by using Anonymous Functions
#AnonymousFunEx2.py

findmax=lambda a,b:a if a>b else b if b>a else "Both Values are Equal"
findmin=lambda k,v: k if k<v else v if v<k else "Both Values are Equal"

#Main Program
a=float(input("Enter First Value:"))
b=float(input("Enter Second Value:"))
maxv=findmax(a,b)
minv=findmin(a,b)
print("Max({},{})={}".format(a,b,maxv))
print("Min({},{})={}".format(a,b,minv))

