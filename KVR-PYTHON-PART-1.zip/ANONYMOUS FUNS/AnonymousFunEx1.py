#Program for Adding Two Numbers bysing Anonymous Functions
#AnonymousFunEx1.py
def addop(a,b): # Normal function
    return(a+b)

sumop=lambda  a,b : a+b # Anonymous Function Def

#Main Program
print("Type of addop=",type(addop)) # <class 'function'>
res=addop(10,20)
print("Sum by using Normal Functions=",res)
print("-------------------------------------")
print("Type of sumop=",type(sumop)) # <class 'function'>
res=sumop(100,200)
print("Sum by using Anonymous Function=",res)