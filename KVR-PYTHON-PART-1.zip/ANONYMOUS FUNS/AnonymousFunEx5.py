#Program for Finding Biggest and Smallest For  List of Numbers by using Anonymous Functions
#AnonymousFunEx4.py
def kvrmax(lst): # Lst=[10 2 34 5 -6 0 12 56 ]
    maxv=lst[0]
    for val in lst:
        if val>maxv:
            maxv=val
    return maxv

def kvrmin(lst):
    minv = lst[0]
    for val in lst:
        if val < minv:
            minv = val
    return minv


findmax=lambda lstobj:kvrmax(lstobj)
findmin=lambda lstobj:kvrmin(lstobj)

#Main Program
print("Enter List of Values separated by Space:")
lst=[float(val) for val in input().split()]
print("Elements of List=",lst)
maxv=findmax(lst)
minv=findmin(lst)
print("Max Value:{}".format(maxv))
print("Min Value:{}".format(minv))

