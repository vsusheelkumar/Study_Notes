#Program for Finding Biggest and Smallest For  List of Numbers by using Anonymous Functions
#AnonymousFunEx4.py
findmax=lambda lstobj:max(lstobj)
findmin=lambda lstobj:min(lstobj)

#Main Program
print("Enter List of Values separated by Space:")
lst=[float(val) for val in input().split()]
print("Elements of List=",lst)
maxv=findmax(lst)
minv=findmin(lst)
print("Max Value:{}".format(maxv))
print("Min Value:{}".format(minv))

