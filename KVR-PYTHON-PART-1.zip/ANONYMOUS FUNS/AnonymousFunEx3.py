#Program for Finding Biggest and Smallest of Three Numbers by using Anonymous Functions
#AnonymousFunEx3.py

findmax=lambda a,b,c : a if b<=a>c else b if a<b>=c else c if a<=c>b else "All Values are Equal"
findmin=lambda k,v,r:k if (k<=v) and (k<r) else v if (v<k) and (v<=r) else r if (r<=k) and (r<v) else "All Values are equal"

#Main Program
a=float(input("Enter First Value:"))
b=float(input("Enter Second Value:"))
c=float(input("Enter Third Value:"))
maxv=findmax(a,b,c)
minv=findmin(a,b,c)
print("Max({},{},{})={}".format(a,b,c,maxv))
print("Min({},{},{})={}".format(a,b,c,minv))

