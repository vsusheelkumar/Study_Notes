#DateToStr.py
from datetime import date
# calling the today function of date class
tod = date.today()
print("Today date=",tod)
# Converting the date to the string
Str = date.isoformat(tod)
print("String Representation=", Str) # String Representation 2021-08-19 
print(type(Str)) # <class 'str'>