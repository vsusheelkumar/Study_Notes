#CurrentDateDayInfo.py
from datetime import datetime
td=datetime.now()
print("current date and time")
print(td)
print("-------------------------------------")
print("Day Number of Year=",td.strftime("%j"))
print("Week Number of Year(Sunday Starts)=",td.strftime("%U"))
print("Week Number of Year(Monday Starts)=",td.strftime("%W"))
print("Century=",td.strftime("%C"))
print("Local Version of date =",td.strftime("%x"))
print("Local Version of time=",td.strftime("%X"))
print("-------------------------------------")
print("Week Day(ISO-8601):",td.strftime("%u"))
print("Week Number(ISO-8601):",td.strftime("%V"))

