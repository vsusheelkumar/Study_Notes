#CurrentDateTimeWeekName.py
from datetime import datetime
td=datetime.now()
print("current date and time")
print(td)
print("-------------------------------------")
#Get Week Name in Short--use %a
print("Short Week Name:",td.strftime("%a"))  #Wed
print("Full Week Name:",td.strftime("%A"))  #Wed
print("-------------------------------------")
print("Week Number:",td.strftime("%w"))
print("Day of the Month:",td.strftime("%d"))