#CurrentDateHourInfo.py
from datetime import datetime
td=datetime.now()
print("current date and time")
print(td)
print("-------------------------------------")
print("Hour in 24 Hours Format:",td.strftime("%H"))
print("Hour in 12 Hours Format:",td.strftime("%I"))
print("Are we in AM / PM:",td.strftime("%p"))
print("Minutes:",td.strftime("%M"))
print("Seconds:",td.strftime("%S"))
print("Micro Seconds:",td.strftime("%f"))

