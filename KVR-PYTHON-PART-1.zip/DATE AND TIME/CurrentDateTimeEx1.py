#CurrentDateTimeEx1.py
import datetime
td=datetime.datetime.now()
print("current date and time")
print(td)