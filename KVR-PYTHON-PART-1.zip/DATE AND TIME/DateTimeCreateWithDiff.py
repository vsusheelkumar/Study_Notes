#DateTimeCreateWithDiff.py
from datetime import datetime
from dateutil.relativedelta import relativedelta
start_time = datetime(2022, 4, 28, 12, 0, 0)
end_time = datetime(2023, 10, 1, 8, 15, 25)
# Calculate the difference
time_diff = relativedelta(end_time, start_time)
