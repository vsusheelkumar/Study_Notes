#Program for Accepting a Value and Decide
# whether It is +VE or -VE or ZERO by using Simple if statement
#IfElifElseStmtEx2.py
value=float(input("Enter Any Number:"))
if(value==0):
    print("{} is ZERO".format(value))
elif(value<0):
        print("{} is -VE Value".format(value))
else:
    print("{} is +VE Value".format(value))
print("I am from Outer If--else Statement")