#Program for Accepting a Value and Decide
# whether It is Palindrome or by using Simple if statement
#IfElifElseStmtEx1.py
val=input("Enter Any Value:") # LIRIL
if(val==val[::-1]):
    print("{} is Palindrome".format(val))
elif(val!=val[::-1]):
    print("{} is Not Palindrome".format(val))
print("Program execution completed")