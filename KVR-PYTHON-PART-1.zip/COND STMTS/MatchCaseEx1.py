#Program for Performinh all Arithmetic Operations by using match Case
#MatchCaseEx1.py
print("*"*50)
print("\tARITHMETIC OPERATIONS")
print("*"*50)
print("\t1.Addition")
print("\t2.Substraction")
print("\t3.Multiplication")
print("\t4.Division")
print("\t5.Modulo Division")
print("\t6.Exponentiation")
print("\t7.Exit")
print("*"*50)
ch=int(input("Enter Ur Choice:"))
match(ch):
    case 1:
        a,b=float(input("Enter First Value:")),float(input("Enter Second Value:"))
        print("\tSum({},{})={}".format(a,b,a+b))
    case 2:
        a, b = float(input("Enter First Value:")), float(input("Enter Second Value:"))
        print("\tSub({},{})={}".format(a, b, a-b))
    case 3:
        a, b = float(input("Enter First Value:")), float(input("Enter Second Value:"))
        print("\tMul({},{})={}".format(a, b, a * b))
    case 4:
        a, b = float(input("Enter First Value:")), float(input("Enter Second Value:"))
        print("\tDiv({},{})={}".format(a, b, a / b))
        print("\tFloor Div({},{})={}".format(a, b, a // b))
    case 5:
        a, b = float(input("Enter First Value:")), float(input("Enter Second Value:"))
        print("\tMod({},{})={}".format(a, b, a % b))
    case 6:
        a, b = float(input("Enter Base Value:")), float(input("Enter Power Value:"))
        print("\tPow({},{})={}".format(a, b, a ** b))
    case 7:
        print("Thx for Using this Program")
    case _: # Deafult Block
        print("Ur Selection of Operation is Wrong")

print("Match Case concept completed")
