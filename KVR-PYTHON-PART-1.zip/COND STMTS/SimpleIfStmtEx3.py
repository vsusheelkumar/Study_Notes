#Program for Accepting a Value and Decide
# whether It is +VE or -VE or ZERO by using Simple if statement
#SimpleIfStmtEx2.py
value=input("Enter Any Number:")
if(value.startswith("-") and (value[1:].isdigit())):
    if(int(value)==0):
        print("{} is ZERO".format(value))
    if(int(value)>0):
        print("{} is +VE".format(value))
    if(int(value)<0):
        print("{} is -VE".format(value))

if(not value.isdigit()) and(not value.startswith("-")):
    print("Don't enter alnums,strs and symbols")