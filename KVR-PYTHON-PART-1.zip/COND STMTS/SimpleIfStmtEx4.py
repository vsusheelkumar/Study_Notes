#Program for accepting any Digit and Display Its Name
#SimpleIfStmtEx4.py
d=int(input('Enter Any Digit:')) # d=0 1 2 3 4 5 6 7 8 9
if(d==0):
    print("ZERO")
if(d==1):
    print("ONE")
if(d==2):
    print("TWO")
if(d==3):
    print("THREE")
if(d==4):
    print("FOUR")
if(d==5):
    print("FIVE")
if(d==6):
    print("SIX")
if(d==7):
    print("SEVEN")
if(d==8):
    print("EIGHT")
if(d==9):
    print("NINE")
if(d>9):
    print("{} is Number".format(d))
if d in [-1,-2,-3,-4,-5,-6,-7,-8,-9]:
    print("{} is -VE Digit".format(d))
if(d<0) and (d not in [-1,-2,-3,-4,-5,-6,-7,-8,-9]):
    print("{} is -VE Number".format(d))