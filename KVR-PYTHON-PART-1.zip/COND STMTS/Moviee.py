#Moviee.py
tkt=input("Do u have a Ticket:")
if(tkt.upper()=="YES"):
    print("Enter into Theater")
    print("Watch the Moviee")
    print("Understand the Message")
print("Goto Home")