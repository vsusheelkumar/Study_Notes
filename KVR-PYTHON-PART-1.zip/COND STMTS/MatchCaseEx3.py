#MatchCaseEx3.py
wkd=input("Enter the Week Name:")
match(wkd.upper()):
    case "MONDAY"|"TUESDAY" |"WEDNESDAY" |"THURSDAY" |"FRIDAY":
        print("{} is Working Day".format(wkd))
    case "SATURDAY":
        print("{} is Week End".format(wkd))
    case "SUNDAY":
        print("{} is Holy Day".format(wkd))
    case _:
        print("{} is not week day".format(wkd))
