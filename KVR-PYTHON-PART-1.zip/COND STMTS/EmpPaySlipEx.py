#EmpPaySlipEx.py
#accept the employee details
empno=int(input("Enter Employee Number:"))
name=input("Enter Employee Name:")
empsal=float(input("Enter Employee Basic Salary:"))
empdsg=input("Enter Employee Designation:")
if(empsal<=0):
    print("{} Invalid Salary to an employee".format(empsal))
else:
    #if the Basic Salary is More than or equal to  10000 then given the following
    if(empsal>=10000):
        da = 20/100*(empsal)
        ta = 10/100*(empsal)
        hra = 9/100*(empsal)
        ma = 1/100*(empsal)
        lic = (2/100) *(empsal)
        gpf = (1/100)*(empsal)
    else:
        da = (10/100)*empsal
        ta = (7.5/100)*empsal
        hra = (6/100)*empsal
        ma = (1/100)*empsal
        lic = (1.5/100)*empsal
        gpf = (0.5/100)*empsal
    netsal=(empsal+da+ta+hra+ma)-(lic+gpf)
    #Dsiplay the Emp Pay Slip
    print("*"*50)
    print("Employee Pay Slip")
    print("*" * 50)
    print("\tEmployee Number:{}".format(empno))
    print("\tEmployee Name:{}".format(name))
    print("\tEmployee Basic Salary:{}".format(empsal))
    print("\tEmployee Designation:{}".format(empdsg))
    print("\tEmployee DA:{}".format(da))
    print("\tEmployee TA:{}".format(ta))
    print("\tEmployee HRA:{}".format(hra))
    print("\tEmployee MA:{}".format(ma))
    print("Deductions")
    print("\tEmployee LIC:{}".format(lic))
    print("\tEmployee GPF:{}".format(gpf))
    print("\tNET SALARY:{}".format(netsal))
    print("*" * 50)
