#Program for Accepting a Value and Decide
# whether It is +VE or -VE or ZERO by using Simple if statement
#SimpleIfStmtEx2.py
value=float(input("Enter Any Number:"))
if(value==0):
    print("{} is ZERO".format(value))
if(value>0):
    print("{} is +VE".format(value))
if(value<0):
    print("{} is -VE".format(value))
