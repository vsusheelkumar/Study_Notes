#Program for Generating Sales Report
#SalesReportEx.py
prodcode1=input("Enter Product Code for First Item:")
prodname1=input("Enter Product Code for First Name:")
prodprice1=float(input("Enter Product Price for First Item:"))
proddiscount1=float(input("Enter Product Discount for First Item:"))
afterdis1=prodprice1*(10/100)

prodcode2=input("Enter Product Code for Second Item:")
prodname2=input("Enter Product Code for Second Name:")
prodprice2=float(input("Enter Product Price for Second Item:"))
proddiscount2=float(input("Enter Product Discount for Second Item:"))
afterdis2=prodprice2*(8/100)

prodcode3=input("Enter Product Code for Third Item:")
prodname3=input("Enter Product Code for Third Name:")
prodprice3=float(input("Enter Product Price for Third Item:"))
proddiscount3=float(input("Enter Product Discount for Third Item:"))
afterdis3=prodprice3*(11/100)

prodcode4=input("Enter Product Code for Fourth Item:")
prodname4=input("Enter Product Code for Fourth Name:")
prodprice4=float(input("Enter Product Price for Fourth Item:"))
proddiscount4=float(input("Enter Product Discount for Fourth Item:"))
afterdis4=prodprice4*(20/100)
#calculate total amount
totamt=prodprice1+prodprice2+prodprice3+prodprice4
totdis=afterdis1+afterdis2+afterdis3+afterdis4
totpay=totamt-totdis
#display Product Sales Report
print("-"*60)
print("\t\t\t\t\tSales Bill")
print("-"*60)
print("\tProdCode\t\tProduct Name\t\tPrice\t\t%Discount\t\tDiscountAmt")
print("-"*60)
print("\t{}\t\t{}\t\t\t\t\t{}\t\t{}\t\t{}".format(prodcode1,prodname1,prodprice1,proddiscount1,afterdis1))
print("\t{}\t\t{}\t\t\t\t\t{}\t\t{}\t\t{}".format(prodcode2,prodname2,prodprice2,proddiscount2,afterdis2))
print("\t{}\t\t{}\t\t\t\t\t{}\t\t{}\t\t{}".format(prodcode3,prodname3,prodprice3,proddiscount3,afterdis3))
print("\t{}\t\t{}\t\t\t\t\t{}\t\t{}\t\t{}".format(prodcode4,prodname4,prodprice4,proddiscount4,afterdis4))
print("\t\t\t\t\tTotal:{}\t\t\t\t\t\t{}".format(totamt,totdis))
print("\t\tNetAmount to Pay After Discount:{}".format(totpay))
print("-"*60)


