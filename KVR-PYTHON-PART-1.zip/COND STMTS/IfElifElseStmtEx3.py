#Program for accepting any Digit and Display Its Name
#IfElifElseStmtEx3.py
d=int(input('Enter Any Digit:')) # d=0 1 2 3 4 5 6 7 8 9
if(d==0):
    print("ZERO")
elif(d==1):
    print("ONE")
elif(d==2):
    print("TWO")
elif(d==3):
    print("THREE")
elif(d==4):
    print("FOUR")
elif(d==5):
    print("FIVE")
elif(d==6):
    print("SIX")
if(d==7):
    print("SEVEN")
elif(d==8):
    print("EIGHT")
elif(d==9):
    print("NINE")
elif(d>9):
    print("{} is Number".format(d))
elif d in [-1,-2,-3,-4,-5,-6,-7,-8,-9]:
    print("{} is -VE Digit".format(d))
elif(d<0) and (d not in [-1,-2,-3,-4,-5,-6,-7,-8,-9]):
    print("{} is -VE Number".format(d))