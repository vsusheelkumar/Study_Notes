#MatchCaseEx3.py
wkd=input("Enter the Week Name:")
if wkd.upper() in ["MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY","SUNDAY","MON","TUE","WED","THU","FRI","SAT","SUN"]:
    match(wkd.upper()[0:3]):
        case "MON"|"TUE" |"WED" |"THU" |"FRI":
            print("{} is Working Day".format(wkd))
        case "SAT":
            print("{} is Week End".format(wkd))
        case "SUN":
            print("{} is Holy Day".format(wkd))
else:
    print("{} is not week day".format(wkd))
