#ClosuresEx3.py
import time
def sethour(h):
	def setmin(m):
		for i in range(m,60):
			print("\t{}:{}".format(h,i))
			time.sleep(1)
	return setmin

#Main Program
sm=sethour(8) # Outer Function Call
sm(9) # Inner Function Call
		

