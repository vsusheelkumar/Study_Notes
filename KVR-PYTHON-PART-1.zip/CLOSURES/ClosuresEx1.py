#ClosuresEx1.py
def  outerfunction(x): # Outer Function
	def innerfunction(y): # Inner Function--Closure
		z=x+y
		return z
	return innerfunction

#Main Program
kvr=outerfunction(10) # OuterFunction Call
print("Outer Function Execution Completed")
print("type of kvr=",type(kvr))
res=kvr(5)
print("Sum=",res)
res=kvr(15)
print("Sum=",res)