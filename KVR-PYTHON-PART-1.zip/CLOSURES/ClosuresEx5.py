#ClosuresEx5.py
def  setname(sname):
	print("Iam from Outer Function Body Starts")
	localname="HYD"
	print("----------------------------------------------------------------------------------------")
	LF=lambda :"Hi {} , From {}, Good Morning".format(sname,localname)
	print("----------------------------------------------------------------------------------------")
	print("Iam from Outer Function Body Ends")
	return LF

#main Program
af=setname("Rossum") # Outer Function Call
print("Type of sf=",type(af))
res=af()
print(res)

