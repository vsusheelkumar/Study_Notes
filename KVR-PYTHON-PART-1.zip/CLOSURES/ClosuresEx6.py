#ClosuresEx6.py
def  setname(sname):
	print("Iam from Outer Function Body Starts")
	localname="HYD"
	print("----------------------------------------------------------------------------------------")
	LF=lambda val:"Hi {},{} , From {}, Good Morning".format(sname,val,localname)
	print("----------------------------------------------------------------------------------------")
	print("Iam from Outer Function Body Ends")
	return LF

#main Program
af=setname("Rossum") # Outer Function Call
print("Type of sf=",type(af))
res=af("Travis")
print(res)
res=af("John Hunter")
print(res)