#ClosuresEx2.py
def setcounter(x):  # Outer Function(Enclosing Function)--Here x Represents Formal Parameter
	y=10 # Local Variable
	def operation(z):# Inner Function(enclosed function)--Closure
		k=x+y+z
		return k
	return operation


#Main Program
op=setcounter(100)
print("Outer Function setcounter() completed Its Execution")
res=op(10000)
print("Amount to Pay=",res)

