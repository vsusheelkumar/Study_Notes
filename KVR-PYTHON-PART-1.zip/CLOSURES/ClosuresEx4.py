#ClosuresEx4.py
import time
def  setcounter(): # Outer Function
	countval=0 # Local var to setcounter()
	def  operation(): # Inner Function---Closure
		nonlocal countval
		countval=countval+1
		return countval
	return operation


op=setcounter() # Outer Function Call
for i in range(1,6):
	print("{} Time={}".format(i,op()))
	time.sleep(1)



