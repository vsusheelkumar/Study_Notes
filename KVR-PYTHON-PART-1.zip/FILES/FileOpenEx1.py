#Program makes us to uderstand How to Open the File
#FileOpenEx1.py
try:
    fp = open("kvr1.data", "r")
except FileNotFoundError:
    print("File Does not Exist")
else:
    print("-------------------------")
    print("File Opened in Read Mode Successfully")
    print("Type of fp=", type(fp))
finally:
    print("-------------------------")
    try:
        print("Is File Closed before close() =",fp.closed)
        fp.close() # Closing the File Manually
        print("Is File Closed after close()=", fp.closed)
    except NameError:
        print("File Itself Not Opened-No Need to Close")
    finally:
        print("-------------------------")


