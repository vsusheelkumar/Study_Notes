#Program makes us to uderstand How to Open the File
#FileOpenEx4.py
with open("kvr1.data","r+") as fp:
    print("********************************************************")
    print("\tFile Opened in Read Mode Sucessfully")
    print("\tIs File Closed within 'with open() as Inde.. =", fp.closed)
    print("\tFile Mode=",fp.mode)
    print("\tFile Name=",fp.name)
    print("\tIs this File Readable=",fp.readable())
    print("\tIs this File Writable=",fp.writable())
    print("********************************************************")
print("-----------------------------------")
print("Is File Closed after 'with open() as Inde.. =", fp.closed)
