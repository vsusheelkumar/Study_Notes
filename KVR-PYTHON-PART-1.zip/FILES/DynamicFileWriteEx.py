#Program for Reading Data Dynamically from KBD and write it to the File
#DynamicFileWriteEx.py
with open("E:\\KVR-PYTHON-7AM\\FILES\\NOTES\\hyd.data","a") as fp:
    print("Enter Data to write to the File (Press @ to Stop):")
    while(True):
        kbdata=input()
        if(kbdata!="@"):
            fp.write(kbdata+"\n")
        else:
            print("Data Written to the File")
            break

