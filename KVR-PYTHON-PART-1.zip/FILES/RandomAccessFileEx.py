#Program for Demonstrating the Random Access Files
#FilePointer.tell()--->Gives Index of the File where file pointer points
#FilePoniter.seek(index)-->Will Re-Set the File Pointer to Specified Index.
#RandomAccessFileEx.py
with open("kvr2.data","r") as fp:
    print("-------------------------------------------")
    print("Initially, File Pointer Points to:",fp.tell())#0
    fildata=fp.read(5)
    print("File Data=",fildata)#GUIDO
    print("Now File pointer Points to:",fp.tell())#5
    print("-------------------------------------------")
    fildata = fp.read(11)
    print("File Data=", fildata)  # VAN ROSSUM
    print("Now File pointer Points to:", fp.tell())  # 16
    print("-------------------------------------------")
    fildata = fp.read(7)
    print("File Data=", fildata)  #
    print("Now File pointer Points to:", fp.tell())  # 23
    print("-------------------------------------------")
    fildata=fp.read()
    print("File Data=", fildata)  #
    print("Now File pointer Points to:", fp.tell())  #223
    print("-------------------------------------------")
    #Re-Set the File Pointer
    fp.seek(5)
    print("Now File pointer Points to:", fp.tell())  # 5
    fildata = fp.read(11)
    print("File Data=", fildata)  # VAN ROSSUM
    print("Now File pointer Points to:", fp.tell())  # 16
    print("-------------------------------------------")
    # Re-Set the File Pointer to Intial Index 0
    fp.seek(0)
    filedata=fp.read()
    print("File Data=", filedata)  # VAN ROSSUM
    print("Now File pointer Points to:", fp.tell())  # 223
    print("-------------------------------------------")
    filedata = fp.read()
    print("File Data=", filedata)  # VAN ROSSUM
    print("Now File pointer Points to:", fp.tell())  # 223
    print("-------------------------------------------")



