#Program makes us to uderstand How to Open the File
#FileOpenEx5.py
with open("kvr5.data","a+") as fp:
    print("********************************************************")
    print("\tFile Created and Opened in Write Mode Sucessfully")
    print("\tIs File Closed within 'with open() as Inde.. =", fp.closed)
    print("\tFile Mode=",fp.mode)
    print("\tFile Name=",fp.name)
    print("\tIs this File Readable=",fp.readable())
    print("\tIs this File Writable=",fp.writable())
    print("********************************************************")
print("-----------------------------------")
print("Is File Closed after 'with open() as Inde.. =", fp.closed)
