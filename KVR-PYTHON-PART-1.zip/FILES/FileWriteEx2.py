#Program for Writing the Data to the File
#FileWriteEx2.py
print("--------------------------------------")
sno=int(input("Enter Student Number:"))
name=input("Enter Student Name:")
marks=float(input("Enter Student Marks:"))
print("--------------------------------------")
with open("Student.data","a") as fp:
    fp.write(str(sno)+"\t")
    fp.write(name+"\t")
    fp.write(str(marks)+"\n")
    print("Data Written to the File")
