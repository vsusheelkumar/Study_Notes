#Program makes us to uderstand How to Open the File
#FileOpenEx2.py
fp=open("kvr1.data","w")
print("File Created--verify")
print("type of fp=", type(fp))