#StudentMenu.py<--File Name and Module Name
def menu():
    print("*"*50)
    print("\t\tStudent Information System")
    print("*" * 50)
    print("\t\t1.Add New Student")
    print("\t\t2.Delete Student")
    print("\t\t3.Update Student")
    print("\t\t4.Searech Student")
    print("\t\t5.Select Single Student")
    print("\t\t6.Select All Student")
    print("\t\t7.Exit")
    print("*" * 50)