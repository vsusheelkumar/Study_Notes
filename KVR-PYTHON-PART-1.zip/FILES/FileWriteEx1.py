#Program for Writing the Data to the File
#FileWriteEx1.py
sno=300
name="Hunter"
marks=25.66
with open("Student.data","a") as fp:
    fp.write(str(sno)+"\t")
    fp.write(name+"\t")
    fp.write(str(marks)+"\n")
    print("Data Written to the File")
