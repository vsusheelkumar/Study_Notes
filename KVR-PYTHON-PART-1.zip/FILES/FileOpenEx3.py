#Program makes us to uderstand How to Open the File
#FileOpenEx3.py
fp=open("kvr.py","w")
print("Python File Created--verify")