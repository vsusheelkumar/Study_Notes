#Program for Reading the Data from File--readlines()
#FileReadEx2.py
try:
    with open("Student.data","r") as fp:
        filedata=fp.readlines()
        print("--------------------------------")
        for record in filedata:
            print(record,end="")
        print()
        print("--------------------------------")
except FileNotFoundError:
    print("File Does Not Exist")
