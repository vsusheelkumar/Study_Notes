#Program for Reading Employee Records from File as Object in Main Memory
#UnPickEmpEx1.py
import pickle
def readrecord():
    try:
        with open("emp.pick","rb") as fp:
            print("-"*50)
            while(True):
                try:
                    emprecord = pickle.load(fp)
                    for val in emprecord:
                        print("\t{}".format(val),end="\t")
                    print()
                except EOFError:
                    print("-" * 50)
                    break
    except FileNotFoundError:
        print("File Does not Exist")

#Main Program
readrecord()