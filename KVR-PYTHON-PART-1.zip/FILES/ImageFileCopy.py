#Program for Copying an Image
#ImageFileCopy.py
def filecopy():
    try:
       with open("D:\\BANG\\kvr.png","rb") as rp:
            with open("pythonkvr.png","wb") as wp:
                #Read the Data from Source File
                srcfiledata=rp.read()
                #write SRCFILE Data to Destination File
                wp.write(srcfiledata)
                print("Image Copied ")
    except FileNotFoundError:
        print("Source File Does not Exist")
#main Program
filecopy() # Function Call
