#Program for Reading Employee Details from KBD and save then File as Record
#PickEmpEx1.py
import pickle
def saverecord():
    with open("emp.pick","ab") as fp:
        #Accept the Emp Values fom KBD
        print("-"*50)
        eno=int(input("Enter Employee Number:"))
        ename=input("Enter Employee Name: ")
        sal=float(input("Enter Employee Salary:"))
        print("-" * 50)
        lst=[]
        lst.append(eno)
        lst.append(ename)
        lst.append(sal)
        #save lst data to the File
        pickle.dump(lst,fp)
        print("Employee Record Saved into the File")
        print("-" * 50)

#Main Program
saverecord()