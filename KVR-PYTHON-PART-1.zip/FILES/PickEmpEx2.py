#Program for Reading Employee Details from KBD and save then File as Record
#PickEmpEx2.py
import pickle
import sys
sys.path.append("E:\\KVR-PYTHON-7AM\\EXCEPTION HANDLING\\CASE STUDY-3")
from NameValidation import validation
from NameValidExceptions import *
def saverecord():
    with open("emp.pick","ab") as fp:
        while(True):
            try:
                #Accept the Emp Values fom KBD
                print("-"*50)
                eno=int(input("Enter Employee Number:"))
                ename=validation(input("Enter Employee Name: "))
                sal=float(input("Enter Employee Salary:"))
                print("-" * 50)
                lst=[]
                lst.append(eno)
                lst.append(ename)
                lst.append(sal)
                #save lst data to the File
                pickle.dump(lst,fp)
                print("Employee Record Saved into the File")
                print("-" * 50)
                ch=input("Do u want to Insert anothere record(yes/no):")
                if(ch.lower()=="no"):
                    print("Thx for This program")
                    break
            except ValueError:
                print("Don't Enter Alnums,strs and Symbols for Empno and Salary")
            except ZeroLengthError:
                print("\t U Must enter Ur Name-try again")
            except SpaceError:
                print("\tDon't Enter Space to UR  Name-try again")
            except InvalidNameError:
                print("\tUr Name is Invalid-try again ")

#Main Program
saverecord()