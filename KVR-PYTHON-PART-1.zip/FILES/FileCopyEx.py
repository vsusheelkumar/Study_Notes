#Program for Copying the Content of One File into Another File
#FileCopyEx.py
def filecopy():
    try:
        srcfile=input("Enter Source File:")
        with open(srcfile,"rt") as rp:
            destfile=input("Enter Destination File:")
            with open(destfile,"at") as wp:
                #Read the Data from Source File
                srcfiledata=rp.read()
                #write SRCFILE Data to Destination File
                wp.write(srcfiledata)
                print("Source File Content Copied into Destination File")
    except FileNotFoundError:
        print("Source File Does not Exist")
#main Program
filecopy() # Function Call