#Program for Writing the Data to the File
#FileWriteEx2.py
x= {10:1.2,20:3.4,40:5.6}
with open("Student1.data","a") as fp:
    fp.writelines(str(x)+"\n")
    print("Data Written to the File")
