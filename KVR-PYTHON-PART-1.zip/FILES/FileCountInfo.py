#Program for Counting Number of Lines, words and Chars
#FileCountInfo.py
filename=input("Enter File Name:")
nl=0
nw=0
nc=0
with open(filename,"r") as fp:
    filedata=fp.readlines()
    for line in filedata:
        print(line,end="")
        nl=nl+1
        nw=nw+len(line.split())
        nc=nc+len(line)
    else:
        print("\n-----------------------------------")
        print("Number of Lines=",nl)
        print("Number of Words=",nw)
        print("Number of Chars=",nc)
        print("-----------------------------------")