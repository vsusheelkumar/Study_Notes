#Program for Displaying the content of File
#DisplayFileContentEx.py
try:
    filename=input("Enter File Name to display Its Content:")
    with open(filename,"r") as fp:
        filedata=fp.read()
        print("---------------------------------")
        print("Content of File")
        print("---------------------------------")
        print(filedata)
        print("---------------------------------")
except FileNotFoundError:
    print("File Does not Exist:")