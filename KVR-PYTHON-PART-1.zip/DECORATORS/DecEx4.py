#DecEx4.py
def cube(calc):
	def perform():
		n,sqv,sqrtv=calc()
		cbtv=n**3
		return n,sqv,sqrtv,cbtv
	return perform

def squareroot(calc):
	def perform():
		n,sqv=calc()
		sqrtv=n**0.5
		return n,sqv,sqrtv
	return perform

def squareval(gv):# Here squareval is called Decorator Def.--Outer Fun
	def calculate(): # Inner Function
		n=gv()
		res=n**2
		return n,res
	return calculate

@cube
@squareroot
@squareval
def getval():  # Defined by KVR
	return float(input("Enter Anu Numerical Value:"))

#Main Program
n,sqv,sqrtv,cbtv=getval() # Normal Function Call
print("Square({})={}".format(n,sqv))
print("SquareRoot({})={}".format(n,sqrtv))
print("Cube({})={}".format(n,cbtv))