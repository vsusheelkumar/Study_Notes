#DecEx1.py
def getval():  # Defined by KVR
	return float(input("Enter Anu Numerical Value:"))

def squareval(kvr): # Here squareval is called Decorator Def.--Outer Fun
	def calc(): # Inner Function
		n=kvr()
		res=n**2
		return n,res
	return calc
	
#Main Program
cal=squareval( getval  ) # Decorator Call
n,sqv=cal()
print("Square({})={}".format(n,sqv))