#DecEx2.py
def squareval(gv):# Here squareval is called Decorator Def.--Outer Fun
	def calculate(): # Inner Function
		n=gv()
		res=n**2
		return n,res
	return calculate

@squareval
def getval():  # Defined by KVR
	return float(input("Enter Anu Numerical Value:"))

	
#Main Program
n,sqv=getval() # Normal Function Call
print("Square({})={}".format(n,sqv))