#Non-DecEx1.py
def getval():  # Defined by KVR
	return 5

def squareval():					#Vandana asked me give square of 5
	n=getval()
	res=n**2
	print("Square({})={}".format(n,res))

def squaroot():					#Divya asked me give Square Root of 5
	n=getval()
	res=n**0.5
	print("SquareRoot({})={}".format(n,res))

def cube():						#Nuthan asked me give Cube of 5
	n=getval()
	res=n**3
	print("Cube({})={}".format(n,res))

#Main Program
squareval()
squaroot()
cube()