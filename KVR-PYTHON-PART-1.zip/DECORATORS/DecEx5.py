#Program accepting a line of Text and Get into Upper Case and Lower Case Separately.
#DecEx5.py
def ConvertToLower(upc):
	def lowerconverter():
		line,uc=upc()
		lc=line.lower()
		return line,uc,lc
	return lowerconverter

def ConvertToUpper(gl):
	def upperconverter():
		line=gl()
		uc=line.upper()
		return line,uc
	return upperconverter

@ConvertToLower
@ConvertToUpper
def getline():
	return input("Enter Line of Text:")

#Main Program
line,uc,lc=getline()
print("----------------------------------------------")
print("Given Line=",line)
print("Upper Case Line=",uc)
print("Lower Case Line=",lc)
print("----------------------------------------------")