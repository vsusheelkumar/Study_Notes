#Program for Reading the Words from KBD by using List Comprehension
#ListCompEx3.py
print("Enter List of Words Separated by Comma:")
lst=[ val  for val in input().split(",")]  # List Comprehension
print("List of Words=",lst)
