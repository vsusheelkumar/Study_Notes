#Program for Reading the Words from KBD and get Only Palindrome words by using List Comprehension
#DictCompEx5.py
print("Enter List of Words separated by comma:")
words={word:len(word) for word in input().split(",") if word==word[::-1]}
print("*"*50)
print("\tWord\t\tLength")
print("*"*50)
for k,v in words.items():
    print("\t{}\t\t\t\t{}".format(k,v))
print("*"*50)


