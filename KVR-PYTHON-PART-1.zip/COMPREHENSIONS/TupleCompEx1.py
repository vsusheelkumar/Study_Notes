#Program for Reading the Values from KBD by using List Comprehension
#TupleCompEx1.py
print("Enter List of Values separated Space")
kvr=(float(val) for val in input().split())
#Here kvr is an object of <class,generator>
#Conver generator Object into tuple
tpl=tuple(kvr)
print(tpl,type(tpl))
