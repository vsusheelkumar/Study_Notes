#Program for Reading the Words and Get Their Lengths ranges between 3 to 4
#DictCompEx3.py
print("Enter List of Words Separated by comma:")
d={word:len(word) for word in input().split(",") if len(word) in range(3,5) } # Dict Comprehension
print("*"*50)
print("\tWord\t\tLength")
print("*"*50)
for k,v in d.items():
    print("\t{}\t\t\t\t{}".format(k,v))
print("*"*50)

