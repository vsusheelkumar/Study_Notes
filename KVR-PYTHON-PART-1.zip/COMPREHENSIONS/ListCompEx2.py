#Program for Reading the Values from KBD by using List Comprehension
#ListCompEx2.py
print("Enter List of Values Separated by Comma:")
lst=[ float(val)  for val in input().split(",")]  # List Comprehension
print("List of Values=",lst)
