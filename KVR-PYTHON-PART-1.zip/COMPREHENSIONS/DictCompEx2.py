#Program for Reading the Numerical Values and Get Their Squares
#DictCompEx2.py
print("Enter List of Values Separated by Space:")
d={ float(val):round(float(val)**0.5,2)  for val in input().split()} # Dict Comprehension
print("*"*50)
print("\tValue\t\tSquares")
print("*"*50)
for k,v in d.items():
    print("\t{}\t\t\t\t{}".format(k,v))
print("*"*50)

