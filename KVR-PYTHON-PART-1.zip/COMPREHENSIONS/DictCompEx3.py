#Program for Reading the Words and Get Their Lengths
#DictCompEx3.py
print("Enter List of Words Separated by comma:")
d={word:len(word) for word in input().split(",") } # Dict Comprehension
print("*"*50)
print("\tWord\t\tLength")
print("*"*50)
for k,v in d.items():
    print("\t{}\t\t\t\t{}".format(k,v))
print("*"*50)

