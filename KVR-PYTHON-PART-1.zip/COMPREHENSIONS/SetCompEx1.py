#Program for Reading the Numerical Values and Get Only +VE from KBD by using Set Comprehension
#SetCompEx1.py
print("Enter List of Values Separated by Space:")
lst= { float(val)  for val in input().split()  if float(val)>0 }  # List Comprehension
print("Set of +Ve Values=",lst)


