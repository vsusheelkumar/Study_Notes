#Program for Reading the Words from KBD and get Only Palindrome words by using List Comprehension
#ListCompEx6.py
print("Enter List of Words separated by comma:")
words=[word for word in input().split(",") if word==word[::-1]]
print("List of Palindrome Words")
print(words)
