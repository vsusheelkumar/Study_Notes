#Program for Reading the Values from KBD and get Unique Value by Eliminating Duplicates
#ListCompEx6.py
print("Enter List of Values separated by comma:")
uv=list(set([float(value) for value in input().split(",")]))
print("List of Unique Values")
print(uv)
