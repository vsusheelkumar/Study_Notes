#Program for Reading the Values from KBD by using List Comprehension
#ListCompEx1.py
print("Enter List of Values separated Space")
lst=[float(val) for val in input().split()]
print("List of Values=",lst)

