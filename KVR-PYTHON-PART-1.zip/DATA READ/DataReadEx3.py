#Program for Reading Two Values and Multiply them
#DataReadEx3.py
a=input("Enter Value of a:")
b=input("Enter Value of b:")
#convert str type values a,b into float type
x=float(a)
y=float(b)
#Multiply them
z=x*y
#display the result
print("-"*50)
print("\t\tFirst Value={}".format(x))
print("\t\tSecond Value={}".format(y))
print("\t\tMul={}".format(z))
print("-"*50)