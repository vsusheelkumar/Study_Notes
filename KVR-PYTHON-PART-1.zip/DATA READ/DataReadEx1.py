#DataReadEx1.py
print("Enter Any Value:")
x=input()
print("Val of x={} Type={}".format(x,type(x)))