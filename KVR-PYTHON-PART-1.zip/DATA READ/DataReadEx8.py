#Program for Reading Two Values and Multiply them
#DataReadEx7.py
print("\t\tMul={}".format(float(input("Enter Value of a:"))*float(input("Enter Value of b:"))))
