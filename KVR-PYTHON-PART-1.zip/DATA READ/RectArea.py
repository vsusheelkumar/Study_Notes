#Program for Calculating Area of Rectangle
#RectArea.py
L=float(input("Enter Length:"))
B=float(input("Enter Breadth:"))
ar=L*B
print("*"*50)
print("\tLength={}".format(L))
print("\tBreadth={}".format(B))
print("\tArea of Rect={}".format(round(ar,2)))
print("*"*50)