#Program for Reading Two Values and Multiply them
#DataReadEx6.py
print("Enter Two Values")
z=float(input())*float(input())
#display the result
print("-"*50)
print("\t\tMul={}".format(z))
print("-"*50)