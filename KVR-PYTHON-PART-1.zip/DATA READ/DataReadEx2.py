#DataReadEx2.py
x=input("Enter Any Value:")
print("Val of x={} Type={}".format(x,type(x)))