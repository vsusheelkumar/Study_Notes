#Program for Reading Two Values and Multiply them
#DataReadEx5.py
print("Enter Two Values")
x=float(input())
y=float(input())
#Multiply them
z=x*y
#display the result
print("-"*50)
print("\t\tFirst Value={}".format(x))
print("\t\tSecond Value={}".format(y))
print("\t\tMul={}".format(z))
print("-"*50)