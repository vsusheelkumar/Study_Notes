#Program for Calculating Area of Circle
#ClrcleAreaEx.py
r=float(input("Enter Radius:"))
ac=3.14*r*r
print("*"*50)
print("\t\tRadius of Circle={}".format(r))
print("\t\tArea of Circle={}".format(ac))
print("---------------OR----------------------------")
print("\t\tArea of Circle=%0.2f" %ac)
print("---------------OR----------------------------")
print("\t\tArea of Circle={}".format(round(ac,2)))
print("*"*50)