#Program for Reading Two Values and Multiply them
#DataReadEx4.py
x=float(input("Enter Value of a:"))
y=float(input("Enter Value of b:"))
#Multiply them
z=x*y
#display the result
print("-"*50)
print("\t\tFirst Value={}".format(x))
print("\t\tSecond Value={}".format(y))
print("\t\tMul={}".format(z))
print("-"*50)