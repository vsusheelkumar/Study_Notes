#Program for Reading Two Values and Multiply them
#DataReadEx7.py
z=float(input("Enter Value of a:"))*float(input("Enter Value of b:"))
print("-"*50)
print("\t\tMul={}".format(z))
print("-"*50)