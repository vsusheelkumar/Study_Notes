#Program for Mul of Two numbers
a=3
b=4
c=a*b
print("Val of a=",a)
print("Val of b=",b)
print("Mul=",c)