#Program for Adding of Two Numbers
a=float(input("Enter Value of a:"))
b=float(input("Enter Value of b:"))
c=a+b
print("-----------------------------")
print("Val of a=",a)
print("Val of a=",b)
print("Sum({},{})={}".format(a,b,c))
print("-----------------------------")

