#Program for adding of Two Numbers
#SumEx1.py
a=100
b=200
c=a+b
print(a)
print(b)
print(c)
