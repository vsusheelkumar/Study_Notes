#CSVPandasReadEx1.py
import pandas as pd
df=pd.read_csv("E:\\KVR-PYTHON-7AM\\CSV\\NOTES\\book.csv")
print("--------------------------------------")
print(df)
print("--------------------------------------")
