#Non-CSVRead.py
with open("E:\\KVR-PYTHON-7AM\\CSV\\NOTES\\employee.csv") as fp:
    csvfiledata=fp.read()
    print("CSV File Content")
    print(csvfiledata)
