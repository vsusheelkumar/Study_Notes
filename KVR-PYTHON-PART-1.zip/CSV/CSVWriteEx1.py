#Program for Creating a CSV File
#CSVWriteEx1.py
import csv # Step-1
colnames=["STNO","NAME","MARKS"] # Step-2
records=[[10,"Rossum",45.67],
        [20,"Travis",56.78],
        [30,"Dennis",33.33],
        [40,"Ritche",88.88],
        [50,"Strrup",33.21]] # Step-3
with open("E:\\KVR-PYTHON-7AM\\CSV\\NOTES\\student.csv","a") as fp:#Step-4
    csvwr=csv.writer(fp) # Here csvwr is an object of <class, csv.Writer>
    #In csvwr, we have Two Functions: 1) writerow()  2) writerows()
    #Writing the Colnames to the CSV File
    csvwr.writerow(colnames) # Step-5
    csvwr.writerows(records) # Step-6
    print("CSV File Created--verify")





