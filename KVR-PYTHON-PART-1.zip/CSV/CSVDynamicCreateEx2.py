#Program for Creating Dynamic CSV File
#CSVDynamicCreateEx2.py
import csv
noc=int(input("Enter How Many Col Names u have:"))
if(noc<=0):
    print("{} is Invalid Number of Columns".format(noc))
else:
    colnames=[]
    for i in range(1,noc+1):
        colname=input("Enter {} Col Name:".format(i))
        colnames.append(colname)
    else:
        nor=int(input("Enter How Many Records u have:"))
        if(nor<=0):
            print("{} is Invalid Number of Records:".format(nor))
        else:
            records=[]
            for rno in range(1,nor+1):
                print("Enter {} Record Deatils:".format(rno))
                print("--------------------------------------")
                record= {} # OR dict()
                for col in colnames:
                    colval=input("\tEnter {} Value:".format(col))
                    record[col]=colval
                records.append(record)
            while (True):
                csvfilename = input("Enter CSV File Name with an extension .csv")
                if (not csvfilename.endswith(".csv")):
                    print("Invalid File Name-Must have an extension .csv-try again")
                else:
                    break
            # Open the CSV File Name
            with open("E:\\KVR-PYTHON-7AM\\CSV\\NOTES\\" + csvfilename, "a") as fp:
                csvdwr=csv.DictWriter(fp,fieldnames=colnames)
                csvdwr.writeheader()
                csvdwr.writerows(records)
                print("CSV File Created with Dict Data--Verify")







