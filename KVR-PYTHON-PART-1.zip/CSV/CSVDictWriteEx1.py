#Program for Creating the CSV File with Dictionary Data
#CSVDictWriteEx1.py
import csv # Step-1
colnames=["BookID","BookName","Price"] # Step-2
records=[{"BookID":1000,"BookName":"Python","Price":350},
         {"BookID":2000,"BookName":"C++","Price":150},
         {"BookID":3000,"BookName":"JAVA","Price":250},
         {"BookID":4000,"BookName":"DSA","Price":450}] # Step-3
with open("E:\\KVR-PYTHON-7AM\\CSV\\NOTES\\book.csv","a") as fp: # Step-4
    csvdwr=csv.DictWriter(fp,fieldnames=colnames)
    #here csvdwr is an object of <class, csv.DictWriter>
    #csvdwr contains Two Function 1) writeheader() 2) writerows()
    csvdwr.writeheader() #Step-5
    csvdwr.writerows(records) # Step-6
    print("CSV File Created with Dict Data--verify")





