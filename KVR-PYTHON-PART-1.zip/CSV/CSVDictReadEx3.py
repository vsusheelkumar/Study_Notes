#Program for Reading the Data from CSV File in the form of Dict
#CSVDictReadEx3.py
import csv
with open("E:\\KVR-PYTHON-7AM\\CSV\\NOTES\\student.csv") as fp:
    csvr=csv.reader(fp) # here csvr is an object of <class, _csv.reader>
    for record in csvr:
        for val in record:
            print("\t{}".format(val),end="\t")
        print()
