#Program for adding the new Record to the existing CSV File
#CSVWriteEx2.py
import csv # Step-1
record=[60,"KVR",11.11] # Record
with open("E:\\KVR-PYTHON-7AM\\CSV\\NOTES\\student.csv","a") as fp:
    csvwr=csv.writer(fp)
    csvwr.writerow(record)
    print("New Record Added to the CSV File")





