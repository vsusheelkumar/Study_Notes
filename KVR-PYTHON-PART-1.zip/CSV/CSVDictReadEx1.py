#Program for Reading the Data from CSV File in the form of Dict
#CSVDictReadEx1.py
import csv
with open("E:\\KVR-PYTHON-7AM\\CSV\\NOTES\\employee.csv") as fp:
    csvdr=csv.DictReader(fp)
    for record in csvdr:
        print("-"*50)
        for k,v in record.items():
            print("\t{}--->{}".format(k,v))
        print()
        print("-" * 50)