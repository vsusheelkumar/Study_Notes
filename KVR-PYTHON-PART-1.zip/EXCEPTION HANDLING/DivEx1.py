#Program for Division of Two Numbers
#DivEx1.py
print("Program Execution Started")
a=input("Enter First Value:")
b=input("Enter Second Value:")
#Convert a and b into int type
x=int(a)#------------------------ValueError
y=int(b) #------------------------ValueError
z=x/y #------------------------ZeroDivisionError
print("Div=",z)
print("Program Execution Ended")
