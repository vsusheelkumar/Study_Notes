#Program for Division of Two Numbers
#This Code Developed  by KVR in 15-02-2025 at 7:40AM
#This Code will come for Maintenance after 5 Years 15-02-2030. At that of Time  if new Programmer adds a new statement and It may give exception and handle that exception now and It gives a Message to the New Programmer.
#DivEx7.py
try:
	print("Program Execution Started")
	a=input("Enter First Value:")
	b=input("Enter Second Value:")
	#Convert a and b into int type
	x=int(a)#------------------------ValueError
	y=int(b) #------------------------ValueError
	z=x/y #------------------------ZeroDivisionError
	s="PYTHON"
	print(s[10])
except  ZeroDivisionError:
	print("\tDON'T ENTER ZERO FOR DEN...")
except ValueError:
	print("\tDON'T ENTER ALNUMS,STRS AND SYMBOLS")
except IndexError:
	print("\tInvalid Index--Check Ur Index")
except: # Default except Block
	print("\tOoops  Some Thing went wrong--try again")
else:
	print("----------else block------------------")
	print("Div=",z)
finally:
	print("-----------finally block-------------")
	print("Program Execution Ended")

