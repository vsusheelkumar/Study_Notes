#MulTableMainProg.py
from MulTableExcept import NegativeNumberError,ZeroError
from MulTable import table
try:
    n=int(input("Enter a Number for Generating Mul Table:"))
    table(n) # Function Call either Gives Resul or Exceptions
except NegativeNumberError:
    print("\tDON'T ENTER -VE NUMBER FOR MUL TABLE")
except ZeroError:
    print("\tDON'T ENTER ZERO FOR DEN...")
except ValueError:
    print("\tDON'T ENTER ALNUMS,STRS AND SYMBOLS")
except:
    print("OOOps some thing went wrong-try again")