#MulTable.py<------File Name and Module Name
from MulTableExcept import NegativeNumberError,ZeroError
def table(n):
    if(n<0):
        raise NegativeNumberError
    elif(n==0):
        raise ZeroError
    else:
        print("-"*50)
        print("\tMul table for:{}".format(n))
        print("-" * 50)
        for i in range(1,11):
            print("\t{} x {} = {}".format(n,i,n*i))
        print("-" * 50)
