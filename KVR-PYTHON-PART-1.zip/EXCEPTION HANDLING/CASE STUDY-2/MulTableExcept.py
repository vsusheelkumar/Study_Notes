#MulTableExcept.py<--File Name and Module Name
class NegativeNumberError(Exception):pass
class ZeroError(BaseException):pass