#Program for Division of Two Numbers
#DivEx4.py
try:
	print("Program Execution Started")
	a=input("Enter First Value:")
	b=input("Enter Second Value:")
	#Convert a and b into int type
	x=int(a)#------------------------ValueError
	y=int(b) #------------------------ValueError
	z=x/y #------------------------ZeroDivisionError
except  ZeroDivisionError as z:
	print("\t",z)
except ValueError as v:
	print("\t",v)
else:
	print("----------else block------------------")
	print("Div=",z)
finally:
	print("-----------finally block-------------")
	print("Program Execution Ended")

