#Program for Division of Two Numbers
#DivEx3.py
try:
	print("Program Execution Started")
	a=input("Enter First Value:")
	b=input("Enter Second Value:")
	#Convert a and b into int type
	x=int(a)#------------------------ValueError
	y=int(b) #------------------------ValueError
	z=x/y #------------------------ZeroDivisionError
except  ZeroDivisionError:
	print("\tDON'T ENTER ZERO FOR DEN...")
except ValueError:
	print("\tDON'T ENTER ALNUMS,STRS AND SYMBOLS")
else:
	print("----------else block------------------")
	print("Div=",z)
finally:
	print("-----------finally block-------------")
	print("Program Execution Ended")

