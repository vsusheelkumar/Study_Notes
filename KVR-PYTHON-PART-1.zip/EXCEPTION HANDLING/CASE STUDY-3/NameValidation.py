#NameValidation.py<--File Name and Module Name
from NameValidExceptions import ZeroLengthError,SpaceError,InvalidNameError
def validation(name): # name=Guido Va2n Rossum
    if(name.isspace()):
        raise SpaceError
    else:
        words=name.split()
        if(len(words)==0):
            raise ZeroLengthError
        else:
            res=True
            for word in words:
                if(not word.isalpha()):
                    res=False
                    break
            if(not res):
                raise InvalidNameError
            else:
                return name
