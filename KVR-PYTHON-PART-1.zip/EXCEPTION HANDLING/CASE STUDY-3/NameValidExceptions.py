#NameValidExceptions.py<--File and Module Name
class ZeroLengthError(Exception):pass
class SpaceError(Exception):pass
class InvalidNameError(Exception):pass