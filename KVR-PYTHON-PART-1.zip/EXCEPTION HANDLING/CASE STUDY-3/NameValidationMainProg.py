#NameValidationMainProg.py
from NameValidExceptions import ZeroLengthError,SpaceError,InvalidNameError
from NameValidation import validation
try:
    name=input("Enter UR Name:")
    vname=validation(name)# Function Call gives either result or exceptions
except ZeroLengthError:
    print("\t U Must enter Ur Name-try again")
except SpaceError:
    print("\tDon't Enter Space to UR  Name-try again")
except InvalidNameError:
    print("\tUr Name is Invalid-try again ")
else:
    print("\t'{}' is Valid Name".format(name))
