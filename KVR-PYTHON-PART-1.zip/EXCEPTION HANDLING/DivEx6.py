#Program for Division of Two Numbers
#In Industry , It is not recommended to write single default except block.
#DivEx6.py
try:
	print("Program Execution Started")
	a=input("Enter First Value:")
	b=input("Enter Second Value:")
	#Convert a and b into int type
	x=int(a)#------------------------ValueError
	y=int(b) #------------------------ValueError
	z=x/y #------------------------ZeroDivisionError
except : # Default except Block
	print("\tOoops  Some Thing went wrong--try again")
else:
	print("----------else block------------------")
	print("Div=",z)
finally:
	print("-----------finally block-------------")
	print("Program Execution Ended")

