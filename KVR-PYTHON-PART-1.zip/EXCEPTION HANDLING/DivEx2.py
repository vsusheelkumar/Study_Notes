#Program for Division of Two Numbers
#DivEx2.py
try:
	print("Program Execution Started")
	a=input("Enter First Value:")
	b=input("Enter Second Value:")
	#Convert a and b into int type
	x=int(a)#------------------------ValueError
	y=int(b) #------------------------ValueError
	z=x/y #------------------------ZeroDivisionError
	print("Div=",z)
	print("Program Execution Ended")
except ZeroDivisionError:
	print("Don't enter Zero for Den..")
except ValueError:
	print("Don't enter Alnums,strs and symbols")