#KvrDivisionDemo.py<---Main Program
from KvrDivision import division
from KvrZeroError import KvrDivisionError
try:
    x=float(input("Enter First Value:"))
    y=float(input("Enter Second Value:"))
    res=division(x,y) # Function Call--result and exception
    print(res)
except KvrDivisionError:
    print("\tDON'T ENTER ZERO FOR DEN...")

#Phase-3: handling the exceptions