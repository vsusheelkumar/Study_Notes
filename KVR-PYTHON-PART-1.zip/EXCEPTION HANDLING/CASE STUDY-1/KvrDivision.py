#KvrDivision.py<---File Name and Module Name
from KvrZeroError import KvrDivisionError
def division(a,b):
    if(b==0):
        raise KvrDivisionError
    else:
        return(a/b)

#Phase-2: Hitting of exceptions during Business Logic Development.