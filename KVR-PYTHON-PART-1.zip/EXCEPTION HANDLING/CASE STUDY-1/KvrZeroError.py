#KvrZeroError.py<---File Name and Module Name--(3)
#           (1)         (2)
class KvrDivisionError(Exception):pass


#Phase-1--Here KvrDivisionError is called Programmer-Defined Exception Class.