#ATMMenu.py<---File and Module Name
def menu():
    print("-"*50)
    print("\tATM or FUNDS TRANSFER APPLICATION")
    print("-" * 50)
    print("\t\t1.Deposit")
    print("\t\t2.Withdraw")
    print("\t\t3.BalEnq")
    print("\t\t4.Exit")
    print("-" * 50)